/*
*    int_kidney_exchange
*    contribution+benefit.cpp
*    Purpose: computational study for Computing Balanced Solutions for Large International Kidney
*			  Exchange Schemes When Maximum Cycle Length Is Three
*             using the benefit and contribution value as initial allocations with inequal country sizes
*
*
*    @version 1.0 13/03/2025
*
*    This program is free software: you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation, either version 3 of the License, or
*    (at your option) any later version and the Gurobi License.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
*    GNU General Public License for more details.
*
*/

#include "benefit_contribution_inequal.h"
#include "Allocation.h" 




int main() {
	try {
		std::cout << "I solemnly swear that I am up to no good." << endl;
		bool target_omega = true; // true: benefit value, false: constribution value
		bool dispy = false; // true: information in terminal while running
		bool disp = false; // true: extremely detailed information while running, avoid with large graphs
		bool c_involved = false;// true: credits considred; false:without credits 
		bool arbitray_maximum = false; //true: arbitray maximum cycple packing
		bool lex_min = false;
		string solution_concept;
		string version;
		bool d1 = false;
		bool d_c = false;
		bool lexmin_call = false;
		bool lexmin_c_call = false;
		bool arbitrary = true;
		map<int, int> temp;
		vector<map<int, int>> cycle_dis_for_all_temp(24, temp);
		vector<vector< map<int, int>>> cycle_dis_for_all(7, cycle_dis_for_all_temp);
		string cycle_length = "length-3";
		string country_size = "inequal";
		if (d1) {
			version = "d1";
		}
		else {
			if (lexmin_call) {
				version = "lexmin_call";
			}
			if (lexmin_c_call) {
				version = "lexmin_c_call";
			}
			if (d_c) {
				version = "d1_c";
			}
			if (arbitrary) {
				version = "arbitrary";
			}
		}

		if (target_omega) {
			solution_concept = "benefit";
			cout << solution_concept << endl;
		}
		else {
			solution_concept = "contribution";
			cout << solution_concept << endl;
		}
		unsigned short int years = 6;
		unsigned short int periods_per_year = 4;
		// input parameters and data
		unsigned short int N;
		unsigned short int inst; // instance number, integer between 0 and 99
		vector<double> temp_period(24, 0);
		vector<vector<double>> deviation_period(7, temp_period);
		vector<vector<vector<double>>> average_d_period(5, deviation_period);
		map<int, int> numofMaxSolution;
		map<int, int> numofMaxSolution_t_d;
		map<int, int> numofMaxSolution_arbitrary;
		vector<double> relative_d1_N(12, 0);
		vector<double> relative_d1_N_c(12, 0);
		vector<double> relative_arbitrary_N(12, 0);
		vector<double> relative_lexmin(12, 0);
		vector<double> relative_lexmin_c(12, 0);
		vector<double> max_d1_N(12, 0);
		vector<double> max_d1_N_c(12, 0);
		vector<double> max_arbitrary_N(12, 0);
		vector<double> max_lexmin(12, 0);
		vector<double> max_lexmin_c(12, 0);
		vector<double> M_N(12, 0);
		vector<double> M_N_d_c(12, 0);
		vector<double> M_N_d_arbitrary(12, 0);
		vector<double> M_N_lex_min(12, 0);
		vector<double> M_N_lex_min_c(12, 0);
		vector<double> core_dis_N(12, 0);
		vector<double> core_dis_N_c(12, 0);
		vector<double> core_dis_N_arbitrary(12, 0);
		vector<long> out_of_core(12, 0);
		vector<long> out_of_core_c(12, 0);
		vector<long> out_of_core_arbitrary(12, 0);
		vector<double> data_preparation_N(12, 0);
		vector<double> graph_building_N(12, 0);
		vector<double> game_generation_arbitrary_N(12, 0);
		vector<double> game_generation_d1_N(12, 0);
		vector<double> game_generation_d1_c_N(12, 0);
		vector<double> game_generation_lexmin_N(12, 0);
		vector<double> game_generation_lexmin_c_N(12, 0);
		vector<double> time_arbitrary_N(12, 0);
		vector<double> time_d1_N(12, 0);
		vector<double> time_d1_c_N(12, 0);
		vector<double> time_lex_min_N(12, 0);
		vector<double> time_lex_min_c_N(12, 0);
		vector<double> total_time_arbitrary_N(12, 0);
		vector<double> total_time_d1_N(12, 0);
		vector<double> total_time_d1_c_N(12, 0);
		vector<double> total_time_lex_min_N(12, 0);
		vector<double> total_time_lex_min_c_N(12, 0);
		vector<double> solution_concept_time_arbitrary_N(12, 0);
		vector<double> solution_concept_time_d1_N(12, 0);
		vector<double> solution_concept_time_d1_c_N(12, 0);
		vector<double> solution_concept_time_lexmin_N(12, 0);
		vector<double> solution_concept_time_lexmin_c_N(12, 0);
		vector<vector<double>> mipgap_N(7), lb_N(7), ub_N(7);
		vector<int> not_optimal(100, 0);
		vector<vector<int>> track_not_optimal_temp(5, not_optimal);
		vector<vector<vector<int>>> track_not_optimal(5, track_not_optimal_temp);
		vector<vector<vector<int>>> track_time_limit(5, track_not_optimal_temp);
		vector<double> temp_relative(5, 0);
		vector<vector<double>> relative_optimal(5, temp_relative);
		for (N = 4; N < 9; ++N) {
			Allocation allo;
			double relative_d1 = 0;
			double relative_d1_c = 0;
			double relative_d1_arbitrary = 0;
			double relative_lexmin_0 = 0;
			double relative_lexmin_c_0 = 0;
			double data_preparation = 0;
			double graph_building = 0;
			double game_generation_arbitrary = 0;
			double game_generation_d1 = 0;
			double game_generation_d1_c = 0;
			double game_generation_lexmin = 0;
			double game_generation_lexmin_c = 0;
			double time_arbitrary = 0;
			double time_d1 = 0;
			double time_d1_c = 0;
			double time_lex_min = 0;
			double time_lex_min_c = 0;
			double total_time_arbitrary = 0;
			double total_time_d1 = 0;
			double total_time_d1_c = 0;
			double total_time_lex_min = 0;
			double total_time_lex_min_c = 0;
			double solution_concept_time_arbitrary = 0;
			double solution_concept_time_d1 = 0;
			double solution_concept_time_d1_c = 0;
			double solution_concept_time_lexmin = 0;
			double solution_concept_time_lexmin_c = 0;
			double max_d1 = 0;
			double max_d1_c = 0;
			double max_d1_arbitrary = 0;
			double max_lexmin_0 = 0;
			double max_lexmin_c_0 = 0;
			double M_100 = 0;
			double M_100_d_c = 0;
			double M_100_d_arbitrary = 0;
			double M_lex_min = 0;
			double M_lex_min_c = 0;
			double core_100 = 0;
			double core_d = 0;
			double core_d_c = 0;
			double core_d_arbitrary = 0;
			long negative_core = 0;
			long negative_core_d = 0;
			long negative_core_d_c = 0;
			long negative_core_d_arbitrary = 0;
			vector<double> mipgap, lb, ub;
			map<int, int> cycle_dis_temp;
			vector<map<int, int>> cycle_dis(24, cycle_dis_temp);
			for (inst = 0; inst < 100; ++inst) {
				std::cout << N << "countries" << " " << "instance_" << inst << endl;
				string line;
				ifstream inp;
				unsigned short int graph_size = 2000;
				// read the data
				inp.open("/data/genxml-" + to_string(inst) + ".xml"); // 1 out of the 100 instances generated by William Pettersson's web tool: https://wpettersson.github.io/kidney-webapp/#/
				getline(inp, line);
				inp.close();


				vector<unsigned short int> Vp(N, 0);
				vector<unsigned short int> Vp_start(N + 1, 0);
				country_sizes(N, Vp, Vp_start, dispy, graph_size);
				unsigned short int no_of_nodes = Vp_start[N];
				vector<unsigned int> arc_out(0, 0);
				vector<unsigned int> arc_in(0, 0);
				unsigned int m = 0;
				unsigned short int k = 0;
				unsigned short int M = 0;
				double M_total = 0;
				vector<unsigned short int> node_labels(no_of_nodes, 0);
				vector<unsigned short int> label_positions(graph_size, graph_size + 1);
				unsigned int S = pow(2, N) - 2;
				set<int> active_source;
				vector<int> source_set;
				// biparite graph
				ListGraph g;
				// original compatibility graph
				ListDigraph g_original;
				vector<ListGraph::Node> c(no_of_nodes);
				vector<ListGraph::Node> c_b(no_of_nodes);
				vector<ListDigraph::Node> c_original(no_of_nodes);
				vector<int> node_set;
				double t0 = cpuTime();
				// paste the data
				xml_parser(line, node_labels, label_positions, c, c_b, c_original, k, g, g_original, arc_in, arc_out, m, no_of_nodes);
				allo.load(arc_in, arc_out, source_set);
				cout << "label positions: " << label_positions[2383] << endl;
				cout << "maxid: " << allo.maxId << endl;
				cout << "arc_in.size(): " << arc_in.size() << ";" << "arc_out.size(): " << arc_out.size() << endl;
				double t1 = cpuTime();
				data_preparation += t1 - t0;

				unsigned short int periods = years * periods_per_year;
				vector<unsigned short int> no_of_active_nodes(N, 0); //initial active nodes for the period 0
				ListGraph::NodeMap<bool> active_nodes(g);
				ListDigraph::NodeMap<bool> active_nodes_original(g_original);
				for (unsigned short int i = 0; i < N; i++) {
					no_of_active_nodes[i] = Vp[i] / 4;
					for (unsigned short int j = Vp_start[i]; j < Vp_start[i + 1]; j++) {
						active_nodes[c[j]] = false;
						active_nodes[c_b[j]] = false;
						active_nodes_original[c_original[j]] = false;
					}
				}
				//read the seed
				string line_seed;
				ifstream seed_doc;
				std::cout << "start reading the seed doc" << endl;
				seed_doc.open("/seeds/n" + to_string(N) + "inst" + to_string(inst) + ".txt");
				getline(seed_doc, line_seed);
				seed_doc.close();
				unsigned int seed = 0;
				seed = stoi(line_seed);
				srand(seed);

				// determine starting pairs and arrival times of others
				initial_pairs(Vp_start, N, active_nodes, active_nodes_original, c, c_b, c_original, active_source, source_set);
				vector<unsigned short int> node_arrives(no_of_nodes, 0);
				arrival_times(node_arrives, Vp_start, N, active_nodes, c, periods);
				t1 = cpuTime();
				double rand_time = t1 - t0;


				t0 = cpuTime();
				ListGraph::EdgeMap<double> edge_card_weight(g, 0);
				ListDigraph::ArcMap<unsigned short int> arc_card_weight(g_original, 0);
				// build the graph
				undi_lemon(m, arc_in, arc_out, label_positions, g, g_original, c, c_b, c_original, edge_card_weight, arc_card_weight, no_of_nodes);
				t1 = cpuTime();
				graph_building += t1 - t0;

				vector<double> v_impu(N, 0);
				vector<double> v(N + 1, 0);
				vector<double> v_S(S, 0);
				vector<unsigned short int> s(N, 0);
				vector<vector<unsigned short int>> actual_alloc_d1C(periods, vector<unsigned short int>(N, 0));
				vector<vector<unsigned short int>> actual_alloc_d1(periods, vector<unsigned short int>(N, 0));
				vector<vector<unsigned short int>> actual_alloc_rand(periods, vector<unsigned short int>(N, 0));
				double prec = pow(10, -7);
				vector<double> target(N, 0);
				vector<vector<double>> init_alloc_d1C(periods, vector<double>(N, 0));
				vector<vector<double>> init_alloc_d1(periods, vector<double>(N, 0));
				vector<vector<double>> init_alloc_rand(periods, vector<double>(N, 0));
				vector<double> credit(N, 0);
				vector<bool> leaving(no_of_nodes, false);
				unsigned short int Q = 0;


				//set the active nodes for the period 0
				period_0(Q, no_of_active_nodes, N, s, Vp_start, node_arrives, active_nodes, active_nodes_original, c, c_b, c_original, credit, leaving, active_source, source_set);

				vector<pair<int, int>> arc_pair;
				vector<vector<unsigned short int>> actual_alloc;
				vector<int> nodeset(2000, 0);
				vector<double> d(N, 0);
				double d_total = 0;
				double d_c_total = 0;
				double max_d = 0;

				//------------arbitray maximum cycle packing----------------
				if (arbitrary) {
					std::cout << N << "countries" << " " << "instance_" << inst << "starts arbitrary" << endl;
					arbitray_maximum = true;
					period_0(Q, no_of_active_nodes, N, s, Vp_start, node_arrives, active_nodes, active_nodes_original, c, c_b, c_original, credit, leaving, active_source, source_set);
					t0 = cpuTime();
					arbitraryMaximum(node_arrives, g, g_original, arc_pair, leaving, active_nodes, active_nodes_original, c, c_b, c_original, disp, no_of_active_nodes, N, Vp_start, periods, dispy, s, Q, v, target_omega, target, credit, edge_card_weight, t0, actual_alloc, v_impu, nodeset, d, M_total, d_total, c_involved, numofMaxSolution, arbitray_maximum, v_S, S, core_100, negative_core, inst, max_d, game_generation_arbitrary, solution_concept_time_arbitrary, average_d_period[0], active_source, source_set, allo, node_set, label_positions, arc_in, arc_out, relative_d1_arbitrary, cycle_dis, track_not_optimal[0], track_time_limit[0], relative_optimal[0]);
					t1 = cpuTime();
					total_time_arbitrary += t1 - t0;
					arbitray_maximum = false;
					M_100_d_arbitrary += M_total;
					//core_d_arbitrary += core_100;
					//negative_core_d_arbitrary += negative_core;
					max_d1_arbitrary += max_d;
					std::cout << N << "countries" << " " << "instance_" << inst << "arbitrary done...";
				}
				//---------d1----------
				if (d1) {
					std::cout << N << "countries" << " " << "instance_" << inst << "starts d1" << endl;
					period_0(Q, no_of_active_nodes, N, s, Vp_start, node_arrives, active_nodes, active_nodes_original, c, c_b, c_original, credit, leaving, active_source, source_set);
					t0 = cpuTime();
					min_d_1(node_arrives, g, g_original, arc_pair, leaving, active_nodes, active_nodes_original, c, c_b, c_original, disp, no_of_active_nodes, N, Vp_start, periods, dispy, s, Q, v, target_omega, target, credit, edge_card_weight, t0, actual_alloc, v_impu, nodeset, d, M_total, d_total, c_involved, numofMaxSolution, arbitray_maximum, v_S, S, core_100, negative_core, d_c_total, inst, lex_min, max_d, game_generation_d1, solution_concept_time_d1, time_d1, active_source, source_set, allo, node_set, label_positions, arc_in, arc_out, mipgap, lb, ub, cycle_dis, track_not_optimal[1], track_time_limit[1], relative_d1, relative_optimal[1], average_d_period[1]);
					t1 = cpuTime();
					total_time_d1 += t1 - t0;
					cout << "total_time_d1: " << total_time_d1 << endl;
					max_d1 += max_d;
					std::cout << "relative_d1: " << relative_d1 << endl;
					std::cout << "the number of countries: " << N << " " << "relative_d1" << " " << inst << " " << relative_d1 / (inst + 1) << endl;
					M_100 += M_total;
					std::cout << "the number of countries: " << N << " " << "relative_d1" << " " << inst << " " << M_100 / (inst + 1);
					std::cout << N << "countries" << " " << "instance_" << inst << "d1 done...";
				}

				// -----------d1+c----------------
				if (d_c) {
					std::cout << N << "countries" << " " << "instance_" << inst << "starts d1+c" << endl;
					c_involved = true;
					period_0(Q, no_of_active_nodes, N, s, Vp_start, node_arrives, active_nodes, active_nodes_original, c, c_b, c_original, credit, leaving, active_source, source_set);
					t0 = cpuTime();
					min_d_1(node_arrives, g, g_original, arc_pair, leaving, active_nodes, active_nodes_original, c, c_b, c_original, disp, no_of_active_nodes, N, Vp_start, periods, dispy, s, Q, v, target_omega, target, credit, edge_card_weight, t0, actual_alloc, v_impu, nodeset, d, M_total, d_total, c_involved, numofMaxSolution, arbitray_maximum, v_S, S, core_100, negative_core, d_c_total, inst, lex_min, max_d, game_generation_d1_c, solution_concept_time_d1_c, time_d1_c, active_source, source_set, allo, node_set, label_positions, arc_in, arc_out, mipgap, lb, ub, cycle_dis, track_not_optimal[2], track_time_limit[2], relative_d1_c, relative_optimal[2], average_d_period[2]);
					t1 = cpuTime();
					total_time_d1_c += t1 - t0;
					c_involved = false;
					M_100_d_c += M_total;
					max_d1_c += max_d;
					std::cout << N << "countries" << " " << "instance_" << inst << "d1+c done...";
				}

				//-----------------lexmin-----------------
				if (lexmin_call) {
					std::cout << N << "countries" << " " << "instance_" << inst << "lexmin starts...";
					lex_min = true;
					period_0(Q, no_of_active_nodes, N, s, Vp_start, node_arrives, active_nodes, active_nodes_original, c, c_b, c_original, credit, leaving, active_source, source_set);
					t0 = cpuTime();
					min_d_1(node_arrives, g, g_original, arc_pair, leaving, active_nodes, active_nodes_original, c, c_b, c_original, disp, no_of_active_nodes, N, Vp_start, periods, dispy, s, Q, v, target_omega, target, credit, edge_card_weight, t0, actual_alloc, v_impu, nodeset, d, M_total, d_total, c_involved, numofMaxSolution, arbitray_maximum, v_S, S, core_100, negative_core, d_c_total, inst, lex_min, max_d, game_generation_lexmin, solution_concept_time_lexmin, time_lex_min, active_source, source_set, allo, node_set, label_positions, arc_in, arc_out, mipgap, lb, ub, cycle_dis, track_not_optimal[3], track_time_limit[3], relative_lexmin_0, relative_optimal[3], average_d_period[3]);
					t1 = cpuTime();
					total_time_lex_min += t1 - t0;
					max_lexmin_0 += max_d;
					lex_min = false;
					M_lex_min += M_total;
					std::cout << N << "countries" << " " << "instance_" << inst << "relative deviation" << d_total / M_total << "lexmin done...";
				}
				//-----------------lexmin+c----------------
				if (lexmin_c_call) {
					std::cout << N << "countries" << " " << "instance_" << inst << "lexmin+c starts...";
					lex_min = true;
					c_involved = true;
					period_0(Q, no_of_active_nodes, N, s, Vp_start, node_arrives, active_nodes, active_nodes_original, c, c_b, c_original, credit, leaving, active_source, source_set);
					t0 = cpuTime();
					min_d_1(node_arrives, g, g_original, arc_pair, leaving, active_nodes, active_nodes_original, c, c_b, c_original, disp, no_of_active_nodes, N, Vp_start, periods, dispy, s, Q, v, target_omega, target, credit, edge_card_weight, t0, actual_alloc, v_impu, nodeset, d, M_total, d_total, c_involved, numofMaxSolution, arbitray_maximum, v_S, S, core_100, negative_core, d_c_total, inst, lex_min, max_d, game_generation_lexmin_c, solution_concept_time_lexmin_c, time_lex_min_c, active_source, source_set, allo, node_set, label_positions, arc_in, arc_out, mipgap, lb, ub, cycle_dis, track_not_optimal[4], track_time_limit[4], relative_lexmin_c_0, relative_optimal[4], average_d_period[4]);
					t1 = cpuTime();
					total_time_lex_min_c += t1 - t0;
					max_lexmin_c_0 += max_d;
					lex_min = false;
					c_involved = false;
					M_lex_min_c += M_total;
					std::cout << N << "countries" << " " << "instance_" << inst << "relative deviation" << d_total / M_total << "lexmin+c done...";
				}
				for (int j = 0; j < mipgap.size(); j++) {
					mipgap_N[N - 4].push_back(mipgap[j]);
					lb_N[N - 4].push_back(lb[j]);
					ub_N[N - 4].push_back(ub[j]);
				}

			}
			cycle_dis_for_all[N - 4] = cycle_dis;
			relative_d1_N[N - 4] = relative_d1 / 100;
			relative_d1_N_c[N - 4] = relative_d1_c / 100;
			relative_arbitrary_N[N - 4] = relative_d1_arbitrary / 100;
			relative_lexmin[N - 4] = relative_lexmin_0 / 100;
			relative_lexmin_c[N - 4] = relative_lexmin_c_0 / 100;
			max_d1_N[N - 4] = max_d1 / 100;
			max_d1_N_c[N - 4] = max_d1_c / 100;
			max_arbitrary_N[N - 4] = max_d1_arbitrary / 100;
			max_lexmin[N - 4] = max_lexmin_0 / 100;
			max_lexmin_c[N - 4] = max_lexmin_c_0 / 100;
			M_N[N - 4] = M_100 / 100;
			M_N_d_c[N - 4] = M_100_d_c / 100;
			M_N_d_arbitrary[N - 4] = M_100_d_arbitrary / 100;
			M_N_lex_min[N - 4] = M_lex_min / 100;
			M_N_lex_min_c[N - 4] = M_lex_min_c / 100;
			data_preparation_N[N - 4] = data_preparation / 100;
			graph_building_N[N - 4] = graph_building / 100;
			game_generation_arbitrary_N[N - 4] = game_generation_arbitrary / 100;
			game_generation_d1_N[N - 4] = game_generation_d1 / 100;
			game_generation_d1_c_N[N - 4] = game_generation_d1_c / 100;
			game_generation_lexmin_N[N - 4] = game_generation_lexmin / 100;
			game_generation_lexmin_c_N[N - 4] = game_generation_lexmin_c / 100;
			time_arbitrary_N[N - 4] = time_arbitrary / 100;
			time_d1_N[N - 4] = time_d1 / 100;
			time_d1_c_N[N - 4] = time_d1_c / 100;
			time_lex_min_N[N - 4] = time_lex_min / 100;
			time_lex_min_c_N[N - 4] = time_lex_min_c / 100;
			total_time_arbitrary_N[N - 4] = total_time_arbitrary / 100;
			total_time_d1_N[N - 4] = total_time_d1 / 100;
			total_time_d1_c_N[N - 4] = total_time_d1_c / 100;
			total_time_lex_min_N[N - 4] = total_time_lex_min / 100;
			total_time_lex_min_c_N[N - 4] = total_time_lex_min_c / 100;
			solution_concept_time_arbitrary_N[N - 4] = solution_concept_time_arbitrary / 100;
			solution_concept_time_d1_N[N - 4] = solution_concept_time_d1 / 100;
			solution_concept_time_d1_c_N[N - 4] = solution_concept_time_d1_c / 100;
			solution_concept_time_lexmin_N[N - 4] = solution_concept_time_lexmin / 100;
			solution_concept_time_lexmin_c_N[N - 4] = solution_concept_time_lexmin_c / 100;
			ofstream res;
			res.open(version + "/" + cycle_length + "/" + country_size + "/inequal_results_l3_" + to_string(N) + ".txt", ofstream::out | ofstream::trunc);
			for (unsigned short int i = 0; i < N - 3; i++) {
				res << i + 4 << "countries" << endl;
				if (d1) {
					res << "data preparation: " << data_preparation_N[i] << endl;
					res << "build graph: " << graph_building_N[i] << endl;
					res << "minimizing d_1: " << relative_d1_N[i] << endl;
					res << "minimizing max_d_1: " << max_d1_N[i] << endl;
					res << "average number of transplants: " << M_N[i] << endl;
					res << "total time: " << total_time_d1_N[i] << endl;
					res << "scenario time: " << time_d1_N[i] << endl;
					res << "game generation: " << game_generation_d1_N[i] << endl;
					res << "solution concept: " << solution_concept_time_d1_N[i] << endl;

					res << "----------accumulated deviations-------------" << endl;
					for (int j = 0; j < 24; j++) {
						res << "round j:" << (double)average_d_period[1][i][j] / 100 << endl;
					}
					res << "------------not optimal------------------" << endl;
					int temp = 0;
					for (int k = 0; k < 100; k++) {
						if (track_not_optimal[1][i][k] != 0 && track_not_optimal[1][i][k] != 2) {
							temp++;
						}
					}
					res << "#not optimal:" << temp << endl;
					res << "---------" << i + 4 << " countries" << "---------" << endl;
					int track_temp = 0;
					for (int l : track_not_optimal[1][i]) {
						res << "inst: " << track_temp << ", " << l << endl;
						track_temp++;
					}

					res << "------------reach time limit------------------" << endl;
					int temp_0 = 0;
					for (int k = 0; k < 100; k++) {
						if (track_time_limit[1][i][k] != 0 && track_time_limit[1][i][k] != 2) {
							temp_0++;
						}
					}
					res << "#time limit:" << temp_0 << endl;
					res << "relative optimal ratio: " << (double)relative_optimal[1][i] / (100 - temp_0) << endl;
					res << "---------" << i + 4 << " countries" << "---------" << endl;
					int track_temp_0 = 0;
					for (int l : track_time_limit[1][i]) {
						res << "inst: " << track_temp_0 << ", " << l << endl;
						track_temp_0++;
					}
					res << "--------------cycle distribution---------------" << endl;
					map<int, int> temp_map;
					vector<map<int, int>> number_of_transplants(3, temp_map);
					for (int j = 0; j < 24; j++) {
						res << "--------------round " << j << "--------------" << endl;
						for (const auto& pair : cycle_dis_for_all[i][j]) {
							res << pair.first << " : " << pair.second << endl;
							number_of_transplants[2][pair.first] += pair.second;
							if (j == 0) {
								number_of_transplants[0][pair.first] = pair.second;
							}
							if (j < 4) {
								number_of_transplants[1][pair.first] += pair.second;
							}
						}
					}
					res << "---------------first round---------------" << endl;
					for (const auto& pair : number_of_transplants[0]) {
						res << pair.first << " : " << pair.second << endl;
					}
					res << "---------------first four rounds---------------" << endl;
					for (const auto& pair : number_of_transplants[1]) {
						res << pair.first << " : " << pair.second << endl;
					}
					res << "---------------across 24 rounds---------------" << endl;
					for (const auto& pair : number_of_transplants[2]) {
						res << pair.first << " : " << pair.second << endl;
					}
				}
				if (d_c) {
					res << "minimizing d_1_c: " << relative_d1_N_c[i] << endl;
					res << "minimizing max_d_1_c: " << max_d1_N_c[i] << endl;
					res << "average number of transplants_c: " << M_N_d_c[i] << endl;
					res << "total time: " << total_time_d1_c_N[i] << endl;
					res << "scenario time: " << time_d1_c_N[i] << endl;
					res << "game generation: " << game_generation_d1_c_N[i] << endl;
					res << "solution concept: " << solution_concept_time_d1_c_N[i] << endl;

					res << "----------accumulated deviations-------------" << endl;
					for (int j = 0; j < 24; j++) {
						res << "round j:" << (double)average_d_period[2][i][j] / 100 << endl;
					}

					res << "------------not optimal------------------" << endl;
					int temp = 0;
					for (int k = 0; k < 100; k++) {
						if (track_not_optimal[2][i][k] != 0 && track_not_optimal[2][i][k] != 2) {
							temp++;
						}
					}
					res << "#not optimal:" << temp << endl;
					res << "---------" << i + 4 << " countries" << "---------" << endl;
					int track_temp = 0;
					for (int l : track_not_optimal[2][i]) {
						res << "inst: " << track_temp << ", " << l << endl;
						track_temp++;
					}

					res << "------------reach time limit------------------" << endl;
					int temp_0 = 0;
					for (int k = 0; k < 100; k++) {
						if (track_time_limit[2][i][k] != 0 && track_time_limit[2][i][k] != 2) {
							temp_0++;
						}
					}
					res << "#time limit:" << temp_0 << endl;
					res << "relative optimal ratio: " << (double)relative_optimal[2][i] / (100 - temp_0) << endl;
					res << "---------" << i + 4 << " countries" << "---------" << endl;
					int track_temp_0 = 0;
					for (int l : track_time_limit[2][i]) {
						res << "inst: " << track_temp_0 << ", " << l << endl;
						track_temp_0++;
					}
					res << "--------------cycle distribution---------------" << endl;
					map<int, int> temp_map;
					vector<map<int, int>> number_of_transplants(3, temp_map);
					for (int j = 0; j < 24; j++) {
						res << "--------------round " << j << "--------------" << endl;
						for (const auto& pair : cycle_dis_for_all[i][j]) {
							res << pair.first << " : " << pair.second << endl;
							number_of_transplants[2][pair.first] += pair.second;
							if (j == 0) {
								number_of_transplants[0][pair.first] = pair.second;
							}
							if (j < 4) {
								number_of_transplants[1][pair.first] += pair.second;
							}
						}
					}
					res << "---------------first round---------------" << endl;
					for (const auto& pair : number_of_transplants[0]) {
						res << pair.first << " : " << pair.second << endl;
					}
					res << "---------------first four rounds---------------" << endl;
					for (const auto& pair : number_of_transplants[1]) {
						res << pair.first << " : " << pair.second << endl;
					}
					res << "---------------across 24 rounds---------------" << endl;
					for (const auto& pair : number_of_transplants[2]) {
						res << pair.first << " : " << pair.second << endl;
					}
				}
				if (arbitrary) {
					res << "minimizing d_1_arbitrary: " << relative_arbitrary_N[i] << endl;
					res << "minimizing max_d_1_arbitrary: " << max_arbitrary_N[i] << endl;
					res << "average number of transplants_arbitrary: " << M_N_d_arbitrary[i] << endl;
					res << "total time: " << total_time_arbitrary_N[i] << endl;
					res << "scenario time: " << time_arbitrary_N[i] << endl;
					res << "game generation: " << game_generation_arbitrary_N[i] << endl;
					res << "solution concept: " << solution_concept_time_arbitrary_N[i] << endl;
					res << "----------accumulated deviations-------------" << endl;
					for (int j = 0; j < 24; j++) {
						res << "round j:" << (double)average_d_period[0][i][j] / 100 << endl;
					}
					res << "------------not optimal------------------" << endl;
					int temp = 0;
					for (int k = 0; k < 100; k++) {
						if (track_not_optimal[0][i][k] != 0 && track_not_optimal[0][i][k] != 2) {
							temp++;
						}
					}
					res << "#not optimal:" << temp << endl;
					res << "---------" << i + 4 << " countries" << "---------" << endl;
					int track_temp = 0;
					for (int l : track_not_optimal[0][i]) {
						res << "inst: " << track_temp << ", " << l << endl;
						track_temp++;
					}

					res << "------------reach time limit------------------" << endl;
					int temp_0 = 0;
					for (int k = 0; k < 100; k++) {
						if (track_time_limit[0][i][k] != 0 && track_time_limit[0][i][k] != 2) {
							temp_0++;
						}
					}
					res << "#time limit:" << temp_0 << endl;
					res << "relative optimal ratio: " << (double)relative_optimal[0][i] / (100 - temp_0) << endl;
					res << "---------" << i + 4 << " countries" << "---------" << endl;
					int track_temp_0 = 0;
					for (int l : track_time_limit[0][i]) {
						res << "inst: " << track_temp_0 << ", " << l << endl;
						track_temp_0++;
					}
					res << "--------------cycle distribution---------------" << endl;
					map<int, int> temp_map;
					vector<map<int, int>> number_of_transplants(3, temp_map);
					for (int j = 0; j < 24; j++) {
						res << "--------------round " << j << "--------------" << endl;
						for (const auto& pair : cycle_dis_for_all[i][j]) {
							res << pair.first << " : " << pair.second << endl;
							number_of_transplants[2][pair.first] += pair.second;
							if (j == 0) {
								number_of_transplants[0][pair.first] = pair.second;
							}
							if (j < 4) {
								number_of_transplants[1][pair.first] += pair.second;
							}
						}
					}
					res << "---------------first round---------------" << endl;
					for (const auto& pair : number_of_transplants[0]) {
						res << pair.first << " : " << pair.second << endl;
					}
					res << "---------------first four rounds---------------" << endl;
					for (const auto& pair : number_of_transplants[1]) {
						res << pair.first << " : " << pair.second << endl;
					}
					res << "---------------across 24 rounds---------------" << endl;
					for (const auto& pair : number_of_transplants[2]) {
						res << pair.first << " : " << pair.second << endl;
					}
				}
				if (lexmin_call) {
					res << "lex min " << relative_lexmin[i] << endl;
					res << "lex min max d " << max_lexmin[i] << endl;
					res << "average number of transplants: " << M_N_lex_min[i] << endl;
					res << "total time: " << total_time_lex_min_N[i] << endl;
					res << "scenario time: " << time_lex_min_N[i] << endl;
					res << "game generation: " << game_generation_lexmin_N[i] << endl;
					res << "solution concept: " << solution_concept_time_lexmin_N[i] << endl;

					res << "----------accumulated deviations-------------" << endl;
					for (int j = 0; j < 24; j++) {
						res << "round j:" << (double)average_d_period[3][i][j] / 100 << endl;
					}

					res << "------------not optimal------------------" << endl;
					int temp = 0;
					for (int k = 0; k < 100; k++) {
						if (track_not_optimal[3][i][k] != 0 && track_not_optimal[3][i][k] != 2) {
							temp++;
						}
					}
					res << "#not optimal:" << temp << endl;
					res << "---------" << i + 4 << " countries" << "---------" << endl;
					int track_temp = 0;
					for (int l : track_not_optimal[3][i]) {
						res << "inst: " << track_temp << ", " << l << endl;
						track_temp++;
					}

					res << "------------reach time limit------------------" << endl;
					int temp_0 = 0;
					for (int k = 0; k < 100; k++) {
						if (track_time_limit[3][i][k] != 0 && track_time_limit[3][i][k] != 2) {
							temp_0++;
						}
					}
					res << "#time limit:" << temp_0 << endl;
					res << "relative optimal ratio: " << (double)relative_optimal[3][i] / (100 - temp_0) << endl;
					res << "---------" << i + 4 << " countries" << "---------" << endl;
					int track_temp_0 = 0;
					for (int l : track_time_limit[3][i]) {
						res << "inst: " << track_temp_0 << ", " << l << endl;
						track_temp_0++;
					}
					res << "--------------cycle distribution---------------" << endl;
					map<int, int> temp_map;
					vector<map<int, int>> number_of_transplants(3, temp_map);
					for (int j = 0; j < 24; j++) {
						res << "--------------round " << j << "--------------" << endl;
						for (const auto& pair : cycle_dis_for_all[i][j]) {
							res << pair.first << " : " << pair.second << endl;
							number_of_transplants[2][pair.first] += pair.second;
							if (j == 0) {
								number_of_transplants[0][pair.first] = pair.second;
							}
							if (j < 4) {
								number_of_transplants[1][pair.first] += pair.second;
							}
						}
					}
					res << "---------------first round---------------" << endl;
					for (const auto& pair : number_of_transplants[0]) {
						res << pair.first << " : " << pair.second << endl;
					}
					res << "---------------first four rounds---------------" << endl;
					for (const auto& pair : number_of_transplants[1]) {
						res << pair.first << " : " << pair.second << endl;
					}
					res << "---------------across 24 rounds---------------" << endl;
					for (const auto& pair : number_of_transplants[2]) {
						res << pair.first << " : " << pair.second << endl;
					}
				}
				if (lexmin_c_call) {
					res << "lex min+c " << relative_lexmin_c[i] << endl;
					res << "lex min+c max " << max_lexmin_c[i] << endl;
					res << "average number of transplants: " << M_N_lex_min_c[i] << endl;
					res << "total time: " << total_time_lex_min_c_N[i] << endl;
					res << "scenario time: " << time_lex_min_c_N[i] << endl;
					res << "game generation: " << game_generation_lexmin_c_N[i] << endl;
					res << "solution concept: " << solution_concept_time_lexmin_c_N[i] << endl;

					res << "----------accumulated deviations-------------" << endl;
					for (int j = 0; j < 24; j++) {
						res << "round j:" << (double)average_d_period[4][i][j] / 100 << endl;
					}

					res << "------------not optimal------------------" << endl;
					int temp = 0;
					for (int k = 0; k < 100; k++) {
						if (track_not_optimal[4][i][k] != 0 && track_not_optimal[4][i][k] != 2) {
							temp++;
						}
					}
					res << "#not optimal:" << temp << endl;
					res << "---------" << i + 4 << " countries" << "---------" << endl;
					int track_temp = 0;
					for (int l : track_not_optimal[4][i]) {
						res << "inst: " << track_temp << ", " << l << endl;
						track_temp++;
					}

					res << "------------reach time limit------------------" << endl;
					int temp_0 = 0;
					for (int k = 0; k < 100; k++) {
						if (track_time_limit[4][i][k] != 0 && track_time_limit[4][i][k] != 2) {
							temp_0++;
						}
					}
					res << "#time limit:" << temp_0 << endl;
					res << "relative optimal ratio: " << (double)relative_optimal[4][i] / (100 - temp_0) << endl;
					res << "---------" << i + 4 << " countries" << "---------" << endl;
					int track_temp_0 = 0;
					for (int l : track_time_limit[4][i]) {
						res << "inst: " << track_temp_0 << ", " << l << endl;
						track_temp_0++;
					}
					res << "--------------cycle distribution---------------" << endl;
					map<int, int> temp_map;
					vector<map<int, int>> number_of_transplants(3, temp_map);
					for (int j = 0; j < 24; j++) {
						res << "--------------round " << j << "--------------" << endl;
						for (const auto& pair : cycle_dis_for_all[i][j]) {
							res << pair.first << " : " << pair.second << endl;
							number_of_transplants[2][pair.first] += pair.second;
							if (j == 0) {
								number_of_transplants[0][pair.first] = pair.second;
							}
							if (j < 4) {
								number_of_transplants[1][pair.first] += pair.second;
							}
						}
					}
					res << "---------------first round---------------" << endl;
					for (const auto& pair : number_of_transplants[0]) {
						res << pair.first << " : " << pair.second << endl;
					}
					res << "---------------first four rounds---------------" << endl;
					for (const auto& pair : number_of_transplants[1]) {
						res << pair.first << " : " << pair.second << endl;
					}
					res << "---------------across 24 rounds---------------" << endl;
					for (const auto& pair : number_of_transplants[2]) {
						res << pair.first << " : " << pair.second << endl;
					}
				}

				res << endl;
			}

			res.close();

			//lower and upper bounds
			ofstream res_bounds;
			res_bounds.open(version + "/inequal_lower_and_uppper_bounds_l3.txt", ofstream::out | ofstream::trunc);
			res_bounds << version << endl;
			for (unsigned short int i = 0; i < N - 3; i++) {
				res_bounds << i + 4 << "countries" << endl;
				for (int j = 0; j < mipgap_N[i].size(); j++) {
					res_bounds << "mipgap:" << mipgap[j] << ", lb:" << lb[j] << ", ub:" << ub[j] << endl;
				}
			}
			res_bounds.close();




		}

	}
	catch (GRBException e) {
		std::cout << "Error code = " << e.getErrorCode() << endl;
		std::cout << e.getMessage() << endl;
	}
	catch (...) {
		std::cout << "Exception during optimization" << endl;
	}
	return 0;
}




void coop_game(ListGraph& g, vector<double>& v, vector<double>& v_impu, vector<double>& v_S, unsigned int& S, vector<unsigned short int>& s, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, ListGraph::EdgeMap<double>& edge_card_weight, bool& dispy, vector<unsigned short int>& Vp_start, unsigned short int& N, ListGraph::NodeMap<bool>& active_nodes, vector<bool>& leaving, map<int, int>& numofMaxSolution, unsigned short int& Q, bool& arbitray_maximum, double& game_generation, Allocation& allo, set<int>& active_source, vector<int>& source_set, vector<int>& node_set, vector<unsigned short int>& label_positions, vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, vector<map<int, int>>& cycle_dis, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, unsigned short int inst) {
	//s.clear();
	vector<bool> a(N, false);
	double t0 = cpuTime();
	bool is_cycle_dis = false;
	if (arbitray_maximum) {
		is_cycle_dis = true;
	}
	v[N] = solve_obj(allo, active_source, node_set, label_positions, track_not_optimal, track_time_limit, cycle_dis, is_cycle_dis, Q, inst, N);
	is_cycle_dis = false;
	if (arbitray_maximum) {
		for (int i : node_set) {
			for (int j = 0; j < N; j++) {
				if (Vp_start[j] <= label_positions[i] && label_positions[i] < Vp_start[j + 1]) {
					//cout << "label_positions[i]: " << label_positions[i] << ";" << "between " << j * Vp << " and " << (j + 1) * Vp << endl;
					s[j]++;
					leaving[label_positions[i]] = true;
				}
			}
		}
	}
	cout << "-----------actual allocations--------------" << endl;
	/*for (int i : s) {
		cout << i << endl;
	}*/
	cout << "v[N]: " << v[N] << endl;
	vector<int> node_set_temp_1, node_set_temp_2;
	vector<int> source_set_temp_1, source_set_temp_2;
	Allocation allo_temp_1, allo_temp_2;
	allo_temp_1.load(arc_in, arc_out, source_set_temp_1);
	allo_temp_2.load(arc_in, arc_out, source_set_temp_1);
	cout << "size of pairs: " << allo_temp_1.nbPairs << endl;
	set<int> active_source_temp_1, active_source_temp_2;
	vector<int> temp_1(N, 0), temp_2(N, 0);
	for (unsigned int i = 0; i < N; i++) {
		active_source_temp_1.clear();
		//ListDigraph::NodeMap<bool> coal1_original(g_original, false);
		for (unsigned short int k = Vp_start[i]; k < Vp_start[i + 1]; k++) {
			if (active_nodes[c[k]]) {
				active_source_temp_1.insert(source_set[k]);
			}
		}

		v_impu[i] = solve_obj(allo, active_source_temp_1, node_set_temp_1, label_positions, track_not_optimal, track_time_limit, cycle_dis, is_cycle_dis, Q, inst, N);
		temp_1.push_back(active_source_temp_1.size());
		std::cout << "finish generating v_impu" << endl;
		active_source_temp_2.clear();
		for (unsigned int j = 0; j < N; j++) {
			if (i != j) {
				for (unsigned short int k = Vp_start[j]; k < Vp_start[j + 1]; k++) {
					if (active_nodes[c[k]]) {
						active_source_temp_2.insert(source_set[k]);
					}
				}
			}
		}


		//MaxWeightedPerfectMatching<FilterNodes<ListGraph>> coal_m2(g, coal2);
		v[i] = solve_obj(allo, active_source_temp_2, node_set_temp_2, label_positions, track_not_optimal, track_time_limit, cycle_dis, is_cycle_dis, Q, inst, N);
		temp_2.push_back(active_source_temp_2.size());
		std::cout << "finish generating v_i" << endl;

	}


	std::cout << "finish generating the copy" << endl;
	double t1 = cpuTime();
	std::cout << "Time in game generation " << t1 - t0 << endl;
	game_generation += t1 - t0;
	for (int i = 0; i < N; i++) {
		cout << "v_impu[i]: " << v_impu[i] << " v[i]:" << v[i] << endl;
		cout << "active source size 1: " << temp_1[i] << " active source size 2: " << temp_2[i] << endl;;
	}
	cout << active_source_temp_1.size() << " " << active_source_temp_2.size() << endl;
	//for (int i : active_source_temp_1) { cout << i << endl; }
	//for (int j : active_source_temp_2) { cout << j << endl; }
	cout << "v[N]: " << v[N] << endl;
	std::cout << "finish generating v[N]" << endl;





	if (dispy)
		std::cout << "grand coal: " << v[N] << endl;

	if (dispy) {
		std::cout << "s: ";
		for (unsigned short int i = 0; i < N; i++) {
			std::cout << s[i] << " " << endl;
		}
	}
	return;
}

void min_d_1(vector<unsigned short int>& node_arrives, ListGraph& g, ListDigraph& g_original, vector<pair<int, int>>& arc_pair, vector<bool>& leaving, ListGraph::NodeMap<bool>& active_nodes, ListDigraph::NodeMap<bool>& active_nodes_original, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, bool& disp, vector<unsigned short int>& no_of_active_nodes, unsigned short int& N, vector<unsigned short int>& Vp_start, unsigned short int& periods, bool& dispy, vector<unsigned short int>& s, unsigned short int& Q, vector<double>& v, bool& target_omega, vector<double>& target, vector<double>& credit, ListGraph::EdgeMap<double>& edge_card_weight, double& t0, vector<vector<unsigned short int>>& actual_alloc, vector<double>& v_impu, vector<int>& nodeset, vector<double>& d, double& M_total, double& d_total, bool& c_involved, map<int, int>& numofMaxSolution, bool& arbitray_maximum, vector<double>& v_S, unsigned int& S, double& core_100, long& negative_core, double& d_c_total, unsigned short int inst, bool lex_min, double& max_d, double& game_generation, double& solution_concept_time, double& scenario_time, set<int>& active_source, vector<int>& source_set, Allocation& allo, vector<int>& node_set, vector<unsigned short int>& label_positions, vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, vector<double>& mipgap, vector<double>& lb, vector<double>& ub, vector<map<int, int>>& cycle_dis, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, double& relative_deviation, vector<double>& relative_optimal, vector<vector<double>>& average_d_period) {
	Q = 0;
	d_total = 0;
	d_c_total = 0;
	M_total = 0;
	core_100 = 0;
	negative_core = 0;
	max_d = 0;
	if (dispy)
		std::cout << " --== Without lex min matching == -- " << endl;
	active_source.clear();
	for (unsigned short int i = 0; i < N; i++) {
		d[i] = 0;
		s[i] = 0;
		credit[i] = 0;
		no_of_active_nodes[i] = (Vp_start[i + 1] - Vp_start[i]) / 4;
		for (unsigned short int j = Vp_start[i]; j < Vp_start[i + 1]; j++) {
			if (node_arrives[j] == 0) {
				active_nodes[c[j]] = true;
				active_nodes[c_b[j]] = true;
				active_nodes_original[c_original[j]] = true;
				active_source.insert(source_set[j]);
			}
			else {
				active_nodes[c[j]] = false;
				active_nodes[c_b[j]] = false;
				active_nodes_original[c_original[j]] = false;
			}
		}
	}
	cout << "size of the subgraph in the first period" << active_source.size() << endl;



	while (Q < periods) {
		if (dispy) {
			std::cout << "--== PERIOD " << Q + 1 << " ==--" << endl;
		}
		if (dispy) {
			std::cout << "Number of active nodes: ";
			for (unsigned short int i = 0; i < N; i++)
				std::cout << no_of_active_nodes[i] << " ";
			std::cout << endl;
		}
		// cooperative game and target
		std::cout << "start generating values" << endl;
		coop_game(g, v, v_impu, v_S, S, s, c, c_b, edge_card_weight, dispy, Vp_start, N, active_nodes, leaving, numofMaxSolution, Q, arbitray_maximum, game_generation, allo, active_source, source_set, node_set, label_positions, arc_in, arc_out, cycle_dis, track_not_optimal, track_time_limit, inst);
		double t0 = cpuTime();
		double suma = 0;
		double sumimpu = 0;
		if (target_omega) {
			for (unsigned short int i = 0; i < N; i++) {
				suma += v[N] - v[i] - v_impu[i];
				sumimpu += v_impu[i];
			}
			for (unsigned short int i = 0; i < N; i++)
				target[i] = v_impu[i] + (v[N] - sumimpu) * ((v[N] - v[i] - v_impu[i]) / suma);
		}
		else {
			for (unsigned short int i = 0; i < N; i++) {
				suma += v[N] - v[i];
				sumimpu += v_impu[i];
			}
			for (unsigned short int i = 0; i < N; i++)
				target[i] = v_impu[i] + (v[N] - sumimpu) * ((v[N] - v[i]) / suma);
		}
		double t1 = cpuTime();
		solution_concept_time += t1 - t0;

		if (suma > 0) {
			cout << "denominator>0" << endl;
		}
		else {
			ofstream res_denominator;
			res_denominator << N << " countries" << " " << "instance_" << inst << " round_" << Q << endl;
			res_denominator.close();
		}
		//init_alloc[Q] = target;
		if (dispy) {
			if (target_omega) {
				std::cout << "Benefit: ";
			}
			else {
				std::cout << "Contribution: ";
			}
			for (unsigned short int i = 0; i < N; i++) {
				std::cout << target[i] << " ";
			}
			std::cout << endl;
		}
		t0 = cpuTime();
		ILP_d1_gurobi(Q, N, g_original, Vp_start, node_arrives, active_nodes, active_nodes_original, arc_pair, nodeset, actual_alloc, v[N], M_total, s, target, leaving, d, d_total, c_involved, credit, lex_min, inst, allo, active_source, node_set, label_positions, mipgap, lb, ub, track_not_optimal, track_time_limit, cycle_dis, average_d_period);
		t1 = cpuTime();
		scenario_time += t1 - t0;
		Q++;
		changing_nodes(active_nodes, active_nodes_original, leaving, no_of_active_nodes, N, Vp_start, node_arrives, Q, c, c_b, c_original, s, d, target, active_source, source_set);
		if (dispy)
			cin.get();
	}
	for (unsigned short int i = 0; i < N; ++i) {
		d_total += abs(d[i]);
		if (c_involved) {
			d_c_total += abs(credit[i]);
		}
	}
	vector<double> max_deviation(N, 0);
	for (unsigned short int i = 0; i < N; ++i) {
		max_deviation[i] = abs(d[i]) / (M_total);
	}
	std::sort(max_deviation.begin(), max_deviation.end());
	max_d = max_deviation[N - 1];
	relative_deviation += d_total / (M_total);
	if (track_time_limit[N - 4][inst] != 9) {
		relative_optimal[N - 4] += d_total / (M_total);

	}
	return;
}

void changing_nodes(ListGraph::NodeMap<bool>& active_nodes, ListDigraph::NodeMap<bool>& active_nodes_original, vector<bool>& leaving, vector<unsigned short int>& no_of_active_nodes, unsigned short int& N, vector<unsigned short int>& Vp_start, vector<unsigned short int>& node_arrives, unsigned short int& Q, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, vector<unsigned short int>& s, vector<double>& d, vector<double>& target, set<int>& active_source, vector<int>& source_set) {
	for (unsigned short int i = 0; i < N; i++) {
		s[i] = 0;
		target[i] = 0;
		for (unsigned short int j = Vp_start[i]; j < Vp_start[i + 1]; j++) {
			if (leaving[j]) {
				active_nodes[c[j]] = false;
				active_nodes[c_b[j]] = false;
				active_nodes_original[c_original[j]] = false;
				if (active_source.find(source_set[j]) == active_source.end()) {
					throw std::invalid_argument("node does not exist!!");
				}
				active_source.erase(source_set[j]);
				no_of_active_nodes[i]--;
				leaving[j] = false;

			}
			else {
				if (active_nodes[c[j]] && node_arrives[j] == Q - 4) {
					active_nodes[c[j]] = false;
					active_nodes[c_b[j]] = false;
					active_nodes_original[c_original[j]] = false;
					if (active_source.find(source_set[j]) == active_source.end()) {
						throw std::invalid_argument("node does not exist!!");
					}
					active_source.erase(source_set[j]);
					no_of_active_nodes[i]--;
				}
			}
			if (node_arrives[j] == Q) {
				active_nodes[c[j]] = true;
				active_nodes[c_b[j]] = true;
				active_nodes_original[c_original[j]] = true;
				if (active_source.find(source_set[j]) != active_source.end()) {
					throw std::invalid_argument("node already exists!!");
				}
				active_source.insert(source_set[j]);
				no_of_active_nodes[i]++;
			}
		}
	}
	return;
}

void initial_pairs(vector<unsigned short int>& Vp_start, unsigned short int& N, ListGraph::NodeMap<bool>& active_nodes, ListDigraph::NodeMap<bool>& active_nodes_original, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, set<int>& active_source, vector<int>& source_set) {
	unsigned short int coal = rand() % (Vp_start[1] - Vp_start[0]);
	unsigned short int count = 0;
	active_source.clear();
	for (unsigned short int i = 0; i < N; i++) {
		while (count < (Vp_start[i + 1] - Vp_start[i]) / 4) {
			if (active_nodes[c[Vp_start[i] + coal]]) {
				coal = rand() % (Vp_start[i + 1] - Vp_start[i]);
			}
			else {
				active_nodes[c[Vp_start[i] + coal]] = true;
				active_nodes[c_b[Vp_start[i] + coal]] = true;
				active_nodes_original[c_original[Vp_start[i] + coal]] = true;
				active_source.insert(source_set[Vp_start[i] + coal]);
				count++;
				coal = rand() % (Vp_start[i + 1] - Vp_start[i]);
			}
		}

		count = 0;
	}
	//cout << "initial size: " << active_source.size() << endl;
	//cout << "active source" << endl;
	/*for (int i : active_source) {
		cout << i << endl;
	}*/
}

void period_0(unsigned short int& Q, vector<unsigned short int>& no_of_active_nodes, unsigned short int& N, vector<unsigned short int>& s, vector<unsigned short int>& Vp_start, vector<unsigned short int>& node_arrives, ListGraph::NodeMap<bool>& active_nodes, ListDigraph::NodeMap<bool>& active_nodes_original, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, vector<double>& credit, vector<bool>& leaving, set<int>& active_source, vector<int>& source_set) {
	Q = 0;
	active_source.clear();
	for (unsigned short int i = 0; i < N; i++) {
		s[i] = 0;
		credit[i] = 0;
		no_of_active_nodes[i] = (Vp_start[i + 1] - Vp_start[i]) / 4;
		for (unsigned short int j = Vp_start[i]; j < Vp_start[i + 1]; j++) {
			leaving[j] = false;
			if (node_arrives[j] == 0) {
				active_nodes[c[j]] = true;
				active_nodes[c_b[j]] = true;
				active_nodes_original[c_original[j]] = true;
				active_source.insert(source_set[j]);
			}
			else {
				active_nodes[c[j]] = false;
				active_nodes[c_b[j]] = false;
				active_nodes_original[c_original[j]] = false;
			}
		}
	}
	//cout << "size of the subgraph" << active_source.size() << endl;
}

void arrival_times(vector<unsigned short int>& node_arrives, vector<unsigned short int>& Vp_start, unsigned short int& N, ListGraph::NodeMap<bool>& active_nodes, vector<ListGraph::Node>& c, unsigned short int& periods) {
	for (unsigned short int i = 0; i < N; i++) {
		for (unsigned short int j = Vp_start[i]; j < Vp_start[i + 1]; j++) {
			if (!(active_nodes[c[j]])) {
				node_arrives[j] = rand() % (periods - 1) + 1;
			}
		}
	}
	return;
}



void undi_lemon(unsigned int& m, vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, vector<unsigned short int>& label_positions, ListGraph& g, ListDigraph& g_original, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, ListGraph::EdgeMap<double>& edge_card_weight, ListDigraph::ArcMap<unsigned short int>& arc_card_weight, unsigned short int& no_of_nodes) {
	bool halt = false;
	for (int i = 0; i < no_of_nodes; i++) {
		ListGraph::Edge e = g.addEdge(c[i], c_b[i]);
		edge_card_weight[e] = 0;
	}
	for (unsigned int i = 0; i < m; i++) {
		if (label_positions[arc_in[i]] < no_of_nodes) { //XY: filter 65535 positions
			ListGraph::Edge e = g.addEdge(c[label_positions[arc_out[i]]], c_b[label_positions[arc_in[i]]]);
			edge_card_weight[e] = 1;
			ListDigraph::Arc a_original = g_original.addArc(c_original[label_positions[arc_out[i]]], c_original[label_positions[arc_in[i]]]);
			arc_card_weight[a_original] = 1;
		}
	}
	return;
}

void xml_parser(string& line, vector<unsigned short int>& node_labels, vector<unsigned short int>& label_positions, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, unsigned short int& k, ListGraph& g, ListDigraph& g_original, vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, unsigned int& m, unsigned short int& no_of_nodes) {
	unsigned int l = 6;
	unsigned short int n = 0; //XY: track the number of nodes
	while (l < line.size() - 7) {
		if (line[l] == '<' && line[l + 1] == 'e') {
			l = l + 17;
			n++;
			if (!is_next_char_digit(line, l)) {
				node_labels[n - 1] = char2uint(line[l]); //XY: donor id
			}
			else {
				if (!is_next_char_digit(line, l + 1)) {
					node_labels[n - 1] = 10 * char2uint(line[l]) + char2uint(line[l + 1]);
					l++;
				}
				else {
					if (!is_next_char_digit(line, l + 2)) {
						node_labels[n - 1] = 100 * char2uint(line[l]) + 10 * char2uint(line[l + 1]) + char2uint(line[l + 2]);
						l = l + 2;
					}
					else {
						node_labels[n - 1] = 1000 * char2uint(line[l]) + 100 * char2uint(line[l + 1]) + 10 * char2uint(line[l + 2]) + char2uint(line[l + 3]);
						l = l + 3;
					}
				}
			}
			if (n + k - 1 == node_labels[n - 1]) {
				label_positions[n + k - 1] = n - 1;
			}
			else {
				while (n + k - 1 < node_labels[n - 1]) {
					label_positions[n + k - 1] = 65535;
					label_positions.push_back(0);
					k++;
				}
				label_positions[n + k - 1] = n - 1;
			}

			c[n - 1] = g.addNode();//XY: add donor ids
			c_b[n - 1] = g.addNode();//changed by XY, add patient ids
			c_original[n - 1] = g_original.addNode();//changed by XY, add patient-donor pairs to the original graph
			l = l + 9;
			if (!is_next_char_digit(line, l)) {
				////donor_ages.push_back(char2uint(line[l]));
				//donor_ages[n - 1] = char2uint(line[l]);
			}
			else {
				if (!is_next_char_digit(line, l + 1)) {
					////donor_ages.push_back(10*char2uint(line[l])+char2uint(line[l+1]));
					//donor_ages[n - 1] = 10*char2uint(line[l])+char2uint(line[l+1]);
					l++;
				}
				else {
					if (!is_next_char_digit(line, l + 2)) {
						////donor_ages.push_back(100*char2uint(line[l])+10*char2uint(line[l+1])+char2uint(line[l+2]));
						//donor_ages[n - 1] = 100*char2uint(line[l])+10*char2uint(line[l+1])+char2uint(line[l+2]);
						l = l + 2;
					}
					else {
						////if (!is_next_char_digit(line, l + 3)){
						////donor_ages.push_back(1000*char2uint(line[l])+100*char2uint(line[l+1])+10*char2uint(line[l+2])+char2uint(line[l+3]));
						//donor_ages[n - 1] = 1000*char2uint(line[l])+100*char2uint(line[l+1])+10*char2uint(line[l+2])+char2uint(line[l+3]);
						l = l + 3;
						////}
					}
				}
			}
			l = l + 25;
			if (!is_next_char_digit(line, l)) {
				if (node_labels[n - 1] != char2uint(line[l]))
					std::cout << "ID ERROR!" << endl;
			}
			else {
				if (!is_next_char_digit(line, l + 1)) {
					if (node_labels[n - 1] != 10 * char2uint(line[l]) + char2uint(line[l + 1]))
						std::cout << "ID ERROR!" << endl;
					l++;
				}
				else {
					if (!is_next_char_digit(line, l + 2)) {
						if (node_labels[n - 1] != 100 * char2uint(line[l]) + 10 * char2uint(line[l + 1]) + char2uint(line[l + 2]))
							std::cout << "ID ERROR!" << endl;
						l = l + 2;
					}
					else {
						//if (!is_next_char_digit(line, l + 3)){
						if (node_labels[n - 1] != 1000 * char2uint(line[l]) + 100 * char2uint(line[l + 1]) + 10 * char2uint(line[l + 2]) + char2uint(line[l + 3]))
							std::cout << "ID ERROR!" << endl;
						l = l + 3;
						//}
					}
				}
			}
			if (line[l + 21] == 'm')
				l = l + 29;
			else
				l = l + 28;
		}
		// XY: recipients
		while (line[l] == '<' && line[l + 1] == 'm' && line[l + 6] == '>') {
			m++;//number of compatibilities
			l = l + 18;
			arc_out.push_back(node_labels[n - 1]);
			if (!is_next_char_digit(line, l)) {
				arc_in.push_back(char2uint(line[l]));
			}
			else {
				if (!is_next_char_digit(line, l + 1)) {
					arc_in.push_back(10 * char2uint(line[l]) + char2uint(line[l + 1]));
					l++;
				}
				else {
					if (!is_next_char_digit(line, l + 2)) {
						arc_in.push_back(100 * char2uint(line[l]) + 10 * char2uint(line[l + 1]) + char2uint(line[l + 2]));
						l = l + 2;
					}
					else {
						//if (!is_next_char_digit(line, l + 3)){
						arc_in.push_back(1000 * char2uint(line[l]) + 100 * char2uint(line[l + 1]) + 10 * char2uint(line[l + 2]) + char2uint(line[l + 3]));
						l = l + 3;
						//}
					}
				}
			}
			l = l + 20;
			if (!is_next_char_digit(line, l)) {
				//arc_weight.push_back(char2uint(line[l]));
			}
			else {
				if (!is_next_char_digit(line, l + 1)) {
					//arc_weight.push_back(10*char2uint(line[l])+char2uint(line[l+1]));
					l++;
				}
				else {
					if (!is_next_char_digit(line, l + 2)) {
						//arc_weight.push_back(100*char2uint(line[l])+10*char2uint(line[l+1])+char2uint(line[l+2]));
						l = l + 2;
					}
					else {
						////if (!is_next_char_digit(line, l + 3)){
						//arc_weight.push_back(1000*char2uint(line[l])+100*char2uint(line[l+1])+10*char2uint(line[l+2])+char2uint(line[l+3]));
						l = l + 3;
						////}
					}
				}
			}
			l = l + 17;
		}
		if (!(line[l] == '<' && line[l + 1] == 'e')) {
			l = l + 18;
		}
		if (n == no_of_nodes)
			break;
	}
	std::cout << "the number of nodes" << n;
	std::cout << "m: " << m << "\n";
	std::cout << "arc_in.size(): " << arc_in.size() << "\n" << " arc_out.size(): " << arc_out.size() << endl;
	return;
}

bool is_next_char_digit(string& line, unsigned int l) {
	if (line[l + 1] == '0' || line[l + 1] == '1' || line[l + 1] == '2' || line[l + 1] == '3' || line[l + 1] == '4' || line[l + 1] == '5' || line[l + 1] == '6' || line[l + 1] == '7' || line[l + 1] == '8' || line[l + 1] == '9')
		return true;
	return false;
}

unsigned int char2uint(char& p) {
	if (p == '1')
		return 1;
	else
		if (p == '2')
			return 2;
		else
			if (p == '3')
				return 3;
			else
				if (p == '4')
					return 4;
				else
					if (p == '5')
						return 5;
					else
						if (p == '6')
							return 6;
						else
							if (p == '7')
								return 7;
							else
								if (p == '8')
									return 8;
								else
									if (p == '9')
										return 9;
									else
										return 0;
}

double cpuTime() {
	return (double)clock() / CLOCKS_PER_SEC;
}



void ILP_d1_gurobi(unsigned short int& Q, unsigned short int& N, ListDigraph& g_original, vector<unsigned short int>& Vp_start, vector<unsigned short int>& node_arrives, ListGraph::NodeMap<bool>& active_nodes, ListDigraph::NodeMap<bool>& active_nodes_original, vector<pair<int, int>>& arc_pair, vector<int>& nodeset, vector<vector<unsigned short int>>& actual_alloc, double& M, double& M_total, vector<unsigned short int>& s, vector<double>& target, vector<bool>& leaving, vector<double>& d, double& d_total, bool& c_involved, vector<double>& credit, bool lex_min, unsigned short int inst, Allocation& allo, set<int>& active_source, vector<int>& node_set, vector<unsigned short int>& label_positions, vector<double>& mipgap, vector<double>& lb, vector<double>& ub, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, vector<map<int, int>>& cycle_dis, vector<vector<double>>& average_d_period) {

	M_total += M;
	//int node_number = countNodes(g_original);
	const unsigned short int row_num = N + 2 * nodeset.size() + 1;
	// Create an environment
	GRBEnv env = GRBEnv(true);
	env.set("LogFile", "mip_lexmin.log");
	env.set("OutputFlag", "0");

	env.start();
	allo.dynamic(active_source);
	node_set.clear();
	// Local variables
	GRBModel model = GRBModel(env);
	model.set("TimeLimit", "3600");
	vector<GRBModel> vector_model(2 * N - 1, GRBEnv(env));
	for (GRBModel i : vector_model) {
		i.set("TimeLimit", "3600");
	}
	vector<GRBVar> isCycleUsed(allo.cycles.size());
	GRBVar var_d1;
	vector<GRBLinExpr> isPatientUsed(allo.maxId + 1);
	GRBLinExpr M_estar;
	vector<GRBLinExpr> cons_d1(N);
	vector<GRBVar> abs_var(2 * N);
	vector<bool> isPatientIdUsed(allo.maxId + 1, false);
	cout << "error taking place" << endl;
	// Initialize cycle variables
	for (int i = 0; i < allo.cycles.size(); i++) {
		isCycleUsed[i] = model.addVar(0, 1, 0, GRB_BINARY);
	}
	// N difference variables
	for (int i = 0; i < N; i++) {
		abs_var[i] = model.addVar(-GRB_INFINITY, GRB_INFINITY, 0.0, GRB_CONTINUOUS);
	}
	// N abs variables
	for (int i = 0; i < N; i++) {
		abs_var[i + N] = model.addVar(0, GRB_INFINITY, 0.0, GRB_CONTINUOUS);
	}

	// variable d1
	var_d1 = model.addVar(0.0, GRB_INFINITY, 0.0, GRB_CONTINUOUS);

	for (int i = 0; i < allo.maxId + 1; i++) {
		isPatientUsed[i] = 0;
	}


	// Perform values, absolute deviations
	for (int i = 0; i < allo.cycles.size(); i++) {
		for (int j = 0; j < allo.cycles[i].idX.size(); j++) {
			isPatientUsed[allo.cycles[i].idX[j]] += isCycleUsed[i];
			isPatientIdUsed[allo.cycles[i].idX[j]] = true;
			for (int k = 0; k < N; k++) {
				if (Vp_start[k] <= label_positions[allo.cycles[i].idX[j]] && label_positions[allo.cycles[i].idX[j]] < Vp_start[k + 1]) {
					cons_d1[k] += isCycleUsed[i];
				}
			}
		}
		M_estar += allo.cycles[i].idX.size() * isCycleUsed[i];

	}

	// maximum size
	model.addConstr(M_estar == M);


	// Unique assignment for patients
	for (int i = 0; i < allo.maxId + 1; i++) {
		if (isPatientIdUsed[i]) model.addConstr(isPatientUsed[i] <= 1);
	}

	// bounds on absolute deviations
	vector<double> bound(N, 0);
	for (unsigned short int i = 1; i < N + 1; ++i) {
		bound[i - 1] = target[i - 1] + credit[i - 1];
		cout << "target[i]: " << target[i - 1] << " credit: " << credit[i - 1] << endl;
	}

	for (unsigned short int i = 1; i < N + 1; ++i) {
		model.addConstr(abs_var[i - 1] == cons_d1[i - 1] - bound[i - 1]);
		model.addGenConstrAbs(abs_var[N + i - 1], abs_var[i - 1]);
		model.addConstr(abs_var[N + i - 1] <= var_d1);
	}

	model.setObjective(1 * var_d1, GRB_MINIMIZE);


	// Setting of Gurobi
	model.getEnv().set(GRB_DoubleParam_TimeLimit, 36000);
	//model.getEnv().set(GRB_IntParam_Method, 2);
	//model.getEnv().set(GRB_IntParam_Threads, 1);
	model.getEnv().set(GRB_DoubleParam_MIPGap, 0);
	model.optimize();

	int optimstatus = model.get(GRB_IntAttr_Status);
	if (optimstatus != 2) {
		track_not_optimal[N - 4][inst] = optimstatus;
		if (optimstatus == 9) {
			track_time_limit[N - 4][inst] = optimstatus;
		}
	}

	for (int i = 0; i < allo.cycles.size(); i++) {
		//cout << "error taking place" << endl;
		if (isCycleUsed[i].get(GRB_DoubleAttr_X) > pow(10, -4)) {
			for (int j = 0; j < allo.cycles[i].idX.size(); j++) {
				node_set.push_back(allo.cycles[i].idX[j]);
			}
		}
	}
	cout << "size of the M" << node_set.size() << endl;
	double obj = model.getObjective().getValue();

	cout << "obj: " << obj << endl;
	for (int i = 0; i < N; i++) {
		cout << abs_var[N + i].get(GRB_DoubleAttr_X) << endl;
	}
	vector<double> d_t(N, 0);
	d_t[0] = var_d1.get(GRB_DoubleAttr_X);
	std::cout << "d_t[0]" << d_t[0] << endl;
	vector<unsigned short int> N_star(N, 0);
	unsigned short int n_star = 0;
	unsigned short int t_star = 0;
	double epsilon = 0;
	unsigned short int track = 0;
	vector<GRBVar> var_lexmin(allo.cycles.size());

	if (d_t[0] > 0.5 && lex_min) {
		epsilon_func(target, credit, epsilon, N);
		sort_d_t(d_t, isCycleUsed, label_positions, N, Vp_start, allo, target, t_star, credit, epsilon, var_lexmin, N_star);
	}
	std::cout << "finish sorting" << "epsilon:" << epsilon << endl;
	std::cout << "start n_star_1" << endl;
	if (lex_min && d_t[0] > 0.5 && abs(epsilon) > pow(10, -4)) {
		lex_min_n_star(d_t, lex_min, t_star, N, allo, M, Vp_start, epsilon, n_star, bound, N_star, var_lexmin, vector_model, track, label_positions, track_not_optimal, track_time_limit, inst);
	}
	std::cout << "finish n_star_1" << endl;
	lexmin_searching(d_t, lex_min, t_star, N, epsilon, n_star, bound, N_star, Vp_start, target, credit, var_lexmin, inst, vector_model, track, M, allo, label_positions, mipgap, lb, ub, track_not_optimal, track_time_limit);

	cout << "finish lexmin_searching" << endl;

	unsigned short int t = 0;
	double gap = 0;
	gap = model.get(GRB_DoubleAttr_MIPGap);
	if (gap > pow(10, -4)) {
		mipgap.push_back(gap);
		lb.push_back(var_d1.get(GRB_DoubleAttr_LB));
		ub.push_back(var_d1.get(GRB_DoubleAttr_UB));
	}
	for (unsigned short int i = 1; i < allo.cycles.size() + 1; ++i) {
		//cout << "{" << arc_pair[i].first << "," << arc_pair[i].second << "}" << endl;
		//cout << var_bi[i - 1].get(GRB_DoubleAttr_X);
		if (lex_min && d_t[0] > 0.5) {
			if (var_lexmin[i - 1].get(GRB_DoubleAttr_X) > pow(10, -4)) {
				t += allo.cycles[i - 1].idX.size();
				cycle_dis[Q][allo.cycles[i - 1].idX.size()] += 1;
				cout << "pass 1" << endl;
				for (int k = 0; k < allo.cycles[i - 1].idX.size(); k++) {
					leaving[label_positions[allo.cycles[i - 1].idX[k]]] = true;
					cout << "allo.cycles[i - 1].idX.size(): " << allo.cycles[i - 1].idX.size() << endl;
					cout << "pass 2" << endl;
				}
				for (unsigned short int j = 0; j < N; ++j) {
					for (int k = 0; k < allo.cycles[i - 1].idX.size(); k++) {
						if (Vp_start[j] <= label_positions[allo.cycles[i - 1].idX[k]] && label_positions[allo.cycles[i - 1].idX[k]] < Vp_start[j + 1]) {
							++s[j];
							cout << "pass 3" << endl;
						}
					}

				}
			}

		}
		else {
			if (isCycleUsed[i - 1].get(GRB_DoubleAttr_X) > pow(10, -4)) {
				t += allo.cycles[i - 1].idX.size();
				cycle_dis[Q][allo.cycles[i - 1].idX.size()] += 1;
				cout << "pass 4" << endl;
				for (int k = 0; k < allo.cycles[i - 1].idX.size(); k++) {
					leaving[label_positions[allo.cycles[i - 1].idX[k]]] = true;
					cout << "pass 5" << endl;
				}
				for (unsigned short int j = 0; j < N; ++j) {
					for (int l = 0; l < allo.cycles[i - 1].idX.size(); l++) {
						if (Vp_start[j] <= label_positions[allo.cycles[i - 1].idX[l]] && label_positions[allo.cycles[i - 1].idX[l]] < Vp_start[j + 1]) {
							++s[j];
							cout << "pass 6" << endl;
						}
					}
				}
			}
		}

	}
	cout << "size of M" << t << endl;
	model.reset();
	model.update();
	for (unsigned short int i = 0; i < track + 1; ++i) {
		vector_model[i].reset();
		vector_model[i].update();
	}

	/*for (unsigned short int i = 0; i < cycle_distri.size(); ++i) {
		cout << "{" << cycle_distri[i].first << "," << cycle_distri[i].second << "}" << endl;
	}*/

	double temp = 0;
	for (unsigned short int i = 0; i < N; ++i) {
		d[i] += target[i] - s[i];
		temp += abs(d[i]);
		if (c_involved) {
			credit[i] += target[i] - s[i];
		}
		else {
			credit[i] = 0;
		}
		std::cout << "country " << to_string(i) << " " << "initial allocation " << i << ": " << target[i] << '/n' << "s[i] : " << s[i] << "d[i] : " << d[i] << "credit[i] : " << credit[i] << endl;
		//actual_alloc[Q].push_back(s[i]);
	}
	average_d_period[N - 4][Q] += temp;
	return;
}


void arbitraryMaximum(vector<unsigned short int>& node_arrives, ListGraph& g, ListDigraph& g_original, vector<pair<int, int>>& arc_pair, vector<bool>& leaving, ListGraph::NodeMap<bool>& active_nodes, ListDigraph::NodeMap<bool>& active_nodes_original, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, bool& disp, vector<unsigned short int>& no_of_active_nodes, unsigned short int& N, vector<unsigned short int>& Vp_start, unsigned short int& periods, bool& dispy, vector<unsigned short int>& s, unsigned short int& Q, vector<double>& v, bool& target_omega, vector<double>& target, vector<double>& credit, ListGraph::EdgeMap<double>& edge_card_weight, double& t0, vector<vector<unsigned short int>>& actual_alloc, vector<double>& v_impu, vector<int>& nodeset, vector<double>& d, double& M_total, double& d_total, bool& c_involved, map<int, int>& numofMaxSolution, bool& arbitray_maximum, vector<double>& v_S, unsigned int& S, double& core_100, long& negative_core, unsigned short int inst, double& max_d, double& game_generation, double& solution_concept_time, vector<vector<double>>& average_d_period, set<int>& active_source, vector<int>& source_set, Allocation& allo, vector<int>& node_set, vector<unsigned short int>& label_positions, vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, double& relative_d1_arbitrary, vector<map<int, int>>& cycle_dis, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, vector<double>& relative_optimal) {
	Q = 0;
	d_total = 0;
	M_total = 0;
	core_100 = 0;
	negative_core = 0;
	max_d = 0;
	active_source.clear();
	if (dispy)
		std::cout << " --== Without lex min matching == -- " << endl;
	for (unsigned short int i = 0; i < N; i++) {
		s[i] = 0;
		credit[i] = 0;
		no_of_active_nodes[i] = (Vp_start[i + 1] - Vp_start[i]) / 4;
		for (unsigned short int j = Vp_start[i]; j < Vp_start[i + 1]; j++) {
			if (node_arrives[j] == 0) {
				active_nodes[c[j]] = true;
				active_nodes[c_b[j]] = true;
				active_nodes_original[c_original[j]] = true;
				active_source.insert(source_set[j]);
			}
			else {
				active_nodes[c[j]] = false;
				active_nodes[c_b[j]] = false;
				active_nodes_original[c_original[j]] = false;
			}
		}
	}


	while (Q < periods) {
		if (dispy) {
			std::cout << "--== PERIOD " << Q + 1 << " ==--" << endl;
		}
		if (dispy) {
			std::cout << "Number of active nodes: ";
			for (unsigned short int i = 0; i < N; i++)
				std::cout << no_of_active_nodes[i] << " ";
			std::cout << endl;
		}
		// cooperative game and target
		std::cout << "start generating values" << endl;
		coop_game(g, v, v_impu, v_S, S, s, c, c_b, edge_card_weight, dispy, Vp_start, N, active_nodes, leaving, numofMaxSolution, Q, arbitray_maximum, game_generation, allo, active_source, source_set, node_set, label_positions, arc_in, arc_out, cycle_dis, track_not_optimal, track_time_limit, inst);
		double t0 = cpuTime();
		double suma = 0;
		double sumimpu = 0;
		if (target_omega) {
			for (unsigned short int i = 0; i < N; i++) {
				suma += v[N] - v[i] - v_impu[i];
				sumimpu += v_impu[i];
			}
			for (unsigned short int i = 0; i < N; i++)
				target[i] = v_impu[i] + (v[N] - sumimpu) * ((v[N] - v[i] - v_impu[i]) / suma);
		}
		else {
			for (unsigned short int i = 0; i < N; i++) {
				suma += v[N] - v[i];
				sumimpu += v_impu[i];
			}
			for (unsigned short int i = 0; i < N; i++)
				target[i] = v_impu[i] + (v[N] - sumimpu) * ((v[N] - v[i]) / suma);
		}
		double t1 = cpuTime();
		solution_concept_time += t1 - t0;
		M_total += v[N];

		//compute deviations
		if (dispy) {
			if (target_omega) {
				std::cout << "Benefit: ";
			}
			else {
				std::cout << "Contribution: ";
			}
			for (unsigned short int i = 0; i < N; i++) {
				std::cout << target[i] << " ";
			}
			std::cout << endl;
		}

		double temp_0 = 0;
		for (unsigned short int i = 0; i < N; ++i) {
			d[i] += target[i] - s[i];
			temp_0 += abs(d[i]);
			if (c_involved) {
				credit[i] += target[i] - s[i];
			}
			else {
				credit[i] = 0;
			}
			std::cout << "country" << to_string(i) << "initial allocation[i]: " << target[i] << '/n' << "s[i]: " << s[i] << "d[i]: " << d[i] << "credit[i]: " << credit[i] << endl;
			//actual_alloc[Q].push_back(s[i]);
		}
		average_d_period[N - 4][Q] += temp_0;

		Q++;
		changing_nodes(active_nodes, active_nodes_original, leaving, no_of_active_nodes, N, Vp_start, node_arrives, Q, c, c_b, c_original, s, d, target, active_source, source_set);
		if (dispy)
			cin.get();
	}
	for (unsigned short int i = 0; i < N; ++i) {
		d_total += abs(d[i]);
	}
	if (track_time_limit[N - 4][inst] != 9) {
		relative_optimal[N - 4] += d_total / (M_total);

	}
	vector<double> max_deviation(N, 0);
	for (unsigned short int i = 0; i < N; ++i) {
		max_deviation[i] = abs(d[i]) / (M_total);
	}
	std::sort(max_deviation.begin(), max_deviation.end());
	max_d = max_deviation[N - 1];
	relative_d1_arbitrary += d_total / (M_total);
	return;
}


void pair_arcs(unsigned short int& Q, ListDigraph& g_original, vector<unsigned short int>& node_arrives, ListDigraph::NodeMap<bool>& active_nodes_original, vector<pair<int, int>>& arc_pair, vector<int>& nodeset) {
	FilterNodes<ListDigraph> sg(g_original, active_nodes_original);
	arc_pair.clear();
	nodeset.clear();
	for (FilterNodes<ListDigraph>::NodeIt n(sg); n != INVALID; ++n) {
		nodeset.push_back(sg.id(n));
	}
	sort(nodeset.begin(), nodeset.end());
	for (FilterNodes<ListDigraph>::ArcIt a(sg); a != INVALID; ++a) {
		arc_pair.push_back({ sg.id(sg.source(a)),sg.id(sg.target(a)) });
	}
	sort(arc_pair.begin(), arc_pair.end());
	return;

}

void sort_d_t(vector<double>& d_t, vector<GRBVar>& isCycleUsed, vector<unsigned short int>& label_positions, unsigned short int& N, vector<unsigned short int>& Vp_start, Allocation& allo, vector<double>& target, unsigned short int& t, vector<double>& credit, double& epsilon, vector<GRBVar>& var_lexmin, vector<unsigned short int>& N_star) {
	unsigned short int n_star = 0;
	vector<unsigned short int> s_copy(N, 0);
	vector<double> d_copy(N, 0);
	for (unsigned short int i = 1; i < allo.cycles.size() + 1; ++i) {
		var_lexmin[i - 1] = isCycleUsed[i - 1];
		//cout << "{" << arc_pair[i].first << "," << arc_pair[i].second << "}" << endl;
		//cout << var_bi[i - 1].get(GRB_DoubleAttr_X);
		if (isCycleUsed[i - 1].get(GRB_DoubleAttr_X) > pow(10, -4)) {
			for (int k = 0; k < allo.cycles[i - 1].idX.size(); k++) {
				for (unsigned short int j = 0; j < N; j++) {
					if (Vp_start[j] <= label_positions[allo.cycles[i - 1].idX[k]] && label_positions[allo.cycles[i - 1].idX[k]] < Vp_start[j + 1]) {
						++s_copy[j];
					}
				}
			}

		}
	}
	for (unsigned short int i = 0; i < N; ++i) {
		d_copy[i] = abs(target[i] + credit[i] - s_copy[i]);
	}
	//sort
	std::sort(d_copy.begin(), d_copy.end());
	/*for (unsigned short int i = 0; i < N; ++i) {
		std::cout << "d_copy[i]" << d_copy[i] << endl;
		std::cout << "s_copy" << s_copy[i] << endl;
	}*/

	int total = 0;
	for (int num : N_star) {
		total += num;
	}

	if (epsilon > 3 * pow(10, -4)) {
		d_t[t] = d_copy[N - 1 - total] + pow(10, -4);
	}
	else {
		d_t[t] = d_copy[N - 1 - total];
	}

	if (t < N - 1) {
		d_t[t + 1] = d_copy[N - 2 - total];
	}
	std::cout << "d" << to_string(t - 1) << d_t[t - 1] << endl;
	std::cout << "epsilon: " << epsilon << endl;
}

void lex_min_n_star(vector<double>& d_t, bool& lex_min, unsigned short int& t_star, unsigned short int& N, Allocation& allo, double& M, vector<unsigned short int>& Vp_start, double& epsilon, unsigned short int& n_star, vector<double>& bound, vector<unsigned short int>& N_star, vector<GRBVar>& var_lexmin, vector<GRBModel>& vector_model, unsigned short int& track, vector<unsigned short int>& label_positions, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, unsigned short int inst) {
	++track;
	std::cout << "t_star: " << t_star << endl;
	vector<GRBVar> isCycleUsed(allo.cycles.size());
	vector<GRBLinExpr> isPatientUsed(allo.maxId + 1);
	GRBLinExpr M_estar;
	vector<GRBLinExpr> cons_d1(N);
	vector<bool> isPatientIdUsed(allo.maxId + 1, false);


	//cycle variables
	for (unsigned short int i = 0; i < allo.cycles.size(); ++i) {
		isCycleUsed[i] = vector_model[track].addVar(0.0, 1.0, 0.0, GRB_BINARY, "x" + to_string(i));
	}
	for (int i = 0; i < allo.maxId + 1; i++) {
		isPatientUsed[i] = 0;
	}

	// Perform values, absolute deviations
	for (int i = 0; i < allo.cycles.size(); i++) {
		for (int j = 0; j < allo.cycles[i].idX.size(); j++) {
			isPatientUsed[allo.cycles[i].idX[j]] += isCycleUsed[i];
			isPatientIdUsed[allo.cycles[i].idX[j]] = true;
			for (int k = 0; k < N; k++) {
				if (Vp_start[k] <= label_positions[allo.cycles[i].idX[j]] && label_positions[allo.cycles[i].idX[j]] < Vp_start[k + 1]) {
					// Vc and Vp
					cons_d1[k] += isCycleUsed[i];
				}
			}
		}
		M_estar += allo.cycles[i].idX.size() * isCycleUsed[i];
	}

	// maximum size
	vector_model[track].addConstr(M_estar == M);

	// Unique assignment for patients
	for (int i = 0; i < allo.maxId + 1; i++) {
		if (isPatientIdUsed[i] == true) vector_model[track].addConstr(isPatientUsed[i] <= 1);
	}






	// N difference variables
	vector<GRBVar> Var_dif(N);
	for (unsigned short int i = 0; i < N; ++i) {
		Var_dif[i] = vector_model[track].addVar(-GRB_INFINITY, GRB_INFINITY, 0.0, GRB_CONTINUOUS, "x" + to_string(i));
	}
	// N abs variables
	vector<GRBVar> Var_abs(N);
	for (unsigned short int i = 0; i < N; ++i) {
		Var_abs[i] = vector_model[track].addVar(0, GRB_INFINITY, 0.0, GRB_CONTINUOUS, "x" + to_string(i));
	}
	// z^t_p variables
	vector<GRBVar> Var_z_p((t_star + 1) * N);
	for (unsigned short i = 0; i < N * (t_star + 1); ++i) {
		Var_z_p[i] = vector_model[track].addVar(0.0, 1.0, 0.0, GRB_BINARY, "x" + to_string(i));
	}

	//sum z_p^t
	GRBLinExpr sum_zp = 0;
	for (unsigned short int i = N * t_star; i < N * (t_star + 1); i++) {
		sum_zp += Var_z_p[i];
	}
	vector_model[track].setObjective(sum_zp, GRB_MINIMIZE);


	// sum over (z_p^i)(d_i^*) between i=1 and i=t-1
	vector<GRBLinExpr> sum_zp_dp(N, 0);
	// sum over (z_p^i)(d_i^*) between i=1 and i=t
	vector<GRBLinExpr> sum_zp_t(N, 0);
	// sum over z_p^i for every i, where i<=t-1;
	vector<GRBLinExpr> sum_t_star(t_star, 0);
	// sum over z_p^i between i=0 and i=t;
	vector<GRBLinExpr> sum_p(N, 0);
	for (unsigned short int i = 0; i < t_star; ++i) {
		for (unsigned short int j = 0; j < N; ++j) {
			sum_zp_dp[j] += Var_z_p[i * N + j] * d_t[i];
			sum_zp_t[j] += Var_z_p[i * N + j] * d_t[i];
			sum_t_star[i] += Var_z_p[i * N + j];
			sum_p[j] += Var_z_p[i * N + j];
		}
	}
	for (unsigned short int j = 0; j < N; ++j) {
		sum_p[j] += Var_z_p[t_star * N + j];
		sum_zp_t[j] += Var_z_p[t_star * N + j] * d_t[t_star];
	}

	for (unsigned short int i = 1; i < N + 1; ++i) {
		vector_model[track].addConstr(Var_dif[i - 1] == cons_d1[i - 1] - bound[i - 1]);
		vector_model[track].addGenConstrAbs(Var_abs[i - 1], Var_dif[i - 1]);
		if (t_star == 0) {
			vector_model[track].addConstr(Var_abs[i - 1] <= d_t[t_star] - epsilon * (1 - Var_z_p[i - 1]));
		}
		if (t_star > 0) {
			vector_model[track].addConstr(Var_abs[i - 1] <= d_t[t_star] - epsilon * (1 - Var_z_p[t_star * N + i - 1]) + sum_zp_dp[i - 1]);
			vector_model[track].addConstr(Var_abs[i - 1] <= sum_zp_t[i - 1] + (1 - sum_p[i - 1]) * d_t[t_star - 1]);
		}
	}

	// for every p in N, sum over Z_p^i between i=1 and i=t is less than 1
	for (unsigned short int i = 0; i < N; ++i) {
		vector_model[track].addConstr(sum_p[i] <= 1);
	}
	// for every i, where i<=t-1, sum over z_p^i is equal to n_i^*
	for (unsigned short int i = 0; i < t_star; ++i) {
		vector_model[track].addConstr(sum_t_star[i] == N_star[i]);
	}

	std::cout << "finish loading constraints" << endl;
	vector_model[track].optimize();


	int optimstatus = vector_model[track].get(GRB_IntAttr_Status);
	if (optimstatus != 2) {
		track_not_optimal[N - 4][inst] = optimstatus;
		if (optimstatus == 9) {
			track_time_limit[N - 4][inst] = optimstatus;
		}
	}

	for (unsigned short int i = 0; i < N; ++i) {
		if (Var_z_p[N * t_star + i].get(GRB_DoubleAttr_X) > pow(10, -4)) {
			N_star[t_star] += 1;
		}
		//std::cout << "var_bi[col_num + N * (2 + t_star) + i].get(GRB_DoubleAttr_X): " << var_bi[col_num + N * (2 + t_star) + i].get(GRB_DoubleAttr_X) << endl;

	}
	std::cout << "epsilon: " << epsilon << "d_t[t_star]: " << d_t[t_star] << endl;
	std::cout << "N_star[t_star]: " << N_star[t_star] << endl;
	std::cout << "finish n_" << to_string(t_star) << endl;
	n_star = 0;
	for (unsigned short int i = 0; i < N; ++i) {
		n_star += N_star[i];
	}
	t_star += N_star[t_star];
	for (unsigned short int i = 0; i < allo.cycles.size(); ++i) {
		var_lexmin[i] = isCycleUsed[i];
	}

}

void lex_min_d_star(vector<double>& d_t, bool& lex_min, unsigned short int& t_star, unsigned short int& N, unsigned short int& n_star, vector<double>& bound, vector<unsigned short int>& N_star, vector<unsigned short int>& Vp_start, vector<double>& target, vector<double>& credit, vector<GRBVar>& var_lexmin, vector<GRBModel>& vector_model, unsigned short int& track, double& M, Allocation& allo, vector<unsigned short int>& label_positions, double& epsilon, vector<double>& mipgap, vector<double>& lb, vector<double>& ub, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, unsigned short int inst) {
	++track;
	vector<GRBVar> isCycleUsed(allo.cycles.size());
	vector<GRBLinExpr> isPatientUsed(allo.maxId + 1);
	GRBLinExpr M_estar;
	vector<GRBLinExpr> cons_d1(N);
	vector<bool> isPatientIdUsed(allo.maxId + 1, false);


	//cycle variables
	for (unsigned short int i = 0; i < allo.cycles.size(); ++i) {
		isCycleUsed[i] = vector_model[track].addVar(0.0, 1.0, 0.0, GRB_BINARY, "x" + to_string(i));
	}
	for (int i = 0; i < allo.maxId + 1; i++) {
		isPatientUsed[i] = 0;
	}

	// Perform values, absolute deviations
	for (int i = 0; i < allo.cycles.size(); i++) {
		for (int j = 0; j < allo.cycles[i].idX.size(); j++) {
			isPatientUsed[allo.cycles[i].idX[j]] += isCycleUsed[i];
			isPatientIdUsed[allo.cycles[i].idX[j]] = true;
			for (int k = 0; k < N; k++) {
				if (Vp_start[k] <= label_positions[allo.cycles[i].idX[j]] && label_positions[allo.cycles[i].idX[j]] < Vp_start[k + 1]) {
					// Vc and Vp
					cons_d1[k] += isCycleUsed[i];
				}
			}
		}
		M_estar += allo.cycles[i].idX.size() * isCycleUsed[i];
	}

	// maximum size
	vector_model[track].addConstr(M_estar == M);

	// Unique assignment for patients
	for (int i = 0; i < allo.maxId + 1; i++) {
		if (isPatientIdUsed[i] == true) vector_model[track].addConstr(isPatientUsed[i] <= 1);
	}






	// N difference variables
	vector<GRBVar> Var_dif(N);
	for (unsigned short int i = 0; i < N; ++i) {
		Var_dif[i] = vector_model[track].addVar(-GRB_INFINITY, GRB_INFINITY, 0.0, GRB_CONTINUOUS, "x" + to_string(i));
	}
	// N abs variables
	vector<GRBVar> Var_abs(N);
	for (unsigned short int i = 0; i < N; ++i) {
		Var_abs[i] = vector_model[track].addVar(0, GRB_INFINITY, 0.0, GRB_CONTINUOUS, "x" + to_string(i));
	}
	// z_p^(t-1) variables
	vector<GRBVar> Var_z_p(t_star * N);
	for (unsigned short i = 0; i < N * t_star; ++i) {
		Var_z_p[i] = vector_model[track].addVar(0.0, 1.0, 0.0, GRB_BINARY, "x" + to_string(i));
	}



	// d_t variable
	GRBVar Var_d_t = vector_model[track].addVar(0, GRB_INFINITY, 0.0, GRB_CONTINUOUS, "d" + to_string(t_star));
	GRBLinExpr obj = 1 * Var_d_t;

	vector_model[track].setObjective(obj, GRB_MINIMIZE);


	// sum over (z_p^i)(d_i^*) between i=1 and i=t-1
	vector<GRBLinExpr> sum_zp_dp(N, 0);
	// sum over z_p^i for every i, where i<=t-1;
	vector<GRBLinExpr> sum_t_star(t_star, 0);
	// sum over z_p^i between i=0 and i=t-1;
	vector<GRBLinExpr> sum_p(N, 0);
	for (unsigned short int i = 0; i < t_star; ++i) {
		for (unsigned short int j = 0; j < N; ++j) {
			sum_zp_dp[j] += Var_z_p[i * N + j] * d_t[i];
			sum_t_star[i] += Var_z_p[i * N + j];
			sum_p[j] += Var_z_p[i * N + j];
		}
	}


	for (unsigned short int i = 1; i < N + 1; ++i) {
		vector_model[track].addConstr(Var_dif[i - 1] == cons_d1[i - 1] - bound[i - 1]);
		vector_model[track].addGenConstrAbs(Var_abs[i - 1], Var_dif[i - 1]);
		if (t_star == 0) {
			vector_model[track].addConstr(Var_abs[i - 1] <= d_t[t_star]);
			vector_model[track].addConstr(Var_abs[i - 1] <= obj + sum_zp_dp[i - 1]);
		}
		if (t_star > 0) {
			vector_model[track].addConstr(Var_abs[i - 1] <= obj + sum_zp_dp[i - 1]);
			vector_model[track].addConstr(Var_abs[i - 1] <= sum_zp_dp[i - 1] + (1 - sum_p[i - 1]) * d_t[t_star - 1]);
			// for every p in N, sum over Z_p^i between i=1 and i=t is less than 1
			for (unsigned short int i = 0; i < N; ++i) {
				vector_model[track].addConstr(sum_p[i] <= 1);
			}
		}
	}


	// for every i, where i<=t-1, sum over z_p^i is equal to n_i^*
	for (unsigned short int i = 0; i < t_star; ++i) {
		vector_model[track].addConstr(sum_t_star[i] == N_star[i]);
	}

	std::cout << "finish loading constraints" << endl;
	vector_model[track].optimize();

	int optimstatus = vector_model[track].get(GRB_IntAttr_Status);
	if (optimstatus != 2) {
		track_not_optimal[N - 4][inst] = optimstatus;
		if (optimstatus == 9) {
			track_time_limit[N - 4][inst] = optimstatus;
		}
	}

	double gap = vector_model[track].get(GRB_DoubleAttr_MIPGap);
	if (gap > pow(10, -4)) {
		if (gap > pow(10, -4)) {
			mipgap.push_back(gap);
			lb.push_back(Var_d_t.get(GRB_DoubleAttr_LB));
			ub.push_back(Var_d_t.get(GRB_DoubleAttr_UB));
		}
	}

	sort_d_t(d_t, isCycleUsed, label_positions, N, Vp_start, allo, target, t_star, credit, epsilon, var_lexmin, N_star);
}

void lexmin_searching(vector<double>& d_t, bool& lex_min, unsigned short int& t_star, unsigned short int& N, double& epsilon, unsigned short int& n_star, vector<double>& bound, vector<unsigned short int>& N_star, vector<unsigned short int>& Vp_start, vector<double>& target, vector<double>& credit, vector<GRBVar>& var_lexmin, unsigned short int inst, vector<GRBModel>& vector_model, unsigned short int& track, double& M, Allocation& allo, vector<unsigned short int>& label_positions, vector<double>& mipgap, vector<double>& lb, vector<double>& ub, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit) {
	while (lex_min && abs(d_t[t_star - 1]) > 0.5 && n_star < N) {
		std::cout << "begin search d_t" << endl;

		lex_min_d_star(d_t, lex_min, t_star, N, n_star, bound, N_star, Vp_start, target, credit, var_lexmin, vector_model, track, M, allo, label_positions, epsilon, mipgap, lb, ub, track_not_optimal, track_time_limit, inst);
		std::cout << "inst: " << inst << endl;
		std::cout << "abs(d_t[t_star])" << abs(d_t[t_star]) << endl;
		std::cout << "t_star: " << t_star << endl;
		std::cout << "N-1: " << N - 1 << endl;
		if (t_star == N - 1) {
			std::cout << "N-1==t_star" << endl;
		}
		else {
			std::cout << "N-1!=t_star" << endl;
		}
		std::cout << "epsilon in the loop: " << epsilon << endl;
		std::cout << "absolute epsilon in the loop: " << abs(epsilon) << endl;
		if (abs(d_t[t_star]) > 0.5) {
			if (abs(epsilon) > pow(10, -4)) {
				if (t_star == N - 1) {
					std::cout << "congratulations t_star == N - 1" << endl;
					//break
					n_star = N;
					std::cout << "congratulations after break" << endl;
				}
				else
				{
					if (d_t[t_star + 1] < 0.5) {
						std::cout << "congratulations d_t[t_star + 1] < 0.5" << endl;
						//break;
						n_star = N;
					}
					else {
						std::cout << "congratulations d_t[t_star + 1] > 0.5" << endl;
						lex_min_n_star(d_t, lex_min, t_star, N, allo, M, Vp_start, epsilon, n_star, bound, N_star, var_lexmin, vector_model, track, label_positions, track_not_optimal, track_time_limit, inst);
						if (d_t[t_star] < 0.5) {
							std::cout << "congratulations d_t[t_star + 1] < 0.5" << endl;
							//break;
							n_star = N;
						}
					}
				}
			}
			if (abs(epsilon) < pow(10, -4)) {
				std::cout << "congratulations abs(epsilon) < pow(10, -7))" << endl;
				lexmin_searching(d_t, lex_min, t_star, N, epsilon, n_star, bound, N_star, Vp_start, target, credit, var_lexmin, inst, vector_model, track, M, allo, label_positions, mipgap, lb, ub, track_not_optimal, track_time_limit);
			}
		}
		else {
			std::cout << "congratulations break" << endl;
			//break
			n_star = N;
		}
	}
}




void epsilon_func(vector<double> target, vector<double> credit, double& epsilon, unsigned short int N) {
	vector<double> target_credit(N, 0);
	vector<double> epsilon_sort(N * (N - 1), 0);
	for (unsigned short int i = 0; i < N; ++i) {
		target_credit[i] = target[i] + credit[i];
	}

	unsigned short int t = -1;
	for (unsigned short int i = 0; i < N - 1; ++i) {
		for (unsigned short j = i + 1; j < N; ++j) {
			++t;
			//cout << "target_credit[i]: " << target_credit[i] << "target_credit[j]: " << target_credit[j] << endl;
			epsilon_sort[t] = abs(frac(target_credit[i]) - frac(target_credit[j]));
			//cout << "a-b: " << epsilon_sort[t] << endl;
			++t;
			epsilon_sort[t] = abs(frac(target_credit[i]) - (1 - frac(target_credit[j])));
			//cout << "a-(1-b): " << epsilon_sort[t] << endl;
		}
	}
	cout << "t" << t << endl;


	auto newEnd = std::remove_if(epsilon_sort.begin(), epsilon_sort.end(), [](double num) {
		return num < 2 * pow(10, -4);
		});
	epsilon_sort.erase(newEnd, epsilon_sort.end());

	std::sort(epsilon_sort.begin(), epsilon_sort.end());
	epsilon = epsilon_sort[0];
	cout << "epsilon_sort[0]" << epsilon_sort[0] << endl;
}

double frac(double ori) {
	double abs_frac;
	abs_frac = abs(ori) - abs(int(ori));
	return abs_frac;
}

double solve_obj(Allocation& allo, set<int>& active_source, vector<int>& node_set, vector<unsigned short int>& label_positions, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, vector<map<int, int>>& cycle_dis, bool& is_cycle_dis, unsigned short int Q, unsigned short int inst, unsigned short int N) {

	GRBEnv env = GRBEnv();
	env.set("OutputFlag", "0");

	// Model
	try {
		allo.dynamic(active_source);
		node_set.clear();
		// Local variables
		GRBModel model = GRBModel(env);
		GRBLinExpr objFun1 = 0;

		vector<GRBVar> isCycleUsed(allo.cycles.size());
		vector<GRBLinExpr> isPatientUsed(allo.maxId + 1, 0);
		vector<bool> isPatientIdUsed(allo.maxId + 1, false);

		// Initialization
		for (int i = 0; i < allo.cycles.size(); i++) {
			isCycleUsed[i] = model.addVar(0, 1, 0, GRB_BINARY);
		}




		// Perform values
		set<int> error_node;
		for (int i = 0; i < allo.cycles.size(); i++) {
			for (int j = 0; j < allo.cycles[i].idX.size(); j++) {
				if (active_source.count(allo.cycles[i].idX[j])) {
					isPatientUsed[allo.cycles[i].idX[j]] += isCycleUsed[i];
					isPatientIdUsed[allo.cycles[i].idX[j]] = true;
					objFun1 += isCycleUsed[i];
				}
				else {
					//cout << "error in generating valid cycles" << endl;
					error_node.insert(allo.cycles[i].idX[j]);
				}
			}
		}

		cout << "print our error nodes" << endl;
		cout << "size of error nodes" << error_node.size() << endl;
		for (auto i = error_node.begin(); i != error_node.end(); i++) { cout << *i << endl; }
		cout << "print out active sources" << endl;
		cout << "size of active sources" << active_source.size() << endl;
		for (auto j = active_source.begin(); j != active_source.end(); j++) {}//cout << *j << endl;														
		int num_ofs = 0;
		for (int i = 0; i < allo.maxId + 1; i++) {
			if (isPatientIdUsed[i]) {
				model.addConstr(isPatientUsed[i] <= 1);
				num_ofs += 1;
			}
		}
		cout << "number of constraints: " << num_ofs << endl;

		model.setObjective(objFun1, GRB_MAXIMIZE);



		// Setting of Gurobi
		model.getEnv().set(GRB_DoubleParam_TimeLimit, 3600);
		model.getEnv().set(GRB_IntParam_Method, 2);
		model.getEnv().set(GRB_IntParam_Threads, 1);
		model.getEnv().set(GRB_DoubleParam_MIPGap, 0);
		model.optimize();

		int optimstatus = model.get(GRB_IntAttr_Status);
		if (optimstatus != 2) {
			track_not_optimal[N - 4][inst] = optimstatus;
			if (optimstatus == 9) {
				track_time_limit[N - 4][inst] = optimstatus;
			}
		}

		int cnt = 0;
		cout << "allo.cycles.size(): " << allo.cycles.size() << endl;
		for (int i = 0; i < allo.cycles.size(); i++) {
			if (isCycleUsed[i].get(GRB_DoubleAttr_X) > pow(10, -4)) {
				cnt += allo.cycles[i].idX.size();
				if (is_cycle_dis) {
					if (allo.cycles[i].idX.size() == 0) {
						cout << "----------------0----------------" << endl;
						cout << "----------i " << i << "-------------" << endl;
					}
					cycle_dis[Q][allo.cycles[i].idX.size()] += 1;
				}
				for (int j = 0; j < allo.cycles[i].idX.size(); j++) {
					node_set.push_back(allo.cycles[i].idX[j]);
				}
			}
		}
		cout << "cnt: " << cnt << endl;
		sort(node_set.begin(), node_set.end());
		/*cout << "----------print the node set------------" << endl;
		for (int i : node_set) {
			cout << i << endl;
		}*/
		cout << "complete filling the node set" << endl;
		cout << "the size of the node set" << node_set.size() << " the size of the active source:" << active_source.size() << endl;
		double obj = model.getObjective().getValue();
		model.reset();
		model.update();
		return obj;

	}

	// Exceptions
	catch (GRBException e) {
		cout << "Error code = " << e.getErrorCode() << endl;
		cout << e.getMessage() << endl;
	}
	catch (...) {
		cout << "Exception during optimization" << endl;
	}



}

void country_sizes(unsigned short int& N, vector<unsigned short int>& Vp, vector<unsigned short int>& Vp_start, bool& dispy, unsigned short int& graph_size) {
	unsigned short int sz = 0;
	if (remainder(N, 2) == 0) {
		sz = 4 * (unsigned short int)(graph_size / (6 * N));
		for (unsigned short int i = 0; i < N / 2; i++) {
			Vp[i] = sz;
			Vp[N - i] = 2 * sz;
		}
		Vp[N / 2] = Vp[N - 1];
	}
	else {
		sz = 4 * (unsigned short int)(graph_size / (8 * N));
		if (remainder(N, 6) == 1) {
			for (unsigned short int i = 0; i < (unsigned short int)(N / 3); i++) {
				Vp[i] = sz;
				Vp[N - i - 1] = 3 * sz;
			}
			for (unsigned short int i = (unsigned short int)(N / 3); i < 2 * (unsigned short int)(N / 3) + 1; i++)
				Vp[i] = 2 * sz;
		}
		else {
			if (remainder(N, 3) == 0) {
				for (unsigned short int i = 0; i < (N / 3); i++) {
					Vp[i] = sz;
					Vp[i + N / 3] = 2 * sz;
					Vp[N - i - 1] = 3 * sz;
				}
			}
			else {
				unsigned short int sm = ((unsigned short int)(N / 3)) + 1;
				unsigned short int med = sm - 1;
				unsigned short int lrg = sm;
				for (unsigned short int i = 0; i < sm; i++) {
					Vp[i] = sz;
					Vp[N - i - 1] = 3 * sz;
				}
				for (unsigned short int i = sm; i < sm + med; i++)
					Vp[i] = 2 * sz;
			}
		}
	}
	for (unsigned short int i = 0; i < N; i++) {
		Vp_start[i + 1] = Vp[i] + Vp_start[i];
	}
	if (dispy) {
		cout << "country sizes: ";
		for (unsigned short int i = 0; i < N; i++) {
			cout << Vp[i] << " ";
		}
		cout << endl << "starting points: ";
		for (unsigned short int i = 0; i < N + 1; i++) {
			cout << Vp_start[i] << " ";
		}
		cout << endl;
	}
	return;
}