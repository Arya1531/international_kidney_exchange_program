#pragma once

#ifndef ALLOCATION_H
#define ALLOCATION_H

using namespace std;
#include <iostream> 
#include <iomanip> 
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <set>
#include <stdexcept>

class Doctor;
class Info;
class Cycle;
class Allocation;




/*	*************************************************************************************
	***********************************  PAIR  ******************************************
	************************************************************************************* */

class Pair {
public:
	int id;
	int source;
	int nbEdges;
	vector<int> targets;
	void print();
};

/*	*************************************************************************************
	************************************* CYCLE *****************************************
	************************************************************************************* */

class Cycle {
public:
	int id;
	int size;
	int isC;
	vector<int> idX;

	void print();
};

/*	*************************************************************************************
	********************************** ALLOCATION ***************************************
	************************************************************************************* */
class Allocation {
public:

	// Data read from the file
	string name;
	int nbPairs;
	vector<vector<int> > idToIdxA;
	vector<vector<int> > idToIdxP;
	int maxId;

	vector<Pair> pairs;
	vector<Cycle> cycles;
	vector<vector<int> > comp;

	vector<int> types;

	// Given by the ILP model
	vector<int> objs;
	vector<int> startC;

	void load(vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, vector<int>& source_set);
	void dynamic(set<int>& active_source);
	void printProb();
	void printInfo(const string& pathAndFileout);
};


#endif 
