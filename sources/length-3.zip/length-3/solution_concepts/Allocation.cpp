#include "Allocation.h" 
#include <map>
#include <algorithm>

using namespace std;



/*	*************************************************************************************
	************************************* PAIR * ****************************************
	************************************************************************************* */

void Pair::print() {
	cout << "Pair " << id << "\t source " << source << "\t nbEdges " << nbEdges << " \t";
	for (int i = 0; i < nbEdges; i++) cout << "(" << targets[i] << ") ";
}

/*	*************************************************************************************
	************************************* CYCLE *****************************************
	************************************************************************************* */

void Cycle::print() {
	if (isC == 1)
		cout << "Chain ";
	else
		cout << "Cycle ";
	cout << setw(5) << id << "\t size " << size << " ";
	for (int i = 0; i < size - 1; i++) cout << setw(5) << idX[i] << " ";
	cout << setw(5) << idX.back() << setw(5) << endl;
}

/*	*************************************************************************************
	********************************** ALLOCATION ***************************************
	************************************************************************************* */

void Allocation::load(vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, vector<int>& source_set) {
	idToIdxP.clear();
	idToIdxP.resize(10000);
	pairs.clear();
	maxId = 0;
	nbPairs = 0;
	int source = -1;
	int nbEdges = 0;
	vector<int> t;
	vector<int> s;
	vector<int> temp;
	vector<int> arc_in_filtered;
	map<int, int> map_source;
	for (int i : arc_out) {
		temp.push_back(i);
	}
	maxId = *max_element(temp.begin(), temp.end());
	for (int i = 0; i < arc_out.size(); i++) {
		if (arc_in[i] <= maxId) {
			arc_in_filtered.push_back(arc_in[i]);
			if (map_source.find(arc_out[i]) == map_source.end()) {
				map_source[arc_out[i]] = 1;
				s.push_back(arc_out[i]);
				temp.push_back(arc_out[i]);
				//cout <<"i: "<< i << endl;
			}
			else {
				map_source[arc_out[i]]++;
			}
		}
	}
	/*int max_temp = 0;
	set<int> arc_in_temp;
	for (int j : arc_in) {
		arc_in_temp.insert(j);
		if (j >= max_temp) {
			max_temp = j;
		}
	}
		if (max_temp >= temp[n - 1]) {
		maxId = max_temp;
	}
	else {
		maxId = temp[n - 1];
	}*/
	int n = map_source.size();
	vector<Pair> P_n(n);
	//cout << "size of arc_in: " << arc_in.size() << " size of arc_out: " << arc_out.size() << endl;
	//cout << "-----------number of nodes in the arc_in: " << arc_in_temp.size() << "--------------" << endl;
	//cout << "------------number of nodes in the arc_out: " << n << "--------------" << endl;
	int count = 0;
	int cnt_3 = 0;
	set<int> temp_test;
	for (int i = 0; i < n; i++) {
		P_n[i].source = s[i];
		P_n[i].nbEdges = map_source[s[i]];
		cnt_3 += P_n[i].nbEdges;
		set<int> temp;

		for (int j = 0; j < map_source[s[i]]; j++) {
			t.push_back(arc_in_filtered[j + count]);
			temp_test.insert(arc_in_filtered[j + count]);
			temp.insert(s[i]);
		}
		if (temp.size() > 1) {
			//cout << "error in inserting sources and targets" << endl;
		}
		P_n[i].targets = t;
		t.clear();
		count += P_n[i].nbEdges;
		pairs.push_back(P_n[i]);
		idToIdxP[P_n[i].source].push_back(nbPairs);
		nbPairs++;
	}
	//cout << "check: number of edges: " << cnt_3 << endl;
	//cout << "number of pairs: " << nbPairs << endl;
	//cout << "------------maximum target-----------" << *(temp_test.rbegin()) << endl;
	//sort(arc_in.begin(), arc_in.end());
	//cout << "------------maximum target-----------" << arc_in[arc_in.size()-1] << endl;
	sort(arc_out.begin(), arc_out.end());
	//cout << "------------maximum source-----------" << arc_out[arc_out.size()-1] << endl;
	int cnt_4 = 0;
	for (int i = 0; i < idToIdxP.size(); i++) {
		if (idToIdxP[i].size()) {
			if (s[cnt_4] != i) {
				//cout << "error in idToIdxP" << endl;
			}
			cnt_4 += 1;
		}
	}
	set<int> check, check_1;
	for (auto i = s.begin(); i != s.end(); i++) {
		check.insert(*i);
	}
	int cnt = check.size();
	for (int j = 0; j < idToIdxP.size(); j++) {
		if (idToIdxP[j].size()) {
			check.insert(j);;
			check_1.insert(j);

		}
	}
	if (check.size() != check_1.size() or check_1.size() != s.size() or check.size() != s.size()) {
		//cout << "check.size(): " << check.size() << " check_1.size(): " << check_1.size() << " s.size(): " << s.size() << endl;

	}
	//cout << "size of idToIdxP" << cnt << endl;

	//cout << "s.size(): " << s.size() << endl;
	//cout << "maxId: " << maxId << endl;

	for (int i : s) {
		source_set.push_back(i);
		//cout << "i: " << i << endl;
	}
	if (source_set.size() != s.size()) {
		//throw std::invalid_argument("source_set is not equivalent to s_set!!");
	}


	// Create the compatibility/scores matrix
	comp.clear();
	comp.resize(maxId + 1);


	//cout << "resize the comp successfully!" << endl;

}

void Allocation::dynamic(set<int>& active_source) {
	int check = 0, check_1 = 0;
	//cout << "maxId: " << maxId << endl;

	for (int i = 0; i < maxId + 1; i++) {
		comp[i].clear();
		// maxid+1
		comp[i].resize(maxId + 1, -1);
		for (int j = 0; j < comp[i].size(); j++) {
			check += 1;
			if (comp[i][j] != -1) {
				check_1 += 1;
				comp[i][j] = -1;
				//cout << "error in comp[i][j]: "<<"i: "<<i<<", j: "<<j<<", comp[i][j]: " << comp[i][j] << endl;
			}
		}
	}
	//cout << "number of check: " << check << ", number of check_1: " << check_1 << endl;
	// Fill the compatibility/scores matrix

	set<int> temp;

	for (auto i = active_source.begin(); i != active_source.end(); i++) {
		temp.insert(*i);
	}
	int cnt = temp.size();
	//cout << "number of pairs: " << nbPairs << endl;
	//cout << "number of active nodes: " << cnt << endl;
	for (int i = 0; i < nbPairs; i++) {
		//cout << "pairs[i].nbEdges: " << pairs[i].nbEdges << endl;
		if (pairs[i].source > maxId) {
			cout << "error in source: " << "i: " << i << ";" << "pairs[i].souce: " << pairs[i].source << endl;
		}
		for (int j = 0; j < pairs[i].nbEdges; j++) {
			//cout << "i: " << i << ";" << " j: " << j << ";" << " pairs[i].targets[j]: " << pairs[i].targets[j] << endl;
			//cout << "i: " << i << " j: " << j << endl;
			//cout << "pairs[i].source: " << pairs[i].source << "; " << "pairs[i].targets[j]: " << pairs[i].targets[j] << endl;
			if (pairs[i].targets[j] > maxId) {
				cout << "error in target: " << "i: " << i << ";" << " j: " << j << "; " << "pairs[i].targets[j]: " << pairs[i].targets[j] << endl;
			}
			if (active_source.find(pairs[i].source) != active_source.end() && active_source.find(pairs[i].targets[j]) != active_source.end()) {
				comp[pairs[i].source][pairs[i].targets[j]] = 1;
				temp.insert(pairs[i].source);
				temp.insert(pairs[i].targets[j]);
			}
			else {
				if (comp[pairs[i].source][pairs[i].targets[j]] != -1) {
					cout << "error in the compatibility graph," << "please print out the corresponding compatibility. " << "source: " << pairs[i].source << " target: " << pairs[i].targets[j] << "comp[pairs[i].source][pairs[i].targets[j]]: " << comp[pairs[i].source][pairs[i].targets[j]] << endl;
				}
			}

		}
	}
	int cnt_1 = temp.size();
	//cout << "number of active pairs: " << cnt_1 << endl;
	if (cnt != cnt_1) {
		cout << "error in generating comp" << endl;
		cout << "number of cnt: " << cnt << " number of cnt_1:" << cnt_1 << endl;
	}
	//cout << "number of edges" << cnt << endl;
	//cout << "number of valid nodes: " << temp.size() << endl;


	// Create the cycles
	set<int> temp_1;
	int num_cycle = 0;
	int cnt_2 = 0;
	types.resize(2);
	cycles.clear();
	for (int i = 0; i < maxId + 1; i++) {
		vector<bool> hbP(maxId + 1, false);
		//if (i == 13) cout << " idToIdxP[i].size(): " << idToIdxP[i].size() << endl;
		for (int j = 0; j < idToIdxP[i].size(); j++) {
			cnt_2 += 1;
			int idx = idToIdxP[i][j];
			//cout << "idx_i: " << i << " idx_j: " << j << " idx: " << idx << endl;
			for (int k = 0; k < pairs[idx].nbEdges; k++) {
				int tId = pairs[idx].targets[k];
				if (hbP[tId] == false) {
					if (comp[tId][i] == 1 && i < tId) {
						num_cycle += 1;
						if (active_source.count(tId) == 0 or active_source.count(i) == 0) {
							cout << "tId or i is not the active source" << "please print out comp[tId][i]: " << comp[tId][i] << endl;;
						}
						Cycle c;
						c.id = cycles.size();
						c.size = 2;
						c.isC = 0;
						c.idX.push_back(i); c.idX.push_back(tId);
						temp_1.insert(i);
						temp_1.insert(tId);
						cycles.push_back(c);
						types[0]++;
					}
					vector<bool> hbP2(maxId + 1, false);
					for (int l = 0; l < idToIdxP[tId].size(); l++) {
						int idx2 = idToIdxP[tId][l];
						for (int m = 0; m < pairs[idx2].nbEdges; m++) {
							int tId2 = pairs[idx2].targets[m];
							if (hbP2[tId2] == false) {
								if (comp[tId2][i] == 1 && comp[tId][i] == 1 && comp[tId2][tId] == 1 && i < tId && i < tId2) {
									if (active_source.count(tId) == 0 or active_source.count(i) == 0 or active_source.count(tId2) == 0) {
										cout << "tId2 is not the active source" << endl;;
									}
									num_cycle += 1;
									Cycle c;
									c.id = cycles.size();
									c.size = 3;
									c.isC = 0;
									c.idX.push_back(i); c.idX.push_back(tId); c.idX.push_back(tId2);
									temp_1.insert(i);
									temp_1.insert(tId);
									temp_1.insert(tId2);
									cycles.push_back(c);
									types[1]++;
								}
							}
							hbP2[tId2] = true;
						}
					}
				}
				hbP[tId] = true;
			}
		}
	}
	//cout << "number of valid comp" << cnt_2 << endl;
	//cout << "number of cycles: " << num_cycle << endl;
	//cout << "number of valid nodes after generating cycles" << temp_1.size() << endl;
}

void Allocation::printProb() {
	cout << "Instance " << name << endl;
	for (int i = 0; i < nbPairs; i++) {
		pairs[i].print();
	}
	/*	for(int i=0; i<maxId+1; i++){
			for(int j=0;j<maxId+1;j++){
				cout << comp[i][j] << "\t";
			}
			cout << endl;
		}*/
		/*	cout << "Cycles: " << endl;
			for(int i=0;i<cycles.size();i++){
				cycles[i].print();
			}*/
}