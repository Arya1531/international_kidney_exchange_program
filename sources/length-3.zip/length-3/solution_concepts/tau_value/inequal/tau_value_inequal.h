#pragma once

#include <iostream>
#include <string>
#include <fstream>
#include <vector>

#include <lemon/list_graph.h> // needed for ListDigraph
#include <lemon/matching.h>
#include <lemon/adaptors.h>
#include <lemon/core.h>
#include <lemon/base.cc>
#include <lemon/concepts/maps.h>

#include <time.h>
#include <glpk.h>
#include <iomanip>


#include <cfloat>
#include <math.h>
#include <stdio.h>
#include <iterator>
#include "gurobi_c++.h"


using namespace lemon;
using namespace std;

double cpuTime();
bool is_next_char_digit(string& line, unsigned int l);
unsigned int char2uint(char& p);
void undi_lemon(unsigned int& m, vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, vector<unsigned short int>& label_positions, ListGraph& g, ListDigraph& g_original, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, ListGraph::EdgeMap<double>& edge_card_weight, ListDigraph::ArcMap<unsigned short int>& arc_card_weight, unsigned short int& no_of_nodes);
void coop_game(vector<double>& v, vector<double>& v_impu, vector<double>& v_S, unsigned int& S, vector<unsigned short int>& s, vector<ListGraph::Node>& c, bool& dispy, vector<unsigned short int>& Vp_start, unsigned short int& N, ListGraph::NodeMap<bool>& active_nodes, vector<bool>& leaving, unsigned short int& Q, bool& arbitray_maximum, double& game_generation, vector<vector<double>>& time_breakdown, unsigned short int inst, Allocation& allo, set<int>& active_source, vector<int>& source_set, vector<int>& node_set, vector<unsigned short int>& label_positions, vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, vector<map<int, int>>& cycle_dis, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit);
void xml_parser(string& line, vector<unsigned short int>& node_labels, vector<unsigned short int>& label_positions, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, unsigned short int& k, ListGraph& g, ListDigraph& g_original, vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, unsigned int& m, unsigned short int& no_of_nodes);

void min_d_1(vector<unsigned short int>& node_arrives, vector<bool>& leaving, ListGraph::NodeMap<bool>& active_nodes, ListDigraph::NodeMap<bool>& active_nodes_original, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, bool& disp, vector<unsigned short int>& no_of_active_nodes, unsigned short int& N, vector<unsigned short int>& Vp_start, unsigned short int& periods, bool& dispy, vector<unsigned short int>& s, unsigned short int& Q, vector<double>& v, bool& target_omega, vector<double>& target, vector<double>& credit, vector<double>& v_impu, vector<double>& d, double& M_total, double& d_total, bool& c_involved, bool& arbitray_maximum, vector<double>& v_S, unsigned int& S, double& d_c_total, int& convex, int& quasibalanced, int& coincidence, unsigned short int inst, bool& lex_min, int& unique, double& game_generation, double& solution_time, double& scenario_time, double& max_d, vector<vector<double>>& average_d_period, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, vector<vector<double>>& time_breakdown, set<int>& active_source, vector<int>& source_set, Allocation& allo, vector<int>& node_set, vector<unsigned short int>& label_positions, vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, double& relative_deviation, vector<map<int, int>>& cycle_dis, vector<double>& relative_optimal);
void arbitraryMaximum(vector<unsigned short int>& node_arrives, vector<bool>& leaving, ListGraph::NodeMap<bool>& active_nodes, ListDigraph::NodeMap<bool>& active_nodes_original, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, bool& disp, vector<unsigned short int>& no_of_active_nodes, unsigned short int& N, vector<unsigned short int>& Vp_start, unsigned short int& periods, bool& dispy, vector<unsigned short int>& s, unsigned short int& Q, vector<double>& v, bool& target_omega, vector<double>& target, vector<double>& credit, vector<double>& d, vector<double>& v_impu, double& M_total, double& d_total, bool& c_involved, bool& arbitray_maximum, vector<double>& v_S, unsigned int& S, int& convex, int& quasibalanced, int& coincidence, unsigned short int inst, double& max_d, int& unique, double& game_generation, double& solution_time, vector<vector<double>>& average_d_period, vector<vector<double>>& time_breakdown, set<int>& active_source, vector<int>& source_set, Allocation& allo, vector<int>& node_set, vector<unsigned short int>& label_positions, vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, double& relative_d1_arbitrary, vector<map<int, int>>& cycle_dis, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, vector<double>& relative_optimal);
void initial_pairs(vector<unsigned short int>& Vp_start, unsigned short int& N, ListGraph::NodeMap<bool>& active_nodes, ListDigraph::NodeMap<bool>& active_nodes_original, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, set<int>& active_source, vector<int>& source_set);
void period_0(unsigned short int& Q, vector<unsigned short int>& no_of_active_nodes, unsigned short int& N, vector<unsigned short int>& s, vector<unsigned short int>& Vp, vector<unsigned short int>& Vp_start, vector<unsigned short int>& node_arrives, ListGraph::NodeMap<bool>& active_nodes, ListDigraph::NodeMap<bool>& active_nodes_original, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, vector<double>& credit, vector<bool>& leaving, set<int>& active_source, vector<int>& source_set);
void arrival_times(vector<unsigned short int>& node_arrives, vector<unsigned short int>& Vp_start, unsigned short int& N, ListGraph::NodeMap<bool>& active_nodes, vector<ListGraph::Node>& c, unsigned short int& periods);
void changing_nodes(ListGraph::NodeMap<bool>& active_nodes, ListDigraph::NodeMap<bool>& active_nodes_original, vector<bool>& leaving, vector<unsigned short int>& no_of_active_nodes, unsigned short int& N, vector<unsigned short int>& Vp_start, vector<unsigned short int>& node_arrives, unsigned short int& Q, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, vector<unsigned short int>& s, vector<double>& target, set<int>& active_source, vector<int>& source_set);
void de2bi(unsigned int& k, vector<bool>& a, unsigned short int& N);
void ILP_d1_gurobi(unsigned short int& Q, unsigned short int& N, vector<unsigned short int>& Vp_start, double& M, double& M_total, vector<unsigned short int>& s, vector<double>& init_alloc, vector<bool>& leaving, vector<double>& d, double& d_total, bool& c_involved, vector<double>& credit, bool lex_min, unsigned short int inst, vector<vector<double>>& average_d_period, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, Allocation& allo, set<int>& active_source, vector<int>& node_set, vector<unsigned short int>& label_positions, vector<map<int, int>>& cycle_dis);
double tau(vector<double>& benefit, unsigned short int& n, unsigned int& s, double& prec, bool& disp, vector<double>& tau_value, bool& quasibal, vector<double>& v_s);
bool convex_game(unsigned short int& n, unsigned int& s, vector<double>& v, double& prec);
void de2bi_card(unsigned int& k, vector<bool>& a, unsigned short int& n, unsigned short int& card);
double frac(double ori);
void epsilon_func(vector<double> target, vector<double> credit, double& epsilon, unsigned short int N);
void lex_min_n_star(vector<double>& d_t, bool& lex_min, unsigned short int& t_star, unsigned short int& N, Allocation& allo, double& M, vector<unsigned short int>& Vp_start, double& epsilon, unsigned short int& n_star, vector<double>& bound, vector<unsigned short int>& N_star, vector<GRBVar>& var_lexmin, vector<GRBModel>& vector_model, unsigned short int& track, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, unsigned short int& inst, vector<unsigned short int>& label_positions);
void lex_min_d_star(vector<double>& d_t, bool& lex_min, unsigned short int& t_star, unsigned short int& N, double& epsilon, unsigned short int& n_star, vector<double>& bound, vector<unsigned short int>& N_star, vector<unsigned short int>& Vp_start, vector<GRBVar>& var_lexmin, vector<GRBModel>& vector_model, unsigned short int& track, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, unsigned short int& inst, double& M, Allocation& allo, vector<unsigned short int>& label_positions);
void lexmin_searching(vector<double>& d_t, bool& lex_min, unsigned short int& t_star, unsigned short int& N, double& epsilon, unsigned short int& n_star, vector<double>& bound, vector<unsigned short int>& N_star, vector<unsigned short int>& Vp_start, vector<GRBVar>& var_lexmin, unsigned short int inst, vector<GRBModel>& vector_model, unsigned short int& track, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, double& M, Allocation& allo, vector<unsigned short int>& label_positions);
void sort_d_t(vector<double>& d_t, vector<GRBVar>& isCycleUsed, vector<unsigned short int>& label_positions, unsigned short int& N, vector<unsigned short int>& Vp_start, Allocation& allo, vector<double>& bound, unsigned short int& t, double& epsilon, vector<GRBVar>& var_lexmin, vector<unsigned short int>& N_star);
double solve_obj(Allocation& allo, set<int>& active_source, vector<int>& node_set, vector<unsigned short int>& label_positions, vector<map<int, int>>& cycle_dis, bool& is_cycle_dis, unsigned short int Q, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, unsigned short int inst, unsigned short int N);
void country_sizes(unsigned short int& N, vector<unsigned short int>& Vp, vector<unsigned short int>& Vp_start, bool& dispy, unsigned short int& graph_size);