/*
*    int_kidney_exchange
*    shapley+nucleolus.cpp
*    Purpose: computational study for Computing Balanced Solutions for Large International Kidney
*			  Exchange Schemes When $\ell=3$
*             using the shapley value and nuceolus as initial allocations with equal country sizes
*
*
*    @version 1.0 03/03/2025
*
*    This program is free software: you can redistribute it and/or modify
*    it under the terms of the GNU General Public License as published by
*    the Free Software Foundation, either version 3 of the License, or
*    (at your option) any later version and the Gurobi License.
*
*    This program is distributed in the hope that it will be useful,
*    but WITHOUT ANY WARRANTY; without even the implied warranty of
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
*    GNU General Public License for more details.
*
*/

#include "Allocation.h"
#include "shapley_nucleolus_steady_main.h"  




int main() {
	cout << "I solemnly swear that I am up to no good." << endl;
	bool c_involved = false;// true: credits considred; false:without credits 
	bool arbitray_maximum = false; //true: arbitray maximum cycple packing
	bool initial_nucl = true; // true: nucleolus; false: shapley
	bool lex_min = false;
	string solution_concept;
	string cycle_length = "length-3";
	string country_size = "equal";
	string version;
	bool d1 = false;
	bool d_c = true;
	bool lexmin_call = false;
	bool lexmin_c_call = false;
	bool arbitrary = false;
	map<int, int> temp;
	vector<map<int, int>> cycle_dis_for_all(7, temp);
	if (d1) {
		version = "d1";
	}
	else {
		if (lexmin_call) {
			version = "lexmin_call";
		}
		if (lexmin_c_call) {
			version = "lexmin_c_call";
		}
		if (d_c) {
			version = "d1_c";
		}
		if (arbitrary) {
			version = "arbitrary";
		}
	}

	if (initial_nucl) {
		solution_concept = "nucleolus";
		cout << solution_concept << endl;
	}
	else {
		solution_concept = "shapley";
		cout << solution_concept << endl;
	}
	vector<double> relative_d1_N(12, 0);
	vector<double> relative_d1_N_c(12, 0);
	vector<double> relative_arbitrary_N(12, 0);
	vector<double> relative_d1_N_initial_allocation(12, 0);
	vector<double> relative_lexmin(12, 0);
	vector<double> relative_lexmin_c(12, 0);
	vector<double> max_d1_N(12, 0);
	vector<double> max_d1_N_c(12, 0);
	vector<double> max_arbitrary_N(12, 0);
	vector<double> max_lexmin(12, 0);
	vector<double> max_lexmin_c(12, 0);
	vector<double> M_N(12, 0);
	vector<double> M_N_d_c(12, 0);
	vector<double> M_N_d_arbitrary(12, 0);
	vector<double> M_N_lex_min(12, 0);
	vector<double> M_N_lex_min_c(12, 0);
	vector<double> core_dis_N(12, 0);
	vector<double> core_dis_N_c(12, 0);
	vector<double> core_dis_N_arbitrary(12, 0);
	vector<long> out_of_core(12, 0);
	vector<long> out_of_core_c(12, 0);
	vector<long> out_of_core_arbitrary(12, 0);
	vector<double> data_preparation_N(12, 0);
	vector<double> graph_building_N(12, 0);
	vector<double> game_generation_arbitrary_N(12, 0);
	vector<double> game_generation_d1_N(12, 0);
	vector<double> game_generation_d1_c_N(12, 0);
	vector<double> game_generation_lexmin_N(12, 0);
	vector<double> game_generation_lexmin_c_N(12, 0);
	vector<double> time_arbitrary_N(12, 0);
	vector<double> time_d1_N(12, 0);
	vector<double> time_d1_c_N(12, 0);
	vector<double> time_lex_min_N(12, 0);
	vector<double> time_lex_min_c_N(12, 0);
	vector<double> total_time_arbitrary_N(12, 0);
	vector<double> total_time_d1_N(12, 0);
	vector<double> total_time_d1_c_N(12, 0);
	vector<double> total_time_lex_min_N(12, 0);
	vector<double> total_time_lex_min_c_N(12, 0);
	vector<double> solution_concept_time_arbitrary_N(12, 0);
	vector<double> solution_concept_time_d1_N(12, 0);
	vector<double> solution_concept_time_d1_c_N(12, 0);
	vector<double> solution_concept_time_lexmin_N(12, 0);
	vector<double> solution_concept_time_lexmin_c_N(12, 0);
	unsigned short int N; // number of countries/players
	unsigned short int inst; // instance number, integer between 0 and 99
	vector<double> temp_period(24, 0);
	vector<vector<double>> deviation_period(7, temp_period);
	vector<vector<vector<double>>> average_d_period(5, deviation_period);
	vector<double> time_breakdown(400, 0);
	vector <vector<double>> time_breakdown_temp(7, time_breakdown);
	vector<vector<vector<double>>> time_breakdown_per_inst(5, time_breakdown_temp);
	vector<double> time_temp(100, 0);
	vector<vector<double>> time_prep(7, time_temp), time_graph(7, time_temp);
	vector<int> not_optimal(100, 0);
	vector<vector<int>> track_not_optimal_temp(7, not_optimal);
	vector<vector<vector<int>>> track_not_optimal(4, track_not_optimal_temp);
	vector<vector<vector<int>>> track_time_limit(4, track_not_optimal_temp);
	vector<double> temp_relative(7, 0);
	vector<vector<double>> relative_optimal(4, temp_relative);
	for (N = 4; N < 9; ++N) {
		double relative_d1 = 0;
		double relative_d1_c = 0;
		double relative_d1_arbitrary = 0;
		double relative_d1_initial_allocation = 0;
		double relative_lexmin_0 = 0;
		double relative_lexmin_c_0 = 0;
		double data_preparation = 0;
		double graph_building = 0;
		double game_generation_arbitrary = 0;
		double game_generation_d1 = 0;
		double game_generation_d1_c = 0;
		double game_generation_lexmin = 0;
		double game_generation_lexmin_c = 0;
		double time_arbitrary = 0;
		double time_d1 = 0;
		double time_d1_c = 0;
		double time_lex_min = 0;
		double time_lex_min_c = 0;
		double total_time_arbitrary = 0;
		double total_time_d1 = 0;
		double total_time_d1_c = 0;
		double total_time_lex_min = 0;
		double total_time_lex_min_c = 0;
		double solution_concept_time_arbitrary = 0;
		double solution_concept_time_d1 = 0;
		double solution_concept_time_d1_c = 0;
		double solution_concept_time_lexmin = 0;
		double solution_concept_time_lexmin_c = 0;
		double max_d1 = 0;
		double max_d1_c = 0;
		double max_d1_arbitrary = 0;
		double max_lexmin_0 = 0;
		double max_lexmin_c_0 = 0;
		double M_100 = 0;
		double M_100_d_c = 0;
		double M_100_d_arbitrary = 0;
		double M_lex_min = 0;
		double M_lex_min_c = 0;
		double core_100 = 0;
		double core_d = 0;
		double core_d_c = 0;
		double core_d_arbitrary = 0;
		long negative_core = 0;
		long negative_core_d = 0;
		long negative_core_d_c = 0;
		long negative_core_d_arbitrary = 0;
		map<int, int> cycle_dis;
		for (inst = 0; inst < 100; ++inst) {
			bool dispy = false; // true: information in terminal while running
			bool disp = false; // true: extremely detailed information while running, avoid with large graphs
			Allocation allo;

			unsigned short int years = 6;
			unsigned short int periods_per_year = 4;
			unsigned short int graph_size = 2000;

			// read the data
			string line;
			ifstream inp;
			inp.open("/data/genxml-" + to_string(inst) + ".xml"); // 1 out of the 100 instances generated by William Pettersson's web tool: https://wpettersson.github.io/kidney-webapp/#/
			getline(inp, line);
			inp.close();

			unsigned short int Vp = 4 * (unsigned short int)((graph_size / 4) / N);
			unsigned short int initialSize = Vp / 4;;
			unsigned short int no_of_nodes = N * Vp;
			vector<unsigned int> arc_out(0, 0);
			vector<unsigned int> arc_in(0, 0);
			unsigned int m = 0;
			unsigned short int k = 0;
			unsigned short int M = 0;
			double M_total = 0;
			vector<unsigned short int> node_labels(no_of_nodes, 0);
			vector<unsigned short int> label_positions(graph_size, graph_size + 1);
			set<int> active_source;
			vector<int> source_set;
			ListGraph g;
			ListDigraph g_original;
			vector<ListGraph::Node> c(no_of_nodes);
			vector<ListGraph::Node> c_b(no_of_nodes);
			vector<ListDigraph::Node> c_original(no_of_nodes);
			vector<int> node_set;
			double t0 = cpuTime();
			// interpret the data
			xml_parser(line, node_labels, label_positions, c, c_b, c_original, k, g, g_original, arc_in, arc_out, m, no_of_nodes);
			allo.load(arc_in, arc_out, source_set);
			double t1 = cpuTime();
			data_preparation += t1 - t0;
			time_prep[N - 4][inst] = t1 - t0;

			unsigned short int periods = years * periods_per_year;
			vector<unsigned short int> no_of_active_nodes(N, initialSize);
			ListGraph::NodeMap<bool> active_nodes(g);
			ListDigraph::NodeMap<bool> active_nodes_original(g_original);
			for (unsigned short int i = 0; i < N; i++) {
				for (unsigned short int j = 0; j < Vp; j++) {
					active_nodes[c[i * Vp + j]] = false;
					active_nodes[c_b[i * Vp + j]] = false;
					active_nodes_original[c_original[i * Vp + j]] = false;
				}
			}

			// read the seed
			string line_seed;
			ifstream seed_doc;
			seed_doc.open("/seeds/n" + to_string(N) + "inst" + to_string(inst) + ".txt");
			getline(seed_doc, line_seed);
			seed_doc.close();
			int seed = 0;
			cout << "line seed" << line_seed << endl;
			seed = stoi(line_seed);
			srand(seed);
			// determining starting pairs and arrival times of others
			initial_pairs(Vp, N, active_nodes, active_nodes_original, c, c_b, c_original, initialSize, active_source, source_set);
			vector<unsigned short int> node_arrives(no_of_nodes, 0);
			arrival_times(node_arrives, Vp, N, active_nodes, c, periods, disp);
			if (disp) {
				cout << endl;
				vector<unsigned short int> bla(periods, 0);
				for (unsigned short int i = 0; i < no_of_nodes; i++)
					bla[node_arrives[i]]++;
				cout << "no of arrivals: ";
				for (unsigned short int i = 0; i < periods; i++)
					cout << bla[i] << " ";
				cout << endl << endl;
			}
			t1 = cpuTime();
			double rand_time = t1 - t0;

			ListGraph::EdgeMap<double> edge_card_weight(g, 0);
			ListDigraph::ArcMap<unsigned short int> arc_card_weight(g_original, 0);
			t0 = cpuTime();
			// buid the graph
			undi_lemon(m, arc_in, arc_out, label_positions, g, g_original, c, c_b, c_original, edge_card_weight, arc_card_weight, no_of_nodes);
			t1 = cpuTime();
			graph_building += t1 - t0;
			time_graph[N - 4][inst] = t1 - t0;

			unsigned int S = pow(2, N) - 2;
			vector<double> v(S + 1, 0);
			vector<unsigned short int> s(N, 0);
			double prec = pow(10, -7);
			vector<double> init_alloc(N, 0);
			unsigned short int I1 = 0;
			unsigned short int I11 = 0;
			unsigned short int I2 = 0;
			vector<double> credit(N, 0);
			vector<double> deviation(N, 0);
			vector<bool> pos(N, false);
			vector<unsigned short int> w(N, 0);
			unsigned short int p;
			vector<unsigned short int> lb(N, 0);
			vector<unsigned short int> ub(N, 0);
			double opt = 0;
			vector<bool> leaving(no_of_nodes, false);
			unsigned short int Q = 0;
			vector<pair<int, int>> arc_pair;
			vector<int> nodeset(graph_size, 0);
			vector<pair<int, int>> cycle_distri;
			vector<vector<unsigned short int>> actual_alloc;
			vector<double> d(N, 0);
			double d_total = 0;
			double d_c_total = 0;
			vector<double> target(N, 0);
			vector<unsigned short int> s_ideal(N, 0);
			vector<double> init_alloc_ideal(N, 0);
			vector<unsigned short int> s_ideal_d1(N, 0);
			double max_d = 0;
			int n_t = 0;

			//--------------arbitray maximum cycle packing--------------------
			if (arbitrary) {
				cout << N << "countries" << " " << "instance_" << inst << "arbitrary starts" << endl;
				arbitray_maximum = true;
				t0 = cpuTime();
				period_0(Q, no_of_active_nodes, N, s, Vp, node_arrives, active_nodes, active_nodes_original, c, c_b, c_original, credit, active_source, source_set);
				arbitraryMaximum(node_arrives, leaving, active_nodes, active_nodes_original, c, c_b, c_original, disp, no_of_active_nodes, N, Vp, periods, dispy, s, Q, v, initial_nucl, credit, d, M_total, d_total, c_involved, arbitray_maximum, initialSize, S, prec, init_alloc, inst, max_d, game_generation_arbitrary, solution_concept_time_arbitrary, average_d_period[0], time_breakdown_per_inst[0], active_source, source_set, allo, node_set, label_positions, arc_in, arc_out, relative_d1_arbitrary, cycle_dis);
				t1 = cpuTime();
				total_time_arbitrary += t1 - t0;
				time_breakdown_per_inst[0][N - 4][inst * 4] = t1 - t0;
				arbitray_maximum = false;
				M_100_d_arbitrary += M_total;
				max_d1_arbitrary += max_d;
				cout << "total number of transplants" << M_100_d_arbitrary << endl;
				cout << N << "countries" << " " << "instance_" << inst << "arbitrary done...";
				cout << "--------------cycle distribution---------------" << endl;
				for (const auto& pair : cycle_dis) {
					cout << pair.first << " : " << pair.second << endl;
				}
			}
			//------------------d1------------------
			if (d1) {
				cout << N << "countries" << " " << "instance_" << inst << "d1 starts" << endl;
				period_0(Q, no_of_active_nodes, N, s, Vp, node_arrives, active_nodes, active_nodes_original, c, c_b, c_original, credit, active_source, source_set);
				t0 = cpuTime();
				min_d_1(node_arrives, leaving, active_nodes, active_nodes_original, c, c_b, c_original, disp, no_of_active_nodes, N, Vp, periods, dispy, s, Q, v, initial_nucl, credit, d, M_total, d_total, c_involved, arbitray_maximum, initialSize, S, prec, init_alloc, d_c_total, inst, lex_min, max_d, game_generation_d1, solution_concept_time_d1, time_d1, average_d_period[1], track_not_optimal[0], track_time_limit[0], time_breakdown_per_inst[1], active_source, source_set, allo, node_set, label_positions, arc_in, arc_out, n_t, relative_d1, cycle_dis, relative_optimal[0]);
				t1 = cpuTime();
				total_time_d1 += t1 - t0;
				time_breakdown_per_inst[1][N - 4][inst * 4] = t1 - t0;
				max_d1 += max_d;
				cout << "relative_d1: " << relative_d1 << endl;
				cout << "the number of countries: " << N << " " << "relative_d1" << " " << inst << " " << relative_d1 / (inst + 1) << endl;
				M_100 += M_total;
				cout << "the number of countries: " << N << " " << "M_100" << " " << inst << " " << M_100 / (inst + 1);
				cout << N << "countries" << " " << "instance_" << inst << "d1 done...";
				cout << "--------------cycle distribution---------------" << endl;
				for (const auto& pair : cycle_dis) {
					cout << pair.first << " : " << pair.second << endl;
				}
			}
			// --------------------d1+c-------------------
			if (d_c) {
				cout << N << "countries" << " " << "instance_" << inst << "d1+c starts" << endl;
				c_involved = true;
				period_0(Q, no_of_active_nodes, N, s, Vp, node_arrives, active_nodes, active_nodes_original, c, c_b, c_original, credit, active_source, source_set);
				t0 = cpuTime();
				min_d_1(node_arrives, leaving, active_nodes, active_nodes_original, c, c_b, c_original, disp, no_of_active_nodes, N, Vp, periods, dispy, s, Q, v, initial_nucl, credit, d, M_total, d_total, c_involved, arbitray_maximum, initialSize, S, prec, init_alloc, d_c_total, inst, lex_min, max_d, game_generation_d1_c, solution_concept_time_d1_c, time_d1_c, average_d_period[2], track_not_optimal[1], track_time_limit[1], time_breakdown_per_inst[2], active_source, source_set, allo, node_set, label_positions, arc_in, arc_out, n_t, relative_d1_c, cycle_dis, relative_optimal[1]);
				t1 = cpuTime();
				total_time_d1_c += t1 - t0;
				time_breakdown_per_inst[2][N - 4][inst * 4] = t1 - t0;
				max_d1_c += max_d;
				c_involved = false;
				M_100_d_c += M_total;
				cout << N << "countries" << " " << "instance_" << inst << "d1+c done..." << endl;
			}
			//-------------------lexmin--------------
			if (lexmin_call) {
				std::cout << N << "countries" << " " << "instance_" << inst << "lexmin starts";
				lex_min = true;
				period_0(Q, no_of_active_nodes, N, s, Vp, node_arrives, active_nodes, active_nodes_original, c, c_b, c_original, credit, active_source, source_set);
				t0 = cpuTime();
				min_d_1(node_arrives, leaving, active_nodes, active_nodes_original, c, c_b, c_original, disp, no_of_active_nodes, N, Vp, periods, dispy, s, Q, v, initial_nucl, credit, d, M_total, d_total, c_involved, arbitray_maximum, initialSize, S, prec, init_alloc, d_c_total, inst, lex_min, max_d, game_generation_lexmin, solution_concept_time_lexmin, time_lex_min, average_d_period[3], track_not_optimal[2], track_time_limit[2], time_breakdown_per_inst[3], active_source, source_set, allo, node_set, label_positions, arc_in, arc_out, n_t, relative_lexmin_0, cycle_dis, relative_optimal[2]);
				t1 = cpuTime();
				total_time_lex_min += t1 - t0;
				time_breakdown_per_inst[3][N - 4][inst * 4] = t1 - t0;
				max_lexmin_0 += max_d;
				lex_min = false;
				M_lex_min += M_total;
				std::cout << N << "countries" << " " << "instance_" << inst << "relative deviation" << d_total / M_total << "lexmin done...";
				cout << "--------------cycle distribution---------------" << endl;
				for (const auto& pair : cycle_dis) {
					cout << pair.first << " : " << pair.second << endl;
				}
			}
			//-----------------lexmin+c----------------
			if (lexmin_c_call) {
				std::cout << N << "countries" << " " << "instance_" << inst << "lexmin+c starts...";
				lex_min = true;
				c_involved = true;
				period_0(Q, no_of_active_nodes, N, s, Vp, node_arrives, active_nodes, active_nodes_original, c, c_b, c_original, credit, active_source, source_set);
				t0 = cpuTime();
				min_d_1(node_arrives, leaving, active_nodes, active_nodes_original, c, c_b, c_original, disp, no_of_active_nodes, N, Vp, periods, dispy, s, Q, v, initial_nucl, credit, d, M_total, d_total, c_involved, arbitray_maximum, initialSize, S, prec, init_alloc, d_c_total, inst, lex_min, max_d, game_generation_lexmin_c, solution_concept_time_lexmin_c, time_lex_min_c, average_d_period[4], track_not_optimal[3], track_time_limit[3], time_breakdown_per_inst[4], active_source, source_set, allo, node_set, label_positions, arc_in, arc_out, n_t, relative_lexmin_c_0, cycle_dis, relative_optimal[3]);
				t1 = cpuTime();
				total_time_lex_min_c += t1 - t0;
				time_breakdown_per_inst[4][N - 4][inst * 4] = t1 - t0;
				max_lexmin_c_0 += max_d;
				lex_min = false;
				c_involved = false;
				M_lex_min_c += M_total;
				std::cout << N << "countries" << " " << "instance_" << inst << "relative deviation" << d_total / M_total << "lexmin+c done...";
			}


		}
		cycle_dis_for_all[N - 4] = cycle_dis;
		relative_d1_N[N - 4] = relative_d1 / 100;
		relative_d1_N_c[N - 4] = relative_d1_c / 100;
		relative_d1_N_initial_allocation[N - 4] = relative_d1_initial_allocation / 100;
		relative_arbitrary_N[N - 4] = relative_d1_arbitrary / 100;
		relative_lexmin[N - 4] = relative_lexmin_0 / 100;
		relative_lexmin_c[N - 4] = relative_lexmin_c_0 / 100;
		max_d1_N[N - 4] = max_d1 / 100;
		max_d1_N_c[N - 4] = max_d1_c / 100;
		max_arbitrary_N[N - 4] = max_d1_arbitrary / 100;
		max_lexmin[N - 4] = max_lexmin_0 / 100;
		max_lexmin_c[N - 4] = max_lexmin_c_0 / 100;
		M_N[N - 4] = M_100 / 100;
		M_N_d_c[N - 4] = M_100_d_c / 100;
		M_N_d_arbitrary[N - 4] = M_100_d_arbitrary / 100;
		M_N_lex_min[N - 4] = M_lex_min / 100;
		M_N_lex_min_c[N - 4] = M_lex_min_c / 100;
		data_preparation_N[N - 4] = data_preparation / 100;
		graph_building_N[N - 4] = graph_building / 100;
		game_generation_arbitrary_N[N - 4] = game_generation_arbitrary / 100;
		game_generation_d1_N[N - 4] = game_generation_d1 / 100;
		game_generation_d1_c_N[N - 4] = game_generation_d1_c / 100;
		game_generation_lexmin_N[N - 4] = game_generation_lexmin / 100;
		game_generation_lexmin_c_N[N - 4] = game_generation_lexmin_c / 100;
		time_arbitrary_N[N - 4] = time_arbitrary / 100;
		time_d1_N[N - 4] = time_d1 / 100;
		time_d1_c_N[N - 4] = time_d1_c / 100;
		time_lex_min_N[N - 4] = time_lex_min / 100;
		time_lex_min_c_N[N - 4] = time_lex_min_c / 100;
		total_time_arbitrary_N[N - 4] = total_time_arbitrary / 100;
		total_time_d1_N[N - 4] = total_time_d1 / 100;
		total_time_d1_c_N[N - 4] = total_time_d1_c / 100;
		total_time_lex_min_N[N - 4] = total_time_lex_min / 100;
		total_time_lex_min_c_N[N - 4] = total_time_lex_min_c / 100;
		solution_concept_time_arbitrary_N[N - 4] = solution_concept_time_arbitrary / 100;
		solution_concept_time_d1_N[N - 4] = solution_concept_time_d1 / 100;
		solution_concept_time_d1_c_N[N - 4] = solution_concept_time_d1_c / 100;
		solution_concept_time_lexmin_N[N - 4] = solution_concept_time_lexmin / 100;
		solution_concept_time_lexmin_c_N[N - 4] = solution_concept_time_lexmin_c / 100;
		ofstream res;
		res.open(version + "/" + cycle_length + "/" + country_size + "/steady_results_l3_" + to_string(N) + ".txt", ofstream::out | ofstream::trunc);
		for (unsigned short int i = 0; i < N - 3; i++) {
			res << i + 4 << "countries" << endl;
			if (d1) {
				res << "data preparation: " << data_preparation_N[i] << endl;
				res << "build graph: " << graph_building_N[i] << endl;
				res << "minimizing d_1: " << relative_d1_N[i] << endl;
				res << "minimizing max_d_1: " << max_d1_N[i] << endl;
				res << "average number of transplants: " << M_N[i] << endl;
				res << "total time: " << total_time_d1_N[i] << endl;
				res << "scenario time: " << time_d1_N[i] << endl;
				res << "game generation: " << game_generation_d1_N[i] << endl;
				res << "solution concept: " << solution_concept_time_d1_N[i] << endl;
				res << "----------accumulated deviations-------------" << endl;
				for (int j = 0; j < 24; j++) {
					res << "round j:" << (double)average_d_period[1][i][j] / 100 << endl;
				}

				res << "------------not optimal------------------" << endl;
				int temp = 0;
				for (int k = 0; k < 100; k++) {
					if (track_not_optimal[0][i][k] != 0 && track_not_optimal[0][i][k] != 2) {
						temp++;
					}
				}
				res << "#not optimal:" << temp << endl;
				res << "---------" << i + 4 << " countries" << "---------" << endl;
				int track_temp = 0;
				for (int l : track_not_optimal[0][i]) {
					res << "inst: " << track_temp << ", " << l << endl;
					track_temp++;
				}

				res << "------------reach time limit------------------" << endl;
				int temp_0 = 0;
				for (int k = 0; k < 100; k++) {
					if (track_time_limit[0][i][k] != 0 && track_time_limit[0][i][k] != 2) {
						temp_0++;
					}
				}
				res << "#time limit:" << temp_0 << endl;
				res << "relative optimal ratio: " << (double)relative_optimal[0][i] / (100 - temp_0) << endl;
				res << "---------" << i + 4 << " countries" << "---------" << endl;
				int track_temp_0 = 0;
				for (int l : track_time_limit[0][i]) {
					res << "inst: " << track_temp_0 << ", " << l << endl;
					track_temp_0++;
				}
				res << "--------------cycle distribution---------------" << endl;
				for (const auto& pair : cycle_dis_for_all[i]) {
					res << pair.first << " : " << pair.second << endl;
				}
			}
			if (d_c) {
				res << "minimizing d_1_c: " << relative_d1_N_c[i] << endl;
				res << "minimizing d_1_c_initial_allocation: " << relative_d1_N_initial_allocation[i] << endl;
				res << "minimizing max_d_1_c: " << max_d1_N_c[i] << endl;
				res << "average number of transplants_c: " << M_N_d_c[i] << endl;
				res << "total time: " << total_time_d1_c_N[i] << endl;
				res << "scenario time: " << time_d1_c_N[i] << endl;
				res << "game generation: " << game_generation_d1_c_N[i] << endl;
				res << "solution concept: " << solution_concept_time_d1_c_N[i] << endl;
				res << "----------accumulated deviations-------------" << endl;
				for (int j = 0; j < 24; j++) {
					res << "round j:" << (double)average_d_period[2][i][j] / 100 << endl;
				}

				res << "------------not optimal------------------" << endl;
				int temp = 0;
				for (int k = 0; k < 100; k++) {
					if (track_not_optimal[1][i][k] != 0 && track_not_optimal[1][i][k] != 2) {
						temp++;
					}
				}
				res << "#not optimal:" << temp << endl;
				res << "---------" << i + 4 << " countries" << "---------" << endl;
				int track_temp = 0;
				for (int l : track_not_optimal[1][i]) {
					res << "inst: " << track_temp << ", " << l << endl;
					track_temp++;
				}

				res << "------------reach time limit------------------" << endl;
				int temp_0 = 0;
				for (int k = 0; k < 100; k++) {
					if (track_time_limit[1][i][k] != 0 && track_time_limit[1][i][k] != 2) {
						temp_0++;
					}
				}
				res << "#time limit:" << temp_0 << endl;
				res << "relative optimal ratio: " << (double)relative_optimal[1][i] / (100 - temp_0) << endl;
				res << "---------" << i + 4 << " countries" << "---------" << endl;
				int track_temp_0 = 0;
				for (int l : track_time_limit[1][i]) {
					res << "inst: " << track_temp_0 << ", " << l << endl;
					track_temp_0++;
				}
				res << "--------------cycle distribution---------------" << endl;
				for (const auto& pair : cycle_dis_for_all[i]) {
					res << pair.first << " : " << pair.second << endl;
				}
			}
			if (lexmin_call) {
				res << "lex min " << relative_lexmin[i] << endl;
				res << "lex min max d " << max_lexmin[i] << endl;
				res << "average number of transplants: " << M_N_lex_min[i] << endl;
				res << "total time: " << total_time_lex_min_N[i] << endl;
				res << "scenario time: " << time_lex_min_N[i] << endl;
				res << "game generation: " << game_generation_lexmin_N[i] << endl;
				res << "solution concept: " << solution_concept_time_lexmin_N[i] << endl;
				res << "----------accumulated deviations-------------" << endl;
				for (int j = 0; j < 24; j++) {
					res << "round j:" << (double)average_d_period[3][i][j] / 100 << endl;
				}

				res << "------------not optimal------------------" << endl;
				int temp = 0;
				for (int k = 0; k < 100; k++) {
					if (track_not_optimal[2][i][k] != 0 && track_not_optimal[2][i][k] != 2) {
						temp++;
					}
				}
				res << "#not optimal:" << temp << endl;
				res << "---------" << i + 4 << " countries" << "---------" << endl;
				int track_temp = 0;
				for (int l : track_not_optimal[2][i]) {
					res << "inst: " << track_temp << ", " << l << endl;
					track_temp++;
				}

				res << "------------reach time limit------------------" << endl;
				int temp_0 = 0;
				for (int k = 0; k < 100; k++) {
					if (track_time_limit[2][i][k] != 0 && track_time_limit[2][i][k] != 2) {
						temp_0++;
					}
				}
				res << "#time limit:" << temp_0 << endl;
				res << "relative optimal ratio: " << (double)relative_optimal[2][i] / (100 - temp_0) << endl;
				res << "---------" << i + 4 << " countries" << "---------" << endl;
				int track_temp_0 = 0;
				for (int l : track_time_limit[2][i]) {
					res << "inst: " << track_temp_0 << ", " << l << endl;
					track_temp_0++;
				}
				res << "--------------cycle distribution---------------" << endl;
				for (const auto& pair : cycle_dis_for_all[i]) {
					res << pair.first << " : " << pair.second << endl;
				}
			}
			if (arbitrary) {
				res << "minimizing d_1_arbitrary: " << relative_arbitrary_N[i] << endl;
				res << "minimizing max_d_1_arbitrary: " << max_arbitrary_N[i] << endl;
				res << "average number of transplants_arbitrary: " << M_N_d_arbitrary[i] << endl;
				res << "total time: " << total_time_arbitrary_N[i] << endl;
				res << "scenario time: " << time_arbitrary_N[i] << endl;
				res << "game generation: " << game_generation_arbitrary_N[i] << endl;
				res << "solution concept: " << solution_concept_time_arbitrary_N[i] << endl;
				res << "----------accumulated deviations-------------" << endl;
				for (int j = 0; j < 24; j++) {
					res << "round j:" << (double)average_d_period[0][i][j] / 100 << endl;
				}
				res << "--------------cycle distribution---------------" << endl;
				for (const auto& pair : cycle_dis_for_all[i]) {
					res << pair.first << " : " << pair.second << endl;
				}

			}
			if (lexmin_c_call) {
				res << "lex min+c " << relative_lexmin_c[i] << endl;
				res << "lex min+c max " << max_lexmin_c[i] << endl;
				res << "average number of transplants: " << M_N_lex_min_c[i] << endl;
				res << "total time: " << total_time_lex_min_c_N[i] << endl;
				res << "scenario time: " << time_lex_min_c_N[i] << endl;
				res << "game generation: " << game_generation_lexmin_c_N[i] << endl;
				res << "solution concept: " << solution_concept_time_lexmin_c_N[i] << endl;
				res << "----------accumulated deviations-------------" << endl;
				for (int j = 0; j < 24; j++) {
					res << "round j:" << (double)average_d_period[4][i][j] / 100 << endl;
				}

				res << "------------not optimal------------------" << endl;
				int temp = 0;
				for (int k = 0; k < 100; k++) {
					if (track_not_optimal[3][i][k] != 0 && track_not_optimal[3][i][k] != 2) {
						temp++;
					}
				}
				res << "#not optimal:" << temp << endl;
				res << "---------" << i + 4 << " countries" << "---------" << endl;
				int track_temp = 0;
				for (int l : track_not_optimal[3][i]) {
					res << "inst: " << track_temp << ", " << l << endl;
					track_temp++;
				}

				res << "------------reach time limit------------------" << endl;
				int temp_0 = 0;
				for (int k = 0; k < 100; k++) {
					if (track_time_limit[3][i][k] != 0 && track_time_limit[3][i][k] != 2) {
						temp_0++;
					}
				}
				res << "#time limit:" << temp_0 << endl;
				res << "relative optimal ratio: " << (double)relative_optimal[3][i] / (100 - temp_0) << endl;
				res << "---------" << i + 4 << " countries" << "---------" << endl;
				int track_temp_0 = 0;
				for (int l : track_time_limit[3][i]) {
					res << "inst: " << track_temp_0 << ", " << l << endl;
					track_temp_0++;
				}
				res << "--------------cycle distribution---------------" << endl;
				for (const auto& pair : cycle_dis_for_all[i]) {
					res << pair.first << " : " << pair.second << endl;
				}
				res << endl;
			}

		}

		res.close();

		// time breakdown per instance
		ofstream res_time;
		res_time.open(version + "/" + cycle_length + "/" + country_size + "/" + "steady_time_breakdown_" + to_string(N) + ".txt", ofstream::out | ofstream::trunc);
		for (unsigned short int i = 0; i < N - 3; i++) {
			res_time << "number of countries: " << i + 4 << endl;
			if (d1) {
				for (int j = 0; j < 100; j++) {
					res_time << "---inst " << j << "---" << endl;
					res_time << "total time: " << time_breakdown_per_inst[1][i][4 * j] << endl;
					res_time << "data preparation: " << time_prep[i][j] << endl;
					res_time << "graph building: " << time_graph[i][j] << endl;
					res_time << "solution concept: " << time_breakdown_per_inst[1][i][4 * j + 1] << endl;
					res_time << "game generation: " << time_breakdown_per_inst[1][i][4 * j + 2] << endl;
					res_time << "scenario: " << time_breakdown_per_inst[1][i][4 * j + 3] << endl;
				}
			}
			if (d_c) {
				for (int j = 0; j < 100; j++) {
					res_time << "---inst " << j << "---" << endl;
					res_time << "total time: " << time_breakdown_per_inst[2][i][4 * j] << endl;
					res_time << "data preparation: " << time_prep[i][j] << endl;
					res_time << "graph building: " << time_graph[i][j] << endl;
					res_time << "solution concept: " << time_breakdown_per_inst[2][i][4 * j + 1] << endl;
					res_time << "game generation: " << time_breakdown_per_inst[2][i][4 * j + 2] << endl;
					res_time << "scenario: " << time_breakdown_per_inst[2][i][4 * j + 3] << endl;
				}
			}
			if (lexmin_call) {
				for (int j = 0; j < 100; j++) {
					res_time << "---inst " << j << "---" << endl;
					res_time << "total time: " << time_breakdown_per_inst[3][i][4 * j] << endl;
					res_time << "data preparation: " << time_prep[i][j] << endl;
					res_time << "graph building: " << time_graph[i][j] << endl;
					res_time << "solution concept: " << time_breakdown_per_inst[3][i][4 * j + 1] << endl;
					res_time << "game generation: " << time_breakdown_per_inst[3][i][4 * j + 2] << endl;
					res_time << "scenario: " << time_breakdown_per_inst[3][i][4 * j + 3] << endl;
				}
			}
			if (lexmin_c_call) {
				for (int j = 0; j < 100; j++) {
					res_time << "---inst " << j << "---" << endl;
					res_time << "total time: " << time_breakdown_per_inst[4][i][4 * j] << endl;
					res_time << "data preparation: " << time_prep[i][j] << endl;
					res_time << "graph building: " << time_graph[i][j] << endl;
					res_time << "solution concept: " << time_breakdown_per_inst[4][i][4 * j + 1] << endl;
					res_time << "game generation: " << time_breakdown_per_inst[4][i][4 * j + 2] << endl;
					res_time << "scenario: " << time_breakdown_per_inst[4][i][4 * j + 3] << endl;
				}
			}
			if (arbitrary) {
				for (int j = 0; j < 100; j++) {
					res_time << "---inst " << j << "---" << endl;
					res_time << "total time: " << time_breakdown_per_inst[0][i][4 * j] << endl;
					res_time << "data preparation: " << time_prep[i][j] << endl;
					res_time << "graph building: " << time_graph[i][j] << endl;
					res_time << "solution concept: " << time_breakdown_per_inst[0][i][4 * j + 1] << endl;
					res_time << "game generation: " << time_breakdown_per_inst[0][i][4 * j + 2] << endl;
					res_time << "scenario: " << time_breakdown_per_inst[0][i][4 * j + 3] << endl;
				}
			}

		}
		res_time.close();

	}
	cout << "Mischief managed!" << endl;
	return 0;
}



void coop_game(vector<double>& v, unsigned int& S, vector<unsigned short int>& s, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, bool& dispy, unsigned short int& Vp, unsigned short int& N, ListGraph::NodeMap<bool>& active_nodes, vector<bool>& leaving, unsigned short int& Q, bool& arbitray_maximum, double& game_generation, vector<vector<double>>& time_breakdown, unsigned short int inst, Allocation& allo, set<int>& active_source, vector<int>& source_set, vector<int>& node_set, vector<unsigned short int>& label_positions, vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, map<int, int>& cycle_dis) {
	vector<bool> a(N, false);
	double t0 = cpuTime();
	bool is_cycle_dis = false;
	if (arbitray_maximum) {
		is_cycle_dis = true;
	}
	v[S] = solve_obj(allo, active_source, node_set, label_positions, cycle_dis, is_cycle_dis);
	is_cycle_dis = false;

	if (arbitray_maximum) {
		for (int i : node_set) {
			for (int j = 0; j < N; j++) {
				if (j * Vp <= label_positions[i] && label_positions[i] < (j + 1) * Vp) {
					//cout << "label_positions[i]: " << label_positions[i] << ";" << "between " << j * Vp << " and " << (j + 1) * Vp << endl;
					s[j]++;
					leaving[label_positions[i]] = true;
				}
			}
		}
	}



	cout << "v[N]: " << v[S] << endl;
	vector<int> node_set_temp_2;
	vector<int> source_set_temp_2;
	Allocation allo_temp_2;
	allo_temp_2.load(arc_in, arc_out, source_set_temp_2);

	set<int> active_source_temp_2;
	vector<int> temp_1(N, 0), temp_2(N, 0);


	for (unsigned int i = 0; i < S; i++) {
		de2bi(i, a, N);
		active_source_temp_2.clear();
		for (unsigned short int j = 0; j < N; j++) {
			if (a[j]) {
				for (unsigned short int k = j * Vp; k < (j + 1) * Vp; ++k) {
					if (active_nodes[c[k]]) {
						active_source_temp_2.insert(source_set[k]);
					}
				}
			}

		}
		v[i] = solve_obj(allo, active_source_temp_2, node_set_temp_2, label_positions, cycle_dis, is_cycle_dis);
	}


	cout << "finish generating the copy" << endl;

	double t1 = cpuTime();
	game_generation += t1 - t0;
	time_breakdown[N - 4][inst * 4 + 2] += t1 - t0;




	if (dispy)
		cout << "grand coal: " << v[S] << endl;

	if (dispy) {
		cout << "s: ";
		for (unsigned short int i = 0; i < N; i++) {
			cout << s[i] << " ";
		}
		cout << endl;
	}
	return;
}



void changing_nodes(ListGraph::NodeMap<bool>& active_nodes, ListDigraph::NodeMap<bool>& active_nodes_original, vector<bool>& leaving, vector<unsigned short int>& no_of_active_nodes, unsigned short int& N, unsigned short int& Vp, vector<unsigned short int>& node_arrives, unsigned short int& Q, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, vector<unsigned short int>& s, vector<double>& d, set<int>& active_source, vector<int>& source_set) {
	for (unsigned short int i = 0; i < N; i++) {
		s[i] = 0;
		for (unsigned short int j = 0; j < Vp; j++) {
			if (leaving[i * Vp + j]) {
				active_nodes[c[i * Vp + j]] = false;
				active_nodes[c_b[i * Vp + j]] = false;
				active_nodes_original[c_original[i * Vp + j]] = false;
				if (active_source.find(source_set[i * Vp + j]) == active_source.end()) {
					throw std::invalid_argument("node does not exist!!");
				}
				active_source.erase(source_set[i * Vp + j]);
				no_of_active_nodes[i]--;
				leaving[i * Vp + j] = false;
			}
			else {
				if (active_nodes[c[i * Vp + j]] && node_arrives[i * Vp + j] == Q - 4) {
					active_nodes[c[i * Vp + j]] = false;
					active_nodes[c_b[i * Vp + j]] = false;
					active_nodes_original[c_original[i * Vp + j]] = false;
					if (active_source.find(source_set[i * Vp + j]) == active_source.end()) {
						throw std::invalid_argument("node does not exist!!");
					}
					active_source.erase(source_set[i * Vp + j]);
					no_of_active_nodes[i]--;
				}
			}
			if (node_arrives[i * Vp + j] == Q) {
				active_nodes[c[i * Vp + j]] = true;
				active_nodes[c_b[i * Vp + j]] = true;
				active_nodes_original[c_original[i * Vp + j]] = true;
				if (active_source.find(source_set[i * Vp + j]) != active_source.end()) {
					throw std::invalid_argument("node already exists!!");
				}
				active_source.insert(source_set[i * Vp + j]);
				no_of_active_nodes[i]++;
			}
		}
	}
	return;
}

void initial_pairs(unsigned short int& Vp, unsigned short int& N, ListGraph::NodeMap<bool>& active_nodes, ListDigraph::NodeMap<bool>& active_nodes_original, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, unsigned short int& initialSize, set<int>& active_source, vector<int>& source_set) {
	unsigned short int coal = rand() % Vp;
	unsigned short int count = 0;
	active_source.clear();
	for (unsigned short int i = 0; i < N; i++) {
		while (count < Vp / 4) {
			if (active_nodes[c[i * Vp + coal]]) {
				coal = rand() % Vp;
			}
			else {
				active_nodes[c[i * Vp + coal]] = true;
				active_nodes[c_b[i * Vp + coal]] = true;
				active_nodes_original[c_original[i * Vp + coal]] = true;
				active_source.insert(source_set[i * Vp + coal]);
				count++;
				coal = rand() % Vp;
			}
		}
		count = 0;
	}
	return;
}

void arrival_times(vector<unsigned short int>& node_arrives, unsigned short int& Vp, unsigned short int& N, ListGraph::NodeMap<bool>& active_nodes, vector<ListGraph::Node>& c, unsigned short int& periods, bool& disp) {
	for (unsigned short int i = 0; i < N; i++) {
		if (disp)
			cout << "Country " << i << " arrivals: ";
		for (unsigned short int j = 0; j < Vp; j++) {
			if (!(active_nodes[c[i * Vp + j]])) {
				node_arrives[i * Vp + j] = rand() % (periods - 1) + 1;
			}
			if (disp)
				cout << node_arrives[i * Vp + j] << " ";
		}
		if (disp)
			cout << endl;
	}
	return;
}

void insertion_sort(vector<unsigned short int>& w, vector<double>& deviation, unsigned short int& N) {
	w[0] = 0;
	for (unsigned short int i = 1; i < N; i++) {
		if (deviation[i] <= deviation[w[i - 1]]) {
			w[i] = i;
		}
		else {
			w[i] = w[i - 1];
			if (i == 1) {
				w[0] = i;
			}
			else {
				for (unsigned short int j = i - 2; j >= 0; j--) {
					if (deviation[i] <= deviation[w[j]]) {
						w[j + 1] = i;
						break;
					}
					else {
						w[j + 1] = w[j];
						if (j == 0) {
							w[0] = i;
							break;
						}
					}
				}
			}
		}
	}
	return;
}

void undi_lemon(unsigned int& m, vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, vector<unsigned short int>& label_positions, ListGraph& g, ListDigraph& g_original, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, ListGraph::EdgeMap<double>& edge_card_weight, ListDigraph::ArcMap<unsigned short int>& arc_card_weight, unsigned short int& no_of_nodes) {
	bool halt = false;
	for (int i = 0; i < no_of_nodes; i++) {
		ListGraph::Edge e = g.addEdge(c[i], c_b[i]);
		edge_card_weight[e] = 0;
	}
	for (unsigned int i = 0; i < m; i++) {
		if (label_positions[arc_in[i]] < no_of_nodes) { //XY: filter 65535 positions
			ListGraph::Edge e = g.addEdge(c[label_positions[arc_out[i]]], c_b[label_positions[arc_in[i]]]);
			edge_card_weight[e] = 1;
			ListDigraph::Arc a_original = g_original.addArc(c_original[label_positions[arc_out[i]]], c_original[label_positions[arc_in[i]]]);
			arc_card_weight[a_original] = 1;
		}
	}
	return;
}
void de2bi(unsigned int& k, vector<bool>& a, unsigned short int& n) {
	vector<bool> zero(n, false);
	a = zero;
	unsigned int i = 2;
	for (unsigned short int c = 0; c < n - 2; c++)
		i += i;
	unsigned int j = k + 1;
	unsigned short int l = n - 1;
	while (j > 0) {
		if (j >= i) {
			a[l] = true;
			j -= i;
		}
		i /= 2;
		l--;
	}
	return;
}

void shapley(vector<double>& shapl, vector<double>& v, unsigned short int& n, unsigned int& S) {
	vector<double> w(n, 0);
	w[0] = 1 / (double)n;
	vector<double> expo(n, 1);
	for (unsigned short int j = 1; j < n; j++) {
		w[j] = w[j - 1] * j / (n - j);
		expo[j] = pow(2, j);
	}
	vector<bool> a(n, false);
	unsigned short int k = 0;
	for (unsigned short int i = 0; i < n - 1; i++)
		shapl[i] = (double)(v[expo[i] - 1]) / n;
	for (unsigned int i = 0; i < S; i++) {
		de2bi_card(i, a, n, k);
		for (unsigned short int j = 0; j < n - 1; j++) {
			if (!a[j])
				shapl[j] += w[k] * (v[i + expo[j]] - v[i]);
		}
	}
	shapl[n - 1] = v[S];
	for (unsigned short int j = 0; j < n - 1; j++)
		shapl[n - 1] -= shapl[j];
	return;
}

void xml_parser(string& line, vector<unsigned short int>& node_labels, vector<unsigned short int>& label_positions, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, unsigned short int& k, ListGraph& g, ListDigraph& g_original, vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, unsigned int& m, unsigned short int& no_of_nodes) {
	unsigned int l = 6;
	unsigned short int n = 0; //XY: track the number of nodes
	while (l < line.size() - 7) {
		if (line[l] == '<' && line[l + 1] == 'e') {
			l = l + 17;
			n++;
			if (!is_next_char_digit(line, l)) {
				node_labels[n - 1] = char2uint(line[l]); //XY: donor id
			}
			else {
				if (!is_next_char_digit(line, l + 1)) {
					node_labels[n - 1] = 10 * char2uint(line[l]) + char2uint(line[l + 1]);
					l++;
				}
				else {
					if (!is_next_char_digit(line, l + 2)) {
						node_labels[n - 1] = 100 * char2uint(line[l]) + 10 * char2uint(line[l + 1]) + char2uint(line[l + 2]);
						l = l + 2;
					}
					else {
						node_labels[n - 1] = 1000 * char2uint(line[l]) + 100 * char2uint(line[l + 1]) + 10 * char2uint(line[l + 2]) + char2uint(line[l + 3]);
						l = l + 3;
					}
				}
			}
			if (n + k - 1 == node_labels[n - 1]) {
				label_positions[n + k - 1] = n - 1;
			}
			else {
				while (n + k - 1 < node_labels[n - 1]) {
					label_positions[n + k - 1] = 65535;
					label_positions.push_back(0);
					k++;
				}
				label_positions[n + k - 1] = n - 1;
			}

			c[n - 1] = g.addNode();//XY: add donor ids
			c_b[n - 1] = g.addNode();//changed by XY, add patient ids
			c_original[n - 1] = g_original.addNode();//changed by XY, add patient-donor pairs to the original graph
			l = l + 9;
			if (!is_next_char_digit(line, l)) {
				////donor_ages.push_back(char2uint(line[l]));
				//donor_ages[n - 1] = char2uint(line[l]);
			}
			else {
				if (!is_next_char_digit(line, l + 1)) {
					////donor_ages.push_back(10*char2uint(line[l])+char2uint(line[l+1]));
					//donor_ages[n - 1] = 10*char2uint(line[l])+char2uint(line[l+1]);
					l++;
				}
				else {
					if (!is_next_char_digit(line, l + 2)) {
						////donor_ages.push_back(100*char2uint(line[l])+10*char2uint(line[l+1])+char2uint(line[l+2]));
						//donor_ages[n - 1] = 100*char2uint(line[l])+10*char2uint(line[l+1])+char2uint(line[l+2]);
						l = l + 2;
					}
					else {
						////if (!is_next_char_digit(line, l + 3)){
						////donor_ages.push_back(1000*char2uint(line[l])+100*char2uint(line[l+1])+10*char2uint(line[l+2])+char2uint(line[l+3]));
						//donor_ages[n - 1] = 1000*char2uint(line[l])+100*char2uint(line[l+1])+10*char2uint(line[l+2])+char2uint(line[l+3]);
						l = l + 3;
						////}
					}
				}
			}
			l = l + 25;
			if (!is_next_char_digit(line, l)) {
				if (node_labels[n - 1] != char2uint(line[l]))
					cout << "ID ERROR!" << endl;
			}
			else {
				if (!is_next_char_digit(line, l + 1)) {
					if (node_labels[n - 1] != 10 * char2uint(line[l]) + char2uint(line[l + 1]))
						cout << "ID ERROR!" << endl;
					l++;
				}
				else {
					if (!is_next_char_digit(line, l + 2)) {
						if (node_labels[n - 1] != 100 * char2uint(line[l]) + 10 * char2uint(line[l + 1]) + char2uint(line[l + 2]))
							cout << "ID ERROR!" << endl;
						l = l + 2;
					}
					else {
						//if (!is_next_char_digit(line, l + 3)){
						if (node_labels[n - 1] != 1000 * char2uint(line[l]) + 100 * char2uint(line[l + 1]) + 10 * char2uint(line[l + 2]) + char2uint(line[l + 3]))
							cout << "ID ERROR!" << endl;
						l = l + 3;
						//}
					}
				}
			}
			if (line[l + 21] == 'm')
				l = l + 29;
			else
				l = l + 28;
		}
		// XY: recipients
		while (line[l] == '<' && line[l + 1] == 'm' && line[l + 6] == '>') {
			m++;//number of compatibilities
			l = l + 18;
			arc_out.push_back(node_labels[n - 1]);
			if (!is_next_char_digit(line, l)) {
				arc_in.push_back(char2uint(line[l]));
			}
			else {
				if (!is_next_char_digit(line, l + 1)) {
					arc_in.push_back(10 * char2uint(line[l]) + char2uint(line[l + 1]));
					l++;
				}
				else {
					if (!is_next_char_digit(line, l + 2)) {
						arc_in.push_back(100 * char2uint(line[l]) + 10 * char2uint(line[l + 1]) + char2uint(line[l + 2]));
						l = l + 2;
					}
					else {
						//if (!is_next_char_digit(line, l + 3)){
						arc_in.push_back(1000 * char2uint(line[l]) + 100 * char2uint(line[l + 1]) + 10 * char2uint(line[l + 2]) + char2uint(line[l + 3]));
						l = l + 3;
						//}
					}
				}
			}
			l = l + 20;
			if (!is_next_char_digit(line, l)) {
				//arc_weight.push_back(char2uint(line[l]));
			}
			else {
				if (!is_next_char_digit(line, l + 1)) {
					//arc_weight.push_back(10*char2uint(line[l])+char2uint(line[l+1]));
					l++;
				}
				else {
					if (!is_next_char_digit(line, l + 2)) {
						//arc_weight.push_back(100*char2uint(line[l])+10*char2uint(line[l+1])+char2uint(line[l+2]));
						l = l + 2;
					}
					else {
						////if (!is_next_char_digit(line, l + 3)){
						//arc_weight.push_back(1000*char2uint(line[l])+100*char2uint(line[l+1])+10*char2uint(line[l+2])+char2uint(line[l+3]));
						l = l + 3;
						////}
					}
				}
			}
			l = l + 17;
		}
		if (!(line[l] == '<' && line[l + 1] == 'e')) {
			l = l + 18;
		}
		if (n == no_of_nodes)
			break;
	}
	cout << "the number of nodes" << n;
	cout << "m: " << m << "\n";
	cout << "arc_in.size(): " << arc_in.size() << "\n" << " arc_out.size(): " << arc_out.size() << endl;
	return;
}

bool is_next_char_digit(string& line, unsigned int l) {
	if (line[l + 1] == '0' || line[l + 1] == '1' || line[l + 1] == '2' || line[l + 1] == '3' || line[l + 1] == '4' || line[l + 1] == '5' || line[l + 1] == '6' || line[l + 1] == '7' || line[l + 1] == '8' || line[l + 1] == '9')
		return true;
	return false;
}

//unsigned int char2uint(char &p){
//	return (int)p-48;
//}

unsigned int char2uint(char& p) {
	if (p == '1')
		return 1;
	else
		if (p == '2')
			return 2;
		else
			if (p == '3')
				return 3;
			else
				if (p == '4')
					return 4;
				else
					if (p == '5')
						return 5;
					else
						if (p == '6')
							return 6;
						else
							if (p == '7')
								return 7;
							else
								if (p == '8')
									return 8;
								else
									if (p == '9')
										return 9;
									else
										return 0;
}

void de2bi_card(unsigned int& k, vector<bool>& a, unsigned short int& n, unsigned short int& card) {
	vector<bool> zero(n, false);
	card = 0;
	a = zero;
	unsigned int i = 2;
	for (unsigned short int c = 0; c < n - 2; c++)
		i += i;
	unsigned int j = k + 1;
	unsigned short int l = n - 1;
	while (j > 0) {
		if (j >= i) {
			a[l] = true;
			card++;
			j -= i;
		}
		i /= 2;
		l--;
	}
	return;
}

double cpuTime() {
	return (double)clock() / CLOCKS_PER_SEC;
}

void nucl(bool& disp, unsigned short int& n, unsigned int& s, vector<double>& x, vector<double>& v, double& prec) {
	double min_satisfaction = 0;
	bool nlsu = false;
	vector<double> singleton_bounds(n, 0);
	double impu = 0;
	vector<double> excess(s, 0);
	vector<bool> unsettled(s + 1, true);
	unsettled[s] = false;
	vector<unsigned short int> zeros(s, 0);
	unsigned short int iter = 0;
	unsigned int piv = 0;
	unsigned int sr = 0;
	double t = 0;
	double t1 = cpuTime();
	for (unsigned short int i = 0; i < n; i++) {
		singleton_bounds[i] = v[pow(2, i) - 1];
		impu += singleton_bounds[i];
	}
	x = singleton_bounds;
	for (unsigned short int i = 0; i < n; i++)
		x[i] += (v[s] - impu) / n;
	vector<bool> a(n, false);
	zeros_mem(a, n, s, zeros);
	excess_init(excess, unsettled, x, v, s, n, zeros);
	nucl_comp(disp, n, s, excess, prec, unsettled, iter, piv, sr, t, x, a, t1, singleton_bounds, nlsu, min_satisfaction, zeros);
	return;
}

void nucl_comp(bool& disp, unsigned short int& n, unsigned int& s, vector<double>& excess, double& prec, vector<bool>& unsettled, unsigned short int& iter, unsigned int& piv, unsigned int& sr, double& t, vector<double>& x, vector<bool>& a, double& t1, vector<double>& singleton_bounds, bool& nlsu, double& min_satisfaction, vector<unsigned short int>& zeros) {
	vector<bool> unsettled_p(n, true);
	vector<vector<double>> Arref(n, vector<double>(n, 0));
	Arref[0] = vector<double>(n, 1);
	vector<bool>J(n, true);
	J[0] = false;
	unsigned short int rank = 1;
	vector<vector<bool>> Asettled(n, vector<bool>(n, 0));
	Asettled[0] = vector<bool>(n, true);
	if (disp) {
		cout << "Starting point:" << endl;
		for (unsigned short int i = 0; i < n; i++)
			cout << x[i] << endl;
	}
	vector<double> d(n, 0);
	double epsi = 0;
	double epsi_old = -DBL_MAX;
	vec_min_uns(epsi, excess, unsettled, s);
	vector<bool> T(s, false);
	vector<unsigned int> T_coord(0, 0);
	vector<bool> T2(n, false);
	vector<unsigned int> T2_coord(0, 0);
	unsigned int t_size = 0;
	tight_coal(T, excess, epsi, prec, s, T_coord, unsettled, t_size);
	unsigned short int t2_size = 0;
	tight_coal2(T2, x, singleton_bounds, prec, n, T2_coord, unsettled_p, t2_size);
	vector<vector<bool>> Atight(t_size, vector<bool>(n, false));
	for (unsigned int i = 0; i < t_size; i++)
		de2bi(T_coord[i], Atight[i], n);
	vector<vector<bool>> Atight2(t2_size, vector<bool>(n, false));
	for (unsigned int i = 0; i < t2_size; i++)
		de2bi(T2_coord[i], Atight2[i], n);
	vector<bool> U(t_size, true);
	vector<bool> U2(t2_size, true);
	while (rank < n)
		pivot(epsi, s, excess, prec, n, a, Arref, J, unsettled, rank, d, x, disp, Asettled, piv, sr, iter, unsettled_p, singleton_bounds, epsi_old, nlsu, zeros, T, T_coord, T2, T2_coord, t_size, t2_size, Atight, Atight2, U, U2, min_satisfaction);
	//cout << "BNF finished!" << endl;
	if (disp) {
		cout << "The nucleolus solution:" << endl;
		for (unsigned short int i = 0; i < n; i++)
			cout << x[i] << endl;
		//cout << "Time needed: " << t << " seconds" << endl;
		cout << "Iterations needed: " << iter << endl;
		cout << "Pivots needed: " << piv << endl;
		cout << "Subroutine solves needed: " << sr << endl;
	}
	return;
}

void zeros_mem(vector<bool>& a, unsigned short int& n, unsigned int& s, vector<unsigned short int>& zeros) {
	a[0] = true;
	zeros[0] = 1;
	for (unsigned int j = 1; j != s + 1; j++) {
		for (unsigned short int i = 0; i < n; i++) {
			if (!a[i]) {
				zeros[j] = i;
				break;
			}
		}
		a[zeros[j]] = 1;
		for (unsigned short int i = 0; i < zeros[j]; i++)
			a[i] = 0;
	}
	return;
}

void excess_init(vector<double>& exc, vector<bool>& unsettled, vector<double>& x, vector<double>& v, unsigned int& S, unsigned short int& N, vector<unsigned short int>& zeros) {
	double ax = x[0];
	vector<double> Ux(N, 0);
	for (unsigned short int i = 0; i < N; i++) {
		Ux[i] = x[i];
		for (unsigned short int j = 0; j < i; j++)
			Ux[i] -= x[j];
	}
	exc[0] = ax - v[0];
	for (unsigned int i = 1; i < S; i++) {
		ax += Ux[zeros[i]];
		if (unsettled[i])
			exc[i] = ax - v[i];
		else
			exc[i] = DBL_MAX;
	}
	return;
}

void vec_min_uns(double& m, vector<double>& x, vector<bool>& unsettled, unsigned int& s) {
	m = DBL_MAX;
	for (unsigned int i = 0; i < s; i++) {
		if (unsettled[i] && x[i] < m)
			m = x[i];
	}
	return;
}

void tight_coal(vector<bool>& T, vector<double>& excess, double& epsi, double& prec, unsigned int& s, vector<unsigned int>& T_coord, vector<bool>& unsettled, unsigned int& t_size) {
	for (unsigned int i = 0; i < s; i++) {
		if (unsettled[i]) {
			if (abs(excess[i] - epsi) < prec) {
				t_size++;
				T[i] = true;
				T_coord.push_back(i);
			}
		}
	}
	return;
}

void tight_coal2(vector<bool>& T2, vector<double>& x, vector<double>& singleton_bounds, double& prec, unsigned short int& n, vector<unsigned int>& T2_coord, vector<bool>& unsettled_p, unsigned short int& t2_size) {
	for (unsigned int i = 0; i < n; i++) {
		if (unsettled_p[i]) {
			if (abs(x[i] - singleton_bounds[i]) < prec) {
				t2_size++;
				T2[i] = true;
				T2_coord.push_back(pow(2, i) - 1);
			}
		}
	}
	return;
}

void pivot(double& epsi, unsigned int& s, vector<double>& excess, double& prec, unsigned short int& n, vector<bool>& a, vector<vector<double>>& Arref, vector<bool>& J, vector<bool>& unsettled, unsigned short int& rank, vector<double>& d, vector<double>& x, bool& disp, vector<vector<bool>>& Asettled, unsigned int& piv, unsigned int& sr_count, unsigned short int& iter, vector<bool>& unsettled_p, vector<double>& singleton_bounds, double& epsi_old, bool& nlsu, vector<unsigned short int>& zeros, vector<bool>& T, vector<unsigned int>& T_coord, vector<bool>& T2, vector<unsigned int>& T2_coord, unsigned int& t_size, unsigned short int& t2_size, vector<vector<bool>>& Atight, vector<vector<bool>>& Atight2, vector<bool>& U, vector<bool>& U2, double& min_satisfaction) {
	if (disp)
		cout << "Epsilon: " << epsi << endl;
	bool u = true;
	bool settled = false;
	subroutine(U, U2, Atight, Atight2, Arref, J, prec, n, t_size, t2_size, rank, disp, Asettled, sr_count, u, s, T_coord, T2_coord, unsettled, epsi_old, epsi, unsettled_p, settled, nlsu);
	if (disp)
		cout << endl << "   ---===   SUBROUTINE FINISHED   ===---   " << endl << endl;
	if (settled) {
		iter++;
		if (iter == 1)
			min_satisfaction = epsi;
	}
	if (disp) {
		cout << "T:" << endl;
		for (unsigned int i = 0; i < t_size; i++) {
			if (!U[i])
				cout << T_coord[i] + 1 << endl;
		}
		cout << "U:" << endl;
		for (unsigned int i = 0; i < t_size; i++) {
			if (U[i])
				cout << T_coord[i] + 1 << endl;
		}
		cout << "T0:" << endl;
		for (unsigned int i = 0; i < t2_size; i++) {
			if (!U2[i])
				cout << T2_coord[i] + 1 << endl;
		}
		cout << "U0:" << endl;
		for (unsigned int i = 0; i < t2_size; i++) {
			if (U2[i])
				cout << T2_coord[i] + 1 << endl;
		}
	}
	if (u) {
		piv++;
		if (disp)
			cout << endl << "   ---===   SOLVING IMPROVING DIRECTION LP   ===---   " << endl << endl;
		imprdir(d, n, t_size, t2_size, Atight, Atight2, U, U2, rank, Asettled, disp);
		if (disp)
			cout << endl << "   ---===   IMPROVING DIRECTION OBTAINED   ===---   " << endl << endl;
		if (disp) {
			cout << "Improving direction:" << endl;
			for (unsigned short int i = 0; i < n; i++) {
				cout << d[i] << "    ";
			}
			cout << endl;
		}
		if (disp)
			cout << endl << "   ---===   COMPUTING STEP SIZE   ===---   " << endl << endl;
		step(T, T2, unsettled, unsettled_p, s, epsi, excess, d, n, x, singleton_bounds, disp, prec, zeros, T_coord, t_size, T2_coord, t2_size, Atight, Atight2, U, U2);
	}
	else {
		if (disp)
			cout << "Min tight set found! Rank increased to: " << rank << endl;
		if (rank == n)
			return;
		if (!nlsu) {
			a[0] = true;
			for (unsigned short int i = 1; i < n; i++)
				a[i] = false;
			for (unsigned int i = 0; i < s; i++) {
				if (unsettled[i]) {
					//de2bi(i, a, n);
					if (!(binrank(Arref, J, a, n, rank))) {
						unsettled[i] = false;
						unsettled[s - 1 - i] = false;
					}
				}
				a[zeros[i + 1]] = 1;
				for (unsigned short int j = 0; j < zeros[i + 1]; j++)
					a[j] = 0;
			}
		}
		for (unsigned short int i = 0; i < n; i++)
			if (unsettled_p[i] == true && unsettled[pow(2, i) - 1] == false)
				unsettled_p[i] = false;
		vec_min_uns(epsi, excess, unsettled, s);
		T = vector<bool>(s, false);
		T_coord.clear();
		T2 = vector<bool>(n, false);
		T2_coord.clear();
		t_size = 0;
		tight_coal(T, excess, epsi, prec, s, T_coord, unsettled, t_size);
		t2_size = 0;
		if (epsi > prec || epsi < -prec)
			tight_coal2(T2, x, singleton_bounds, prec, n, T2_coord, unsettled_p, t2_size);
		Atight = vector<vector<bool>>(t_size, vector<bool>(n, false));
		for (unsigned int i = 0; i < t_size; i++)
			de2bi(T_coord[i], Atight[i], n);
		Atight2 = vector<vector<bool>>(t2_size, vector<bool>(n, false));
		for (unsigned int i = 0; i < t2_size; i++)
			de2bi(T2_coord[i], Atight2[i], n);
		U = vector<bool>(t_size, true);
		U2 = vector<bool>(t2_size, true);
	}
	return;
}

void subroutine(vector<bool>& U, vector<bool>& U2, vector<vector<bool>>& Atight, vector<vector<bool>>& Atight2, vector<vector<double>>& Arref, vector<bool>& J, double& prec, unsigned short int& n, unsigned int& tight_size, unsigned short int& tight2_size, unsigned short int& rank, bool& disp, vector<vector<bool>>& Asettled, unsigned int& sr_count, bool& u, unsigned int& s, vector<unsigned int>& T_coord, vector<unsigned int>& T2_coord, vector<bool>& unsettled, double& epsi_old, double& epsi, vector<bool>& unsettled_p, bool& settled, bool& nlsu) {
	unsigned int sumt = 0;
	vector<bool> t(tight_size, false);
	unsigned int sumt2 = 0;
	vector<bool> t2(tight2_size, false);
	glp_prob* lp;
	lp = glp_create_prob();
	//glp_set_prob_name(lp, "sr");
	//glp_set_obj_name(lp, "obj");
	glp_set_obj_dir(lp, GLP_MAX);
	glp_add_rows(lp, n + 1);
	glp_add_cols(lp, tight_size + tight2_size + rank);
	for (unsigned short int i = 1; i < n + 1; i++)
		glp_set_row_bnds(lp, i, GLP_FX, 0, 0);
	glp_set_row_bnds(lp, n + 1, GLP_FX, 1, 1);
	for (unsigned int i = 1; i < tight_size + tight2_size + 1; i++) {
		glp_set_col_bnds(lp, i, GLP_LO, 0, DBL_MAX);
		glp_set_obj_coef(lp, i, 1);
	}
	for (unsigned int i = tight_size + tight2_size + 1; i < tight_size + tight2_size + rank + 1; i++) {
		glp_set_col_bnds(lp, i, GLP_FR, -DBL_MAX, DBL_MAX);
		glp_set_obj_coef(lp, i, 0);
	}
	vector<int> ia((n + 1) * (tight_size + tight2_size + rank) + 1, 0);
	vector<int> ja((n + 1) * (tight_size + tight2_size + rank) + 1, 0);
	vector<double> ar((n + 1) * (tight_size + tight2_size + rank) + 1, 0);
	vector<bool> ar0pos(tight_size, false);
	unsigned int count = 0;
	for (unsigned int j = 1; j < tight_size + 1; j++) {
		for (unsigned short int i = 1; i < n + 1; i++) {
			count++;
			ia[count] = i;
			ja[count] = j;
			if (Atight[j - 1][i - 1]) {
				ar[count] = 1;
			}
			else {
				ar[count] = 0;
			}
		}
	}
	for (unsigned short int j = 1; j < tight2_size + 1; j++) {
		for (unsigned short int i = 1; i < n + 1; i++) {
			count++;
			ia[count] = i;
			ja[count] = j + tight_size;
			if (Atight2[j - 1][i - 1]) {
				ar[count] = 1;
			}
			else {
				ar[count] = 0;
			}
		}
	}
	for (unsigned short int j = 1; j < rank + 1; j++) {
		for (unsigned short int i = 1; i < n + 1; i++) {
			count++;
			ia[count] = i;
			ja[count] = j + tight_size + tight2_size;
			if (Asettled[j - 1][i - 1]) {
				ar[count] = 1;
			}
			else {
				ar[count] = 0;
			}
		}
	}
	for (unsigned int j = 1; j < tight_size + 1; j++) {
		count++;
		ia[count] = n + 1;
		ja[count] = j;
		ar[count] = 1;
	}
	for (unsigned int j = tight_size + 1; j < tight_size + tight2_size + rank + 1; j++) {
		count++;
		ia[count] = n + 1;
		ja[count] = j;
		ar[count] = 0;
	}
	int* ia_arr = ia.data();
	int* ja_arr = ja.data();
	double* ar_arr = ar.data();
	glp_load_matrix(lp, count, ia_arr, ja_arr, ar_arr);
	if (disp)
		cout << endl << "  --==  solving subroutine LP  ==--  " << endl << endl;
	glp_smcp parm;
	glp_init_smcp(&parm);
	if (!disp)
		parm.msg_lev = GLP_MSG_OFF;
	parm.presolve = GLP_ON;
	glp_simplex(lp, &parm);
	bool feas = false;
	if (glp_get_prim_stat(lp) == 2)
		feas = true;
	if (disp)
		cout << "subroutine feasibility: " << feas << endl;
	if (feas && nlsu)
		settled = true;
	sr_count++;
	unsigned int i;
	unsigned short int rank_old = rank;
	while (feas) {
		subr_upd(Arref, J, i, n, prec, U, U2, sumt, sumt2, t, t2, Atight, Atight2, tight_size, tight2_size, rank, unsettled, Asettled, disp, s, T_coord, T2_coord, epsi_old, epsi, unsettled_p, settled, lp, ar0pos);
		if (rank == n) {
			u = false;
			glp_delete_prob(lp);
			glp_free_env();
			return;
		}
		for (unsigned int i = 0; i < tight_size; i++) {
			if (ar0pos[i]) {
				ar[count - tight_size - tight2_size - rank_old + i + 1] = 0;
				ar0pos[i] = false;
			}
		}
		if (sumt < tight_size) {
			i = 0;
			while (i < tight_size) {
				if (t[i] == false) {
					if (!(binrank(Arref, J, Atight[i], n, rank))) {
						U[i] = false;
						t[i] = true;
						ar[count - tight_size - tight2_size - rank_old + i + 1] = 0;
						glp_set_obj_coef(lp, i + 1, 0);
						sumt++;
						unsettled[T_coord[i]] = false;
						unsettled[s - 1 - T_coord[i]] = false;
						if (disp)
							cout << T_coord[i] + 1 << " and " << s - T_coord[i] << " got settled without rank increase." << endl;
						if (sumt == tight_size && sumt2 == tight2_size) {
							u = false;
							glp_delete_prob(lp);
							glp_free_env();
							return;
						}
					}
				}
				i++;
			}
			i = 0;
			while (i < tight2_size) {
				if (t2[i] == false) {
					if (!(binrank(Arref, J, Atight2[i], n, rank))) {
						U2[i] = false;
						t2[i] = true;
						glp_set_obj_coef(lp, tight_size + i + 1, 0);
						sumt2++;
						unsettled[T2_coord[i]] = false;
						unsettled[s - 1 - T2_coord[i]] = false;
						if (disp)
							cout << T2_coord[i] + 1 << " and " << s - T2_coord[i] << " got settled without rank increase." << endl;
						if (sumt == tight_size && sumt2 == tight2_size) {
							u = false;
							glp_delete_prob(lp);
							glp_free_env();
							return;
						}
					}
				}
				i++;
			}
			for (unsigned short int i = 0; i < n; i++)
				if (unsettled_p[i] == true && unsettled[pow(2, i) - 1] == false)
					unsettled_p[i] = false;
			glp_load_matrix(lp, count, ia_arr, ja_arr, ar_arr);
			if (disp)
				cout << endl << "  --==  solving subroutine LP again  ==--  " << endl << endl;
			glp_simplex(lp, &parm);
			feas = false;
			if (glp_get_prim_stat(lp) == 2)
				feas = true;
			if (disp)
				cout << "subroutine feasibility: " << feas << endl;
			sr_count++;
		}
		else {
			u = false;
			glp_delete_prob(lp);
			glp_free_env();
			return;
		}
	}
	glp_delete_prob(lp);
	glp_free_env();
	return;
}

void subr_upd(vector<vector<double>>& Arref, vector<bool>& J, unsigned int& i, unsigned short int& n, double& prec, vector<bool>& U, vector<bool>& U2, unsigned int& sumt, unsigned int& sumt2, vector<bool>& t, vector<bool>& t2, vector<vector<bool>>& Atight, vector<vector<bool>>& Atight2, unsigned int& tight_size, unsigned short int& tight2_size, unsigned short int& rank, vector<bool>& unsettled, vector<vector<bool>>& Asettled, bool& disp, unsigned int& s, vector<unsigned int>& T_coord, vector<unsigned int>& T2_coord, double& epsi_old, double& epsi, vector<bool>& unsettled_p, bool& settled, glp_prob*& lp, vector<bool>& ar0pos) {
	i = 0;
	vector<double> lambdi(tight_size + tight2_size, 0);
	for (unsigned int j = 0; j < tight_size; j++) {
		if (t[j] == false)
			lambdi[j] = glp_get_col_prim(lp, j + 1);
	}
	for (unsigned short int j = 0; j < tight2_size; j++) {
		if (t2[j] == false)
			lambdi[j + tight_size] = glp_get_col_prim(lp, tight_size + j + 1);
	}
	while (i < tight_size && sumt < tight_size) {
		if (lambdi[i] > prec) {
			U[i] = false;
			t[i] = true;
			ar0pos[i] = true;
			//ar[count - tight_size - tight2_size - rank + i + 1] = 0;
			glp_set_obj_coef(lp, i + 1, 0);
			sumt++;
			unsettled[T_coord[i]] = false;
			unsettled[s - 1 - T_coord[i]] = false;
			if (binrank2(Arref, J, Atight[i], n, rank)) {
				rank++;
				if (epsi > epsi_old) {
					settled = true;
					epsi_old = epsi;
				}
				if (disp)
					cout << "lambda_" << T_coord[i] + 1 << " > 0, rank = " << rank << " (" << s - T_coord[i] << " settled as well)" << endl;
				//rowechform(Arref, J, Atight[i], n, rank);
				Asettled[rank - 1] = Atight[i];
				if (disp) {
					cout << "Arref:" << endl;
					for (unsigned short int j = 0; j < n; j++) {
						for (unsigned short int k = 0; k < n; k++) {
							cout << Arref[j][k] << " ";
						}
						cout << endl;
					}
					cout << "J: ";
					for (unsigned short int j = 0; j < n; j++)
						cout << J[j] << " ";
					cout << endl;
				}
				if (rank == n) {
					if (disp)
						cout << "Rank condition satisfied!" << endl;
					return;
				}
				glp_set_col_bnds(lp, i + 1, GLP_FR, -DBL_MAX, DBL_MAX);
			}
			else {
				if (disp)
					cout << "lambda_" << T_coord[i] + 1 << " > 0, got settled (with " << s - T_coord[i] << ") without rank increase" << endl;
			}
		}
		i++;
	}
	i = 0;
	while (i < tight2_size && sumt2 < tight2_size) {
		if (lambdi[i + tight_size] > prec) {
			U2[i] = false;
			t2[i] = true;
			sumt2++;
			glp_set_obj_coef(lp, tight_size + i + 1, 0);
			unsettled[T2_coord[i]] = false;
			unsettled[s - 1 - T2_coord[i]] = false;
			if (binrank2(Arref, J, Atight2[i], n, rank)) {
				rank++;
				if (epsi > epsi_old) {
					settled = true;
					epsi_old = epsi;
				}
				if (disp)
					cout << "lambda_" << T2_coord[i] + 1 << " > 0, rank = " << rank << " (" << s - T2_coord[i] << " settled as well)" << endl;
				//rowechform(Arref, J, Atight2[i], n, rank);
				Asettled[rank - 1] = Atight2[i];
				if (disp) {
					cout << "Arref:" << endl;
					for (unsigned short int j = 0; j < n; j++) {
						for (unsigned short int k = 0; k < n; k++) {
							cout << Arref[j][k] << " ";
						}
						cout << endl;
					}
					cout << "J: ";
					for (unsigned short int j = 0; j < n; j++)
						cout << J[j] << " ";
					cout << endl;
				}
				if (rank == n) {
					if (disp)
						cout << "Rank condition satisfied!" << endl;
					return;
				}
				glp_set_col_bnds(lp, tight_size + i + 1, GLP_FR, -DBL_MAX, DBL_MAX);
			}
			else {
				if (disp)
					cout << "lambda_" << T_coord[i] + 1 << " > 0, got settled (with " << s - T_coord[i] << ") without rank increase" << endl;
			}
		}
		i++;
	}
	for (unsigned short int i = 0; i < n; i++)
		if (unsettled_p[i] == true && unsettled[pow(2, i) - 1] == false)
			unsettled_p[i] = false;
	return;
}

void step(vector<bool>& T, vector<bool>& T2, vector<bool>& unsettled, vector<bool>& unsettled_p, unsigned int& s, double& epsi, vector<double>& excess, vector<double>& d, unsigned short int& n, vector<double>& x, vector<double>& singleton_bounds, bool& disp, double& prec, vector<unsigned short int>& zeros, vector<unsigned int>& T_coord, unsigned int& t_size, vector<unsigned int>& T2_coord, unsigned short int& t2_size, vector<vector<bool>>& Atight, vector<vector<bool>>& Atight2, vector<bool>& U, vector<bool>& U2) {
	double ad = d[0];
	vector<double> Ud(n, 0);
	double alpha = DBL_MAX;
	double alpha1 = DBL_MAX;
	double alpha2 = DBL_MAX;
	vector<unsigned int> argmin(0, 0);
	vector<unsigned int> argmin2(0, 0);
	for (unsigned short int i = 0; i < n; i++) {
		Ud[i] = d[i];
		for (unsigned short int j = 0; j < i; j++)
			Ud[i] -= d[j];
	}
	if ((ad < 1 - prec) && unsettled[0] && !T2[0] && !T[0]) {
		alpha1 = (epsi - excess[0]) / (ad - 1);
		argmin.push_back(0);
	}
	for (unsigned int j = 1; j < s; j++) {
		ad += Ud[zeros[j]];
		if ((ad < 1 - prec) && unsettled[j] && !T[j])
			if (alpha1 - prec > (epsi - excess[j]) / (ad - 1)) {
				alpha1 = (epsi - excess[j]) / (ad - 1);
				argmin = vector<unsigned int>(1, 0);
				argmin[0] = j;
			}
			else {
				if (abs(alpha1 - (epsi - excess[j]) / (ad - 1)) < prec)
					argmin.push_back(j);
			}
	}
	for (unsigned short int i = 0; i < n; i++) {
		if (!T2[i] && unsettled_p[i] && d[i] < -prec) {
			if ((singleton_bounds[i] - x[i]) / d[i] < alpha2 - prec) {
				alpha2 = (singleton_bounds[i] - x[i]) / d[i];
				argmin2 = vector<unsigned int>(1, 0);
				argmin2[0] = i;
			}
			else {
				if (abs((singleton_bounds[i] - x[i]) / d[i] - alpha2) < prec)
					argmin2.push_back(i);
			}
		}
	}
	if (alpha1 < alpha2 - prec)
		alpha = alpha1;
	else {
		if (alpha2 < alpha1 - prec)
			alpha = alpha2;
		else
			alpha = alpha1;
	}
	if (disp)
		cout << "Step size: " << alpha << endl;
	if (disp)
		cout << endl << "  --==  step size obtained  ==--  " << endl << endl;
	for (unsigned short int i = 0; i < n; i++)
		x[i] += alpha * d[i];
	if (disp) {
		cout << "New point: " << endl;
		for (unsigned short int i = 0; i < n; i++)
			cout << x[i] << endl;
	}
	ad = d[0];
	if (unsettled[0]) {
		excess[0] += alpha * ad;
		if (ad > 1 + prec && T[0]) {
			for (unsigned int i = 0; i < t_size; i++) {
				if (T_coord[i] == 0) {
					T[0] = false;
					T_coord.erase(T_coord.begin() + i);
					Atight.erase(Atight.begin() + i);
					U.erase(U.begin() + i);
					t_size--;
					break;
				}
			}
		}
	}
	else {
		if (T[0]) {
			for (unsigned int i = 0; i < t_size; i++) {
				if (T_coord[i] == 0) {
					T[0] = false;
					T_coord.erase(T_coord.begin() + i);
					Atight.erase(Atight.begin() + i);
					U.erase(U.begin() + i);
					t_size--;
					break;
				}
			}
		}
	}
	for (unsigned int j = 1; j < s; j++) {
		ad += Ud[zeros[j]];
		if (unsettled[j]) {
			excess[j] += alpha * ad;
			if (ad > 1 + prec && T[j]) {
				for (unsigned int i = 0; i < t_size; i++) {
					if (T_coord[i] == j) {
						T[j] = false;
						T_coord.erase(T_coord.begin() + i);
						Atight.erase(Atight.begin() + i);
						U.erase(U.begin() + i);
						t_size--;
						break;
					}
				}
			}
		}
		else {
			if (T[j]) {
				for (unsigned int i = 0; i < t_size; i++) {
					if (T_coord[i] == j) {
						T[j] = false;
						T_coord.erase(T_coord.begin() + i);
						Atight.erase(Atight.begin() + i);
						U.erase(U.begin() + i);
						t_size--;
						break;
					}
				}
			}
		}
	}
	for (unsigned short int j = 0; j < n; j++) {
		if (unsettled_p[j] && T2[j] && d[j] > prec) {
			for (unsigned short int i = 0; i < t2_size; i++) {
				if (T2_coord[i] == pow(2, j) - 1) {
					T2[j] = false;
					T2_coord.erase(T2_coord.begin() + i);
					Atight2.erase(Atight2.begin() + i);
					U2.erase(U2.begin() + i);
					t2_size--;
					break;
				}
			}
		}
		else {
			if (!unsettled_p[j] && T2[j]) {
				for (unsigned short int i = 0; i < t2_size; i++) {
					if (T2_coord[i] == pow(2, j) - 1) {
						T2[j] = false;
						T2_coord.erase(T2_coord.begin() + i);
						Atight2.erase(Atight2.begin() + i);
						U2.erase(U2.begin() + i);
						t2_size--;
						break;
					}
				}
			}
		}
	}
	for (unsigned int i = 0; i < t_size; i++)
		U[i] = true;
	for (unsigned short int i = 0; i < t2_size; i++)
		U2[i] = true;
	epsi += alpha;
	if (alpha1 < alpha2 - prec) {
		for (unsigned int j = 0; j < argmin.size(); j++) {
			T[argmin[j]] = true;
			T_coord.push_back(argmin[j]);
			Atight.push_back(vector<bool>(n, false));
			de2bi(argmin[j], Atight[t_size], n);
			U.push_back(true);
			t_size++;
		}
	}
	else {
		if (alpha2 < alpha1 - prec) {
			for (unsigned int j = 0; j < argmin2.size(); j++) {
				T2[argmin2[j]] = true;
				T2_coord.push_back(pow(2, argmin2[j]) - 1);
				Atight2.push_back(vector<bool>(n, false));
				de2bi(T2_coord[t2_size], Atight2[t2_size], n);
				U2.push_back(true);
				t2_size++;
			}
		}
		else {
			for (unsigned int j = 0; j < argmin.size(); j++) {
				T[argmin[j]] = true;
				T_coord.push_back(argmin[j]);
				Atight.push_back(vector<bool>(n, false));
				de2bi(argmin[j], Atight[t_size], n);
				U.push_back(true);
				t_size++;
			}
			for (unsigned int j = 0; j < argmin2.size(); j++) {
				T2[argmin2[j]] = true;
				T2_coord.push_back(pow(2, argmin2[j]) - 1);
				Atight2.push_back(vector<bool>(n, false));
				de2bi(T2_coord[t2_size], Atight2[t2_size], n);
				U2.push_back(true);
				t2_size++;
			}
		}
	}
	return;
}

void imprdir(vector<double>& d, unsigned short int& n, unsigned int& t_size, unsigned short int& t2_size, vector<vector<bool>>& Atight, vector<vector<bool>>& Atight2, vector<bool>& U, vector<bool>& U2, unsigned short int& rank, vector<vector<bool>>& Asettled, bool& disp) {
	glp_prob* dir_lp;
	dir_lp = glp_create_prob();
	glp_set_obj_dir(dir_lp, GLP_MIN);
	glp_add_cols(dir_lp, n);
	glp_add_rows(dir_lp, t_size + t2_size + rank);
	for (unsigned int i = 1; i < t_size + 1; i++) {
		if (U[i - 1]) {
			glp_set_row_bnds(dir_lp, i, GLP_LO, 1, DBL_MAX);
		}
		else {
			glp_set_row_bnds(dir_lp, i, GLP_FX, 0, 0);
		}
	}
	for (unsigned short int i = 1; i < t2_size + 1; i++)
		glp_set_row_bnds(dir_lp, t_size + i, GLP_LO, 0, DBL_MAX);
	for (unsigned short int i = 1; i < rank + 1; i++)
		glp_set_row_bnds(dir_lp, t_size + t2_size + i, GLP_FX, 0, 0);
	for (unsigned short int i = 1; i < n + 1; i++)
		glp_set_col_bnds(dir_lp, i, GLP_FR, -DBL_MAX, DBL_MAX);
	vector<unsigned int> sumd(n, 0);
	for (unsigned int i = 0; i < t_size; i++) {
		if (U[i]) {
			for (unsigned short int j = 0; j < n; j++) {
				if (Atight[i][j])
					sumd[j]++;
			}
		}
	}
	for (unsigned short int i = 1; i < n + 1; i++)
		glp_set_obj_coef(dir_lp, i, sumd[i - 1]);
	vector<int> ia(n * (t_size + t2_size + rank) + 1, 0);
	vector<int> ja(n * (t_size + t2_size + rank) + 1, 0);
	vector<double> ar(n * (t_size + t2_size + rank) + 1, 0);
	unsigned int count = 0;
	for (unsigned int i = 1; i < t_size + 1; i++) {
		for (unsigned short int j = 1; j < n + 1; j++) {
			count++;
			ia[count] = i;
			ja[count] = j;
			if (Atight[i - 1][j - 1])
				ar[count] = 1;
			else
				ar[count] = 0;
		}
	}
	for (unsigned int i = 1; i < t2_size + 1; i++) {
		for (unsigned short int j = 1; j < n + 1; j++) {
			count++;
			ia[count] = i + t_size;
			ja[count] = j;
			if (Atight2[i - 1][j - 1])
				ar[count] = 1;
			else
				ar[count] = 0;
		}
	}
	for (unsigned int i = 1; i < rank + 1; i++) {
		for (unsigned short int j = 1; j < n + 1; j++) {
			count++;
			ia[count] = i + t_size + t2_size;
			ja[count] = j;
			if (Asettled[i - 1][j - 1])
				ar[count] = 1;
			else
				ar[count] = 0;
		}
	}
	int* ia_arr = ia.data();
	int* ja_arr = ja.data();
	double* ar_arr = ar.data();
	glp_load_matrix(dir_lp, count, ia_arr, ja_arr, ar_arr);
	glp_smcp parm;
	glp_init_smcp(&parm);
	if (!disp)
		parm.msg_lev = GLP_MSG_OFF;
	glp_simplex(dir_lp, &parm);
	for (unsigned short int j = 1; j < n + 1; j++)
		d[j - 1] = glp_get_col_prim(dir_lp, j);
	glp_delete_prob(dir_lp);
	glp_free_env();
	return;
}

bool binrank(vector<vector<double>>& Arref, vector<bool>& J, vector<bool>& b, unsigned short int& n, unsigned short int& rank) {
	double prec = pow(10, -10);
	vector<double> B(n, 0);
	for (unsigned short int i = 0; i < n; i++) {
		if (b[i] == true)
			B[i] = 1;
	}
	// m = rank
	// pivot_col[i] = !J[i]
	if (rank >= n)
		return false;
	else {
		unsigned short int j = 0;
		vector<bool> piv(n, false);
		vector<double> aux(n, 0);
		unsigned short int k = 0;
		unsigned short int I = 0;
		unsigned int s = 0;
		unsigned short int ind = 0;
		unsigned short int count = 0;
		while (j < n) {
			for (unsigned short i = 0; i < n; i++) {
				if (B[i] > prec || B[i] < -prec)
					piv[i] = true;
			}
			sum_vecb(s, piv);
			if (s == 0)
				return false;
			else {
				while (k == 0) {
					if (piv[I] == true)
						k = I + 1;
					I++;
				}
				k--;
				I = 0;
				if (J[k] == true) {
					return true;
				}
				else {
					while (count < k + 1) {
						if (!J[count])
							ind++;
						count++;
					}
					ind--;
					count = 0;
					sc_vec_prod(aux, B[k] / Arref[ind][k], Arref[ind]);
					vec_subtract(B, B, aux);
					j++;
				}
			}
			for (unsigned short int l = 0; l < n; l++)
				piv[l] = false;
			k = 0;
			ind = 0;
		}
		return false;
	}
}

bool binrank2(vector<vector<double>>& Arref, vector<bool>& J, vector<bool>& b, unsigned short int& n, unsigned short int& rank) {
	double prec = pow(10, -10);
	vector<double> B(n, 0);
	for (unsigned short int i = 0; i < n; i++) {
		if (b[i] == true)
			B[i] = 1;
	}
	// m = rank
	// pivot_col[i] = !J[i]
	if (rank >= n)
		return false;
	else {
		unsigned short int j = 0;
		vector<bool> piv(n, false);
		vector<double> aux(n, 0);
		unsigned short int k = 0;
		unsigned short int I = 0;
		unsigned int s = 0;
		unsigned short int ind = 0;
		unsigned short int count = 0;
		while (j < n) {
			for (unsigned short i = 0; i < n; i++) {
				if (B[i] > prec || B[i] < -prec)
					piv[i] = true;
			}
			sum_vecb(s, piv);
			if (s == 0)
				return false;
			else {
				while (k == 0) {
					if (piv[I] == true)
						k = I + 1;
					I++;
				}
				k--;
				I = 0;
				if (J[k] == true) {
					for (unsigned short i = 0; i < k; i++)
						if (!J[i])
							I++;
					for (unsigned short i = 0; i < rank - I; i++)
						Arref[rank - i] = Arref[rank - i - 1];
					Arref[I] = B;
					J[k] = false;
					return true;
				}
				else {
					while (count < k + 1) {
						if (!J[count])
							ind++;
						count++;
					}
					ind--;
					count = 0;
					sc_vec_prod(aux, B[k] / Arref[ind][k], Arref[ind]);
					vec_subtract(B, B, aux);
					j++;
				}
			}
			for (unsigned short int l = 0; l < n; l++)
				piv[l] = false;
			k = 0;
			ind = 0;
		}
		return false;
	}
}

void sum_vecb(unsigned int& s, vector<bool>& x) {
	// sums up the values of boolean x
	s = 0;
	for (unsigned int i = 0; i < x.size(); i++)
		s += x[i];
	return;
}

void vec_subtract(vector<double>& z, vector<double>& x, vector<double>& y) {
	// subtracts vector (double) y from vector (double) x
	for (unsigned int i = 0; i != x.size(); i++)
		z[i] = x[i] - y[i];
	return;
}

void sc_vec_prod(vector<double>& y, double a, vector<double>& x) {
	for (unsigned int i = 0; i < x.size(); i++)
		y[i] = a * x[i];
	return;
}

void period_0(unsigned short int& Q, vector<unsigned short int>& no_of_active_nodes, unsigned short int& N, vector<unsigned short int>& s, unsigned short int& Vp, vector<unsigned short int>& node_arrives, ListGraph::NodeMap<bool>& active_nodes, ListDigraph::NodeMap<bool>& active_nodes_original, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, vector<double>& credit, set<int>& active_source, vector<int>& source_set) {
	Q = 0;
	active_source.clear();
	for (unsigned short int i = 0; i < N; i++) {
		s[i] = 0;
		credit[i] = 0;
		no_of_active_nodes[i] = Vp / 4;
		for (unsigned short int j = 0; j < Vp; j++) {
			if (node_arrives[i * Vp + j] == 0) {
				active_nodes[c[i * Vp + j]] = true;
				active_nodes[c_b[i * Vp + j]] = true;
				active_nodes_original[c_original[i * Vp + j]] = true;
				active_source.insert(source_set[i * Vp + j]);
			}
			else {
				active_nodes[c[i * Vp + j]] = false;
				active_nodes[c_b[i * Vp + j]] = false;
				active_nodes_original[c_original[i * Vp + j]] = false;
			}
		}
	}
	return;
}

void min_d_1(vector<unsigned short int>& node_arrives, vector<bool>& leaving, ListGraph::NodeMap<bool>& active_nodes, ListDigraph::NodeMap<bool>& active_nodes_original, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, bool& disp, vector<unsigned short int>& no_of_active_nodes, unsigned short int& N, unsigned short int& Vp, unsigned short int& periods, bool& dispy, vector<unsigned short int>& s, unsigned short int& Q, vector<double>& v, bool& initial_nucl, vector<double>& credit, vector<double>& d, double& M_total, double& d_total, bool& c_involved, bool& arbitray_maximum, unsigned short int& initialSize, unsigned int& S, double& prec, vector<double>& init_alloc, double& d_c_total, unsigned short int inst, bool lex_min, double& max_d, double& game_generation, double& solution_concept_time, double& scenario_time, vector<vector<double>>& average_d_period, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, vector<vector<double>>& time_breakdown, set<int>& active_source, vector<int>& source_set, Allocation& allo, vector<int>& node_set, vector<unsigned short int>& label_positions, vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, int& n_t, double& relative_deviation, map<int, int>& cycle_dis, vector<double>& relative_optimal) {
	Q = 0;
	d_total = 0;
	d_c_total = 0;
	M_total = 0;
	max_d = 0;
	active_source.clear();
	if (dispy)
		cout << " --== Without lex min matching == -- " << endl;
	for (unsigned short int i = 0; i < N; i++) {
		d[i] = 0;
		s[i] = 0;
		credit[i] = 0;
		no_of_active_nodes[i] = initialSize;
		for (unsigned short int j = 0; j < Vp; j++) {
			if (node_arrives[i * Vp + j] == 0) {
				active_nodes[c[i * Vp + j]] = true;
				active_nodes[c_b[i * Vp + j]] = true;
				active_nodes_original[c_original[i * Vp + j]] = true;
				active_source.insert(source_set[i * Vp + j]);
			}
			else {
				active_nodes[c[i * Vp + j]] = false;
				active_nodes[c_b[i * Vp + j]] = false;
				active_nodes_original[c_original[i * Vp + j]] = false;
			}
		}
	}
	int temp_max = 0;
	bool is_cycle_dis = false;
	while (Q < 4) {
		is_cycle_dis = true;
		v[S] = solve_obj(allo, active_source, node_set, label_positions, cycle_dis, is_cycle_dis);

		if (is_cycle_dis) {
			for (int i : node_set) {
				for (int j = 0; j < N; j++) {
					if (j * Vp <= label_positions[i] && label_positions[i] < (j + 1) * Vp) {
						//cout << "label_positions[i]: " << label_positions[i] << ";" << "between " << j * Vp << " and " << (j + 1) * Vp << endl;
						s[j]++;
						leaving[label_positions[i]] = true;
					}
				}
			}
		}
		Q++;
		changing_nodes(active_nodes, active_nodes_original, leaving, no_of_active_nodes, N, Vp, node_arrives, Q, c, c_b, c_original, s, d, active_source, source_set);
		temp_max += v[S];
		M_total += v[S];

	}
	is_cycle_dis = false;
	while (Q < periods) {
		if (dispy) {
			cout << "--== PERIOD " << Q + 1 << " ==--" << endl;
		}
		if (dispy) {
			cout << "Number of active nodes: ";
			for (unsigned short int i = 0; i < N; i++)
				cout << no_of_active_nodes[i] << " ";
			cout << endl;
		}
		// cooperative game and target
		cout << "start generating values" << endl;
		coop_game(v, S, s, c, c_b, dispy, Vp, N, active_nodes, leaving, Q, arbitray_maximum, game_generation, time_breakdown, inst, allo, active_source, source_set, node_set, label_positions, arc_in, arc_out, cycle_dis);
		double t0 = cpuTime();
		if (initial_nucl)
			nucl(disp, N, S, init_alloc, v, prec);
		else {
			shapley(init_alloc, v, N, S);

		}
		double t1 = cpuTime();
		solution_concept_time += t1 - t0;
		time_breakdown[N - 4][inst * 4 + 1] += t1 - t0;
		if (dispy) {
			if (initial_nucl) {
				cout << "nucl: ";
			}
			else {
				cout << "Shapley: ";
			}
			for (unsigned short int i = 0; i < N; i++) {
				cout << init_alloc[i] << " ";
			}
			cout << endl;
		}
		t0 = cpuTime();
		ILP_d1_gurobi(Q, N, Vp, v[S], M_total, s, leaving, d, d_total, c_involved, credit, init_alloc, lex_min, inst, average_d_period, track_not_optimal, track_time_limit, allo, active_source, node_set, label_positions, n_t, cycle_dis);
		t1 = cpuTime();
		scenario_time += t1 - t0;
		time_breakdown[N - 4][inst * 4 + 3] += t1 - t0;
		Q++;
		changing_nodes(active_nodes, active_nodes_original, leaving, no_of_active_nodes, N, Vp, node_arrives, Q, c, c_b, c_original, s, d, active_source, source_set);
		if (dispy)
			cin.get();
	}
	for (unsigned short int i = 0; i < N; ++i) {
		d_total += abs(d[i]);
		if (c_involved) {
			d_c_total += abs(credit[i]);
		}
	}
	vector<double> max_deviation(N, 0);
	for (unsigned short int i = 0; i < N; ++i) {
		max_deviation[i] = abs(d[i]) / (M_total - temp_max);
	}
	std::sort(max_deviation.begin(), max_deviation.end());
	max_d = max_deviation[N - 1];
	relative_deviation += d_total / (M_total - temp_max);
	if (track_time_limit[N - 4][inst] != 9) {
		relative_optimal[N - 4] += d_total / (M_total - temp_max);

	}
	return;
}

double core_dist(vector<double>& x, vector<double>& v, unsigned short int& N, unsigned int& S) {
	double eps = x[0] - v[0];
	if (x[1] - v[1] < eps)
		eps = x[1] - v[1];
	vector<bool> a(N, false);
	double xS = 0;
	for (unsigned int i = 2; i < S; i++) {
		de2bi(i, a, N);
		for (unsigned short int j = 0; j < N; j++) {
			if (a[j]) {
				xS += x[j];
			}

		}
		if (xS - v[i] < eps)
			eps = xS - v[i];
		xS = 0;
	}
	return eps;
}

void ILP_d1_gurobi(unsigned short int& Q, unsigned short int& N, unsigned short int& Vp, double& M, double& M_total, vector<unsigned short int>& s, vector<bool>& leaving, vector<double>& d, double& d_total, bool& c_involved, vector<double>& credit, vector<double>& init_alloc, bool lex_min, unsigned short int inst, vector<vector<double>>& average_d_period, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, Allocation& allo, set<int>& active_source, vector<int>& node_set, vector<unsigned short int>& label_positions, int& n_t, map<int, int>& cycle_dis) {
	M_total += M;
	// Create an environment
	GRBEnv env = GRBEnv(true);
	env.set("LogFile", "mip_shapley_lexmin_c.log");
	env.set("OutputFlag", "0");
	env.start();
	allo.dynamic(active_source);
	node_set.clear();

	// Create an empty model
	GRBModel model = GRBModel(env);
	model.set("TimeLimit", "3600");
	vector<GRBModel> vector_model(2 * N - 1, GRBEnv(env));
	for (unsigned short int i = 0; i < 2 * N - 1; ++i) {
		vector_model[i].set("TimeLimit", "3600");
	}

	vector<GRBVar> isCycleUsed(allo.cycles.size());
	GRBVar var_d1;
	vector<GRBLinExpr> isPatientUsed(allo.maxId + 1);
	GRBLinExpr M_estar;
	vector<GRBLinExpr> cons_d1(N);
	vector<GRBVar> abs_var(2 * N);
	vector<bool> isPatientIdUsed(allo.maxId + 1, false);

	// Initialize cycle variables
	for (int i = 0; i < allo.cycles.size(); i++) {
		isCycleUsed[i] = model.addVar(0, 1, 0, GRB_BINARY);
	}
	// N difference variables
	for (int i = 0; i < N; i++) {
		abs_var[i] = model.addVar(-GRB_INFINITY, GRB_INFINITY, 0.0, GRB_CONTINUOUS);
	}
	// N abs variables
	for (int i = 0; i < N; i++) {
		abs_var[i + N] = model.addVar(0, GRB_INFINITY, 0.0, GRB_CONTINUOUS);
	}

	// variable d1
	var_d1 = model.addVar(0.0, GRB_INFINITY, 0.0, GRB_CONTINUOUS);

	for (int i = 0; i < allo.maxId + 1; i++) {
		isPatientUsed[i] = 0;
	}


	// Perform values, absolute deviations
	for (int i = 0; i < allo.cycles.size(); i++) {
		for (int j = 0; j < allo.cycles[i].idX.size(); j++) {
			isPatientUsed[allo.cycles[i].idX[j]] += isCycleUsed[i];
			isPatientIdUsed[allo.cycles[i].idX[j]] = true;
			for (int k = 0; k < N; k++) {
				if (k * Vp <= label_positions[allo.cycles[i].idX[j]] && label_positions[allo.cycles[i].idX[j]] < (k + 1) * Vp) {
					cons_d1[k] += isCycleUsed[i];
				}
			}
		}
		M_estar += allo.cycles[i].idX.size() * isCycleUsed[i];

	}

	// maximum size
	model.addConstr(M_estar == M);

	// bounds on absolute deviations
	vector<double> bound(N, 0);
	for (unsigned short int i = 1; i < N + 1; ++i) {
		bound[i - 1] = init_alloc[i - 1] + credit[i - 1];
		cout << " init_alloc[i]: " << init_alloc[i - 1] << " credit: " << credit[i - 1] << endl;
	}

	for (unsigned short int i = 1; i < N + 1; ++i) {
		model.addConstr(abs_var[i - 1] == cons_d1[i - 1] - bound[i - 1]);
		model.addGenConstrAbs(abs_var[N + i - 1], abs_var[i - 1]);
		model.addConstr(abs_var[N + i - 1] <= var_d1);
	}

	model.setObjective(1 * var_d1, GRB_MINIMIZE);
	// Unique assignment for patients
	for (int i = 0; i < allo.maxId + 1; i++) {
		if (isPatientIdUsed[i]) model.addConstr(isPatientUsed[i] <= 1);
	}

	// Setting of Gurobi
	model.getEnv().set(GRB_DoubleParam_TimeLimit, 3600);
	//model.getEnv().set(GRB_IntParam_Method, 3);
	//model.getEnv().set(GRB_IntParam_Threads, 16);
	//model.getEnv().set(GRB_DoubleParam_MIPGap, 0);
	model.optimize();

	int optimstatus = model.get(GRB_IntAttr_Status);
	if (optimstatus != 2) {
		track_not_optimal[N - 4][inst] = optimstatus;
		if (optimstatus == 9) {
			track_time_limit[N - 4][inst] = optimstatus;
		}
	}

	for (int i = 0; i < allo.cycles.size(); i++) {
		//cout << "error taking place" << endl;
		if (isCycleUsed[i].get(GRB_DoubleAttr_X) > pow(10, -4)) {
			for (int j = 0; j < allo.cycles[i].idX.size(); j++) {
				node_set.push_back(allo.cycles[i].idX[j]);
			}
		}
	}
	cout << "size of the M" << node_set.size() << endl;
	double obj = model.getObjective().getValue();

	cout << "obj: " << obj << endl;

	vector<double> d_t(N, 0);
	d_t[0] = var_d1.get(GRB_DoubleAttr_X);
	std::cout << "d_t[0]" << d_t[0] << endl;
	vector<unsigned short int> N_star(N, 0);
	unsigned short int n_star = 0;
	unsigned short int t_star = 0;
	double epsilon = 0;
	unsigned short int track = 0;
	vector<GRBVar> var_lexmin(allo.cycles.size());
	if (d_t[0] > 0.5 && lex_min) {
		epsilon_func(init_alloc, credit, epsilon, N);
		sort_d_t(d_t, isCycleUsed, label_positions, N, Vp, allo, init_alloc, t_star, credit, epsilon, var_lexmin, N_star);
	}
	std::cout << "finish sorting" << "epsilon:" << epsilon << endl;
	std::cout << "start n_star_1" << endl;
	if (lex_min && d_t[0] > 0.5 && abs(epsilon) > pow(10, -4)) {
		lex_min_n_star(d_t, lex_min, t_star, N, allo, M, Vp, epsilon, n_star, bound, N_star, var_lexmin, vector_model, track, track_not_optimal, track_time_limit, label_positions, inst, n_t);
	}
	std::cout << "finish n_star_1" << endl;
	lexmin_searching(d_t, lex_min, t_star, N, epsilon, n_star, bound, N_star, Vp, init_alloc, credit, var_lexmin, inst, vector_model, track, track_not_optimal, track_time_limit, M, allo, label_positions, n_t);

	cout << "finish lexmin_searching" << endl;

	unsigned short int t = 0;
	for (unsigned short int i = 1; i < allo.cycles.size() + 1; ++i) {
		//cout << "{" << arc_pair[i].first << "," << arc_pair[i].second << "}" << endl;
		//cout << var_bi[i - 1].get(GRB_DoubleAttr_X);
		if (lex_min && d_t[0] > 0.5) {
			if (var_lexmin[i - 1].get(GRB_DoubleAttr_X) > pow(10, -4)) {
				if (allo.cycles[i - 1].idX.size() == 0) {
					cout << "----------------0----------------" << endl;
					cout << "------------------period " << Q << "----------i-1 " << i - 1 << "-------------" << endl;
				}
				cycle_dis[allo.cycles[i - 1].idX.size()] += 1;
				t += allo.cycles[i - 1].idX.size();
				//cout << "pass 1" << endl;
				for (int k = 0; k < allo.cycles[i - 1].idX.size(); k++) {
					leaving[label_positions[allo.cycles[i - 1].idX[k]]] = true;
					//cout << "allo.cycles[i - 1].idX.size(): " << allo.cycles[i - 1].idX.size() << endl;
					//cout << "pass 2" << endl;
				}
				for (unsigned short int j = 0; j < N; ++j) {
					for (int k = 0; k < allo.cycles[i - 1].idX.size(); k++) {
						if (j * Vp <= label_positions[allo.cycles[i - 1].idX[k]] && label_positions[allo.cycles[i - 1].idX[k]] < (j + 1) * Vp) {
							++s[j];
							//cout << "pass 3" << endl;
						}
					}

				}
			}

		}
		else {
			if (isCycleUsed[i - 1].get(GRB_DoubleAttr_X) > pow(10, -4)) {
				if (allo.cycles[i - 1].idX.size() == 0) {
					cout << "----------------0----------------" << endl;
					cout << "isCycleUsed[i - 1].get(GRB_DoubleAttr_X): " << isCycleUsed[i - 1].get(GRB_DoubleAttr_X) << endl;
					cout << "------------------period " << Q << "----------i-1 " << i - 1 << "-------------" << endl;
				}
				cycle_dis[allo.cycles[i - 1].idX.size()] += 1;
				t += allo.cycles[i - 1].idX.size();
				//cout << "pass 4" << endl;
				for (int k = 0; k < allo.cycles[i - 1].idX.size(); k++) {
					leaving[label_positions[allo.cycles[i - 1].idX[k]]] = true;
					//cout << "pass 5" << endl;
				}
				for (unsigned short int j = 0; j < N; ++j) {
					for (int l = 0; l < allo.cycles[i - 1].idX.size(); l++) {
						if (j * Vp <= label_positions[allo.cycles[i - 1].idX[l]] && label_positions[allo.cycles[i - 1].idX[l]] < (j + 1) * Vp) {
							++s[j];
							//cout << "pass 6" << endl;
						}
					}
				}
			}
		}

	}
	cout << "size of M" << t << endl;
	model.reset();
	model.update();
	for (unsigned short int i = 0; i < track + 1; ++i) {
		vector_model[i].reset();
		vector_model[i].update();
	}


	std::cout << "maximum size: " << t;
	cout << "maximum size: " << t;
	double temp = 0;
	for (unsigned short int i = 0; i < N; ++i) {
		d[i] += init_alloc[i] - s[i];
		temp += abs(d[i]);
		if (c_involved) {
			credit[i] += init_alloc[i] - s[i];
		}
		else {
			credit[i] = 0;
		}
		cout << "country" << to_string(i) << "init_alloc[i]: " << init_alloc[i] << '/n' << "s[i]: " << s[i] << "d[i]: " << d[i] << "credit[i]: " << credit[i] << endl;
		//actual_alloc[Q].push_back(s[i]);
	}
	average_d_period[N - 4][Q] += temp;
	return;
}

void arbitraryMaximum(vector<unsigned short int>& node_arrives, vector<bool>& leaving, ListGraph::NodeMap<bool>& active_nodes, ListDigraph::NodeMap<bool>& active_nodes_original, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, bool& disp, vector<unsigned short int>& no_of_active_nodes, unsigned short int& N, unsigned short int& Vp, unsigned short int& periods, bool& dispy, vector<unsigned short int>& s, unsigned short int& Q, vector<double>& v, bool& initial_nucl, vector<double>& credit, vector<double>& d, double& M_total, double& d_total, bool& c_involved, bool& arbitray_maximum, unsigned short int& initialSize, unsigned int& S, double& prec, vector<double>& init_alloc, unsigned short int inst, double& max_d, double& game_generation, double& solution_concept_time, vector<vector<double>>& average_d_period, vector<vector<double>>& time_breakdown, set<int>& active_source, vector<int>& source_set, Allocation& allo, vector<int>& node_set, vector<unsigned short int>& label_positions, vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, double& relative_d1_arbitrary, map<int, int>& cycle_dis) {
	Q = 0;
	d_total = 0;
	M_total = 0;
	max_d = 0;
	if (dispy)
		cout << " --== Without lex min matching == -- " << endl;
	for (unsigned short int i = 0; i < N; i++) {
		s[i] = 0;
		credit[i] = 0;
		no_of_active_nodes[i] = initialSize;
		for (unsigned short int j = 0; j < Vp; j++) {
			if (node_arrives[i * Vp + j] == 0) {
				active_nodes[c[i * Vp + j]] = true;
				active_nodes[c_b[i * Vp + j]] = true;
				active_nodes_original[c_original[i * Vp + j]] = true;
				active_source.insert(source_set[i * Vp + j]);
			}
			else {
				active_nodes[c[i * Vp + j]] = false;
				active_nodes[c_b[i * Vp + j]] = false;
				active_nodes_original[c_original[i * Vp + j]] = false;
			}
		}
	}
	int temp_max = 0;
	bool is_cycle_dis = false;
	while (Q < 4) {
		is_cycle_dis = true;
		v[S] = solve_obj(allo, active_source, node_set, label_positions, cycle_dis, is_cycle_dis);

		if (arbitray_maximum) {
			for (int i : node_set) {
				for (int j = 0; j < N; j++) {
					if (j * Vp <= label_positions[i] && label_positions[i] < (j + 1) * Vp) {
						//cout << "label_positions[i]: " << label_positions[i] << ";" << "between " << j * Vp << " and " << (j + 1) * Vp << endl;
						s[j]++;
						leaving[label_positions[i]] = true;
					}
				}
			}
		}
		Q++;
		changing_nodes(active_nodes, active_nodes_original, leaving, no_of_active_nodes, N, Vp, node_arrives, Q, c, c_b, c_original, s, d, active_source, source_set);
		temp_max += v[S];
		M_total += v[S];

	}
	is_cycle_dis = false;
	while (Q < periods) {
		if (dispy) {
			cout << "--== PERIOD " << Q + 1 << " ==--" << endl;
		}
		if (dispy) {
			cout << "Number of active nodes: ";
			for (unsigned short int i = 0; i < N; i++)
				cout << no_of_active_nodes[i] << " ";
			cout << endl;
		}
		// cooperative game and target
		cout << "start generating values" << endl;
		coop_game(v, S, s, c, c_b, dispy, Vp, N, active_nodes, leaving, Q, arbitray_maximum, game_generation, time_breakdown, inst, allo, active_source, source_set, node_set, label_positions, arc_in, arc_out, cycle_dis);
		double t0 = cpuTime();
		if (initial_nucl)
			nucl(disp, N, S, init_alloc, v, prec);
		else {
			shapley(init_alloc, v, N, S);

		}
		double t1 = cpuTime();
		solution_concept_time += t1 - t0;
		time_breakdown[N - 4][inst * 4 + 1] += t1 - t0;
		M_total += v[S];

		double temp_0 = 0;
		for (unsigned short int i = 0; i < N; ++i) {
			d[i] += init_alloc[i] - s[i];
			temp_0 += abs(d[i]);
			if (c_involved) {
				credit[i] += init_alloc[i] - s[i];
			}
			else {
				credit[i] = 0;
			}
			cout << "country" << to_string(i) << "init_alloc[i]: " << init_alloc[i] << '/n' << "s[i]: " << s[i] << "d[i]: " << d[i] << "credit[i]: " << credit[i] << endl;
		}
		average_d_period[N - 4][Q] += temp_0;

		Q++;
		changing_nodes(active_nodes, active_nodes_original, leaving, no_of_active_nodes, N, Vp, node_arrives, Q, c, c_b, c_original, s, d, active_source, source_set);
		if (dispy)
			cin.get();
	}
	for (unsigned short int i = 0; i < N; ++i) {
		d_total += abs(d[i]);
	}
	vector<double> max_deviation(N, 0);
	for (unsigned short int i = 0; i < N; ++i) {
		max_deviation[i] = abs(d[i]) / (M_total - temp_max);
	}
	std::sort(max_deviation.begin(), max_deviation.end());
	max_d = max_deviation[N - 1];
	relative_d1_arbitrary += d_total / (M_total - temp_max);
	return;
}


void sort_d_t(vector<double>& d_t, vector<GRBVar>& isCycleUsed, vector<unsigned short int>& label_positions, unsigned short int& N, unsigned short int& Vp, Allocation& allo, vector<double>& target, unsigned short int& t, vector<double>& credit, double& epsilon, vector<GRBVar>& var_lexmin, vector<unsigned short int>& N_star) {
	unsigned short int n_star = 0;
	vector<unsigned short int> s_copy(N, 0);
	vector<double> d_copy(N, 0);
	for (unsigned short int i = 1; i < allo.cycles.size() + 1; ++i) {
		var_lexmin[i - 1] = isCycleUsed[i - 1];
		//cout << "{" << arc_pair[i].first << "," << arc_pair[i].second << "}" << endl;
		//cout << var_bi[i - 1].get(GRB_DoubleAttr_X);
		if (isCycleUsed[i - 1].get(GRB_DoubleAttr_X) > pow(10, -4)) {
			for (int k = 0; k < allo.cycles[i - 1].idX.size(); k++) {
				for (unsigned short int j = 0; j < N; j++) {
					if (j * Vp <= label_positions[allo.cycles[i - 1].idX[k]] && label_positions[allo.cycles[i - 1].idX[k]] < (j + 1) * Vp) {
						++s_copy[j];
					}
				}
			}

		}
	}
	for (unsigned short int i = 0; i < N; ++i) {
		d_copy[i] = abs(target[i] + credit[i] - s_copy[i]);
	}
	//sort
	std::sort(d_copy.begin(), d_copy.end());
	for (unsigned short int i = 0; i < N; ++i) {
		std::cout << "d_copy[i]" << d_copy[i] << endl;
		//std::cout << "s_copy" << s_copy[i] << endl;
	}
	//epsilon_func(target, credit, epsilon, N);
	int total = 0;
	for (int num : N_star) {
		total += num;
	}
	if (epsilon > 3 * pow(10, -4)) {
		d_t[t] = d_copy[N - 1 - total] + pow(10, -4);
	}
	else {
		d_t[t] = d_copy[N - 1 - total];
	}
	if (t < N - 1) {
		d_t[t + 1] = d_copy[N - 2 - total];
	}
	std::cout << "d" << to_string(t - 1) << d_t.back() << endl;
	std::cout << "epsilon: " << epsilon << endl;
}

void epsilon_func(vector<double>& target, vector<double>& credit, double& epsilon, unsigned short int N) {
	vector<double> target_credit(N, 0);
	vector<double> epsilon_sort(N * (N - 1), 0);
	for (unsigned short int i = 0; i < N; ++i) {
		cout << "target[i]: " << target[i] << endl;
		target_credit[i] = target[i] + credit[i];
	}

	unsigned short int t = -1;
	for (unsigned short int i = 0; i < N - 1; ++i) {
		for (unsigned short j = i + 1; j < N; ++j) {
			++t;
			//cout << "target_credit[i]: " << target_credit[i] << "target_credit[j]: " << target_credit[j] << endl;
			epsilon_sort[t] = abs(frac(target_credit[i]) - frac(target_credit[j]));
			//cout << "a-b: " << epsilon_sort[t] << endl;
			++t;
			epsilon_sort[t] = abs(frac(target_credit[i]) - (1 - frac(target_credit[j])));
			//cout << "a-(1-b): " << epsilon_sort[t] << endl;
		}
	}
	cout << "t" << t << endl;

	/*for (unsigned short int i = 0; i < epsilon_sort.size(); ++i) {
		cout << "epsilon_sort: " << epsilon_sort[i] << endl;
	}*/

	auto newEnd = std::remove_if(epsilon_sort.begin(), epsilon_sort.end(), [](double num) {
		return num < 2 * pow(10, -4);
		});
	epsilon_sort.erase(newEnd, epsilon_sort.end());

	std::sort(epsilon_sort.begin(), epsilon_sort.end());
	epsilon = epsilon_sort[0];
	cout << "epsilon_sort[0]" << epsilon_sort[0] << endl;
}

double frac(double ori) {
	double abs_frac;
	abs_frac = abs(ori) - abs(int(ori));
	return abs_frac;
}

void lex_min_n_star(vector<double>& d_t, bool& lex_min, unsigned short int& t_star, unsigned short int& N, Allocation& allo, double& M, unsigned short int& Vp, double& epsilon, unsigned short int& n_star, vector<double>& bound, vector<unsigned short int>& N_star, vector<GRBVar>& var_lexmin, vector<GRBModel>& vector_model, unsigned short int& track, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, vector<unsigned short int>& label_positions, unsigned short int inst, int& n_t) {
	++track;
	std::cout << "t_star: " << t_star << endl;
	vector<GRBVar> isCycleUsed(allo.cycles.size());
	vector<GRBLinExpr> isPatientUsed(allo.maxId + 1);
	GRBLinExpr M_estar;
	vector<GRBLinExpr> cons_d1(N);
	vector<bool> isPatientIdUsed(allo.maxId + 1, false);


	//cycle variables
	for (unsigned short int i = 0; i < allo.cycles.size(); ++i) {
		isCycleUsed[i] = vector_model[track].addVar(0.0, 1.0, 0.0, GRB_BINARY, "x" + to_string(i));
	}
	for (int i = 0; i < allo.maxId + 1; i++) {
		isPatientUsed[i] = 0;
	}

	// Perform values, absolute deviations
	for (int i = 0; i < allo.cycles.size(); i++) {
		for (int j = 0; j < allo.cycles[i].idX.size(); j++) {
			isPatientUsed[allo.cycles[i].idX[j]] += isCycleUsed[i];
			isPatientIdUsed[allo.cycles[i].idX[j]] = true;
			for (int k = 0; k < N; k++) {
				if (k * Vp <= label_positions[allo.cycles[i].idX[j]] && label_positions[allo.cycles[i].idX[j]] < (k + 1) * Vp) {
					// Vc and Vp
					cons_d1[k] += isCycleUsed[i];
				}
			}
		}
		M_estar += allo.cycles[i].idX.size() * isCycleUsed[i];
	}

	// maximum size
	vector_model[track].addConstr(M_estar == M);

	// Unique assignment for patients
	for (int i = 0; i < allo.maxId + 1; i++) {
		if (isPatientIdUsed[i] == true) vector_model[track].addConstr(isPatientUsed[i] <= 1);
	}






	// N difference variables
	vector<GRBVar> Var_dif(N);
	for (unsigned short int i = 0; i < N; ++i) {
		Var_dif[i] = vector_model[track].addVar(-GRB_INFINITY, GRB_INFINITY, 0.0, GRB_CONTINUOUS, "x" + to_string(i));
	}
	// N abs variables
	vector<GRBVar> Var_abs(N);
	for (unsigned short int i = 0; i < N; ++i) {
		Var_abs[i] = vector_model[track].addVar(0, GRB_INFINITY, 0.0, GRB_CONTINUOUS, "x" + to_string(i));
	}
	// z^t_p variables
	vector<GRBVar> Var_z_p((t_star + 1) * N);
	for (unsigned short i = 0; i < N * (t_star + 1); ++i) {
		Var_z_p[i] = vector_model[track].addVar(0.0, 1.0, 0.0, GRB_BINARY, "x" + to_string(i));
	}

	//sum z_p^t
	GRBLinExpr sum_zp = 0;
	for (unsigned short int i = N * t_star; i < N * (t_star + 1); i++) {
		sum_zp += Var_z_p[i];
	}
	vector_model[track].setObjective(sum_zp, GRB_MINIMIZE);


	// sum over (z_p^i)(d_i^*) between i=1 and i=t-1
	vector<GRBLinExpr> sum_zp_dp(N, 0);
	// sum over (z_p^i)(d_i^*) between i=1 and i=t
	vector<GRBLinExpr> sum_zp_t(N, 0);
	// sum over z_p^i for every i, where i<=t-1;
	vector<GRBLinExpr> sum_t_star(t_star, 0);
	// sum over z_p^i between i=0 and i=t;
	vector<GRBLinExpr> sum_p(N, 0);
	for (unsigned short int i = 0; i < t_star; ++i) {
		for (unsigned short int j = 0; j < N; ++j) {
			sum_zp_dp[j] += Var_z_p[i * N + j] * d_t[i];
			sum_zp_t[j] += Var_z_p[i * N + j] * d_t[i];
			sum_t_star[i] += Var_z_p[i * N + j];
			sum_p[j] += Var_z_p[i * N + j];
		}
	}
	for (unsigned short int j = 0; j < N; ++j) {
		sum_p[j] += Var_z_p[t_star * N + j];
		sum_zp_t[j] += Var_z_p[t_star * N + j] * d_t[t_star];
	}

	for (unsigned short int i = 1; i < N + 1; ++i) {
		vector_model[track].addConstr(Var_dif[i - 1] == cons_d1[i - 1] - bound[i - 1]);
		vector_model[track].addGenConstrAbs(Var_abs[i - 1], Var_dif[i - 1]);
		if (t_star == 0) {
			vector_model[track].addConstr(Var_abs[i - 1] <= d_t[t_star] - epsilon * (1 - Var_z_p[i - 1]));
		}
		if (t_star > 0) {
			vector_model[track].addConstr(Var_abs[i - 1] <= d_t[t_star] - epsilon * (1 - Var_z_p[t_star * N + i - 1]) + sum_zp_dp[i - 1]);
			vector_model[track].addConstr(Var_abs[i - 1] <= sum_zp_t[i - 1] + (1 - sum_p[i - 1]) * d_t[t_star - 1]);
		}
	}

	// for every p in N, sum over Z_p^i between i=1 and i=t is less than 1
	for (unsigned short int i = 0; i < N; ++i) {
		vector_model[track].addConstr(sum_p[i] <= 1);
	}
	// for every i, where i<=t-1, sum over z_p^i is equal to n_i^*
	for (unsigned short int i = 0; i < t_star; ++i) {
		vector_model[track].addConstr(sum_t_star[i] == N_star[i]);
	}

	std::cout << "finish loading constraints" << endl;
	vector_model[track].optimize();

	int optimstatus = vector_model[track].get(GRB_IntAttr_Status);
	if (optimstatus != 2) {
		track_not_optimal[N - 4][inst] = optimstatus;
		if (optimstatus == 9) {
			track_time_limit[N - 4][inst] = optimstatus;
		}
	}



	for (unsigned short int i = 0; i < N; ++i) {
		if (Var_z_p[N * t_star + i].get(GRB_DoubleAttr_X) > pow(10, -4)) {
			N_star[t_star] += 1;
		}
		//std::cout << "var_bi[col_num + N * (2 + t_star) + i].get(GRB_DoubleAttr_X): " << var_bi[col_num + N * (2 + t_star) + i].get(GRB_DoubleAttr_X) << endl;

	}
	std::cout << "epsilon: " << epsilon << "d_t[t_star: " << d_t[t_star] << endl;
	std::cout << "N_star[t_star]: " << N_star[t_star] << endl;
	std::cout << "finish n_" << to_string(t_star) << endl;
	n_star = 0;
	for (unsigned short int i = 0; i < N; ++i) {
		n_star += N_star[i];
	}
	t_star += 1;
	n_t = N_star[t_star];
	for (unsigned short int i = 0; i < allo.cycles.size(); ++i) {
		var_lexmin[i] = isCycleUsed[i];
	}

}

void lex_min_d_star(vector<double>& d_t, bool& lex_min, unsigned short int& t_star, unsigned short int& N, unsigned short int& n_star, vector<double>& bound, vector<unsigned short int>& N_star, unsigned short int& Vp, vector<double>& target, vector<double>& credit, vector<GRBVar>& var_lexmin, vector<GRBModel>& vector_model, unsigned short int& track, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, unsigned short int& inst, double& M, Allocation& allo, vector<unsigned short int>& label_positions, double& epsilon, int& n_t) {
	++track;
	vector<GRBVar> isCycleUsed(allo.cycles.size());
	vector<GRBLinExpr> isPatientUsed(allo.maxId + 1);
	GRBLinExpr M_estar;
	vector<GRBLinExpr> cons_d1(N);
	vector<bool> isPatientIdUsed(allo.maxId + 1, false);



	//cycle variables
	for (unsigned short int i = 0; i < allo.cycles.size(); ++i) {
		isCycleUsed[i] = vector_model[track].addVar(0.0, 1.0, 0.0, GRB_BINARY, "x" + to_string(i));
	}
	for (int i = 0; i < allo.maxId + 1; i++) {
		isPatientUsed[i] = 0;
	}

	// Perform values, absolute deviations
	for (int i = 0; i < allo.cycles.size(); i++) {
		for (int j = 0; j < allo.cycles[i].idX.size(); j++) {
			isPatientUsed[allo.cycles[i].idX[j]] += isCycleUsed[i];
			isPatientIdUsed[allo.cycles[i].idX[j]] = true;
			for (int k = 0; k < N; k++) {
				if (k * Vp <= label_positions[allo.cycles[i].idX[j]] && label_positions[allo.cycles[i].idX[j]] < (k + 1) * Vp) {
					// Vc and Vp
					cons_d1[k] += isCycleUsed[i];
				}
			}
		}
		M_estar += allo.cycles[i].idX.size() * isCycleUsed[i];
	}

	// maximum size
	vector_model[track].addConstr(M_estar == M);

	// Unique assignment for patients
	for (int i = 0; i < allo.maxId + 1; i++) {
		if (isPatientIdUsed[i] == true) vector_model[track].addConstr(isPatientUsed[i] <= 1);
	}






	// N difference variables
	vector<GRBVar> Var_dif(N);
	for (unsigned short int i = 0; i < N; ++i) {
		Var_dif[i] = vector_model[track].addVar(-GRB_INFINITY, GRB_INFINITY, 0.0, GRB_CONTINUOUS, "x" + to_string(i));
	}
	// N abs variables
	vector<GRBVar> Var_abs(N);
	for (unsigned short int i = 0; i < N; ++i) {
		Var_abs[i] = vector_model[track].addVar(0, GRB_INFINITY, 0.0, GRB_CONTINUOUS, "x" + to_string(i));
	}
	// z_p^(t-1) variables
	vector<GRBVar> Var_z_p(t_star * N);
	for (unsigned short i = 0; i < N * t_star; ++i) {
		Var_z_p[i] = vector_model[track].addVar(0.0, 1.0, 0.0, GRB_BINARY, "x" + to_string(i));
	}



	// d_t variable
	GRBVar Var_d_t = vector_model[track].addVar(0, GRB_INFINITY, 0.0, GRB_CONTINUOUS, "d" + to_string(t_star));
	GRBLinExpr obj = 1 * Var_d_t;

	vector_model[track].setObjective(obj, GRB_MINIMIZE);


	// sum over (z_p^i)(d_i^*) between i=1 and i=t-1
	vector<GRBLinExpr> sum_zp_dp(N, 0);
	// sum over z_p^i for every i, where i<=t-1;
	vector<GRBLinExpr> sum_t_star(t_star, 0);
	// sum over z_p^i between i=0 and i=t-1;
	vector<GRBLinExpr> sum_p(N, 0);
	for (unsigned short int i = 0; i < t_star; ++i) {
		for (unsigned short int j = 0; j < N; ++j) {
			sum_zp_dp[j] += Var_z_p[i * N + j] * d_t[i];
			sum_t_star[i] += Var_z_p[i * N + j];
			sum_p[j] += Var_z_p[i * N + j];
		}
	}


	for (unsigned short int i = 1; i < N + 1; ++i) {
		vector_model[track].addConstr(Var_dif[i - 1] == cons_d1[i - 1] - bound[i - 1]);
		vector_model[track].addGenConstrAbs(Var_abs[i - 1], Var_dif[i - 1]);
		if (t_star == 0) {
			vector_model[track].addConstr(Var_abs[i - 1] <= d_t[t_star]);
			vector_model[track].addConstr(Var_abs[i - 1] <= obj + sum_zp_dp[i - 1]);
		}
		if (t_star > 0) {
			vector_model[track].addConstr(Var_abs[i - 1] <= obj + sum_zp_dp[i - 1]);
			vector_model[track].addConstr(Var_abs[i - 1] <= sum_zp_dp[i - 1] + (1 - sum_p[i - 1]) * d_t[t_star - 1]);
			// for every p in N, sum over Z_p^i between i=1 and i=t is less than 1
			for (unsigned short int i = 0; i < N; ++i) {
				vector_model[track].addConstr(sum_p[i] <= 1);
			}
		}
	}


	// for every i, where i<=t-1, sum over z_p^i is equal to n_i^*
	for (unsigned short int i = 0; i < t_star; ++i) {
		vector_model[track].addConstr(sum_t_star[i] == N_star[i]);
	}

	std::cout << "finish loading constraints" << endl;
	vector_model[track].optimize();

	int optimstatus = vector_model[track].get(GRB_IntAttr_Status);
	if (optimstatus != 2) {
		track_not_optimal[N - 4][inst] = optimstatus;
		if (optimstatus == 9) {
			track_time_limit[N - 4][inst] = optimstatus;
		}
	}

	sort_d_t(d_t, isCycleUsed, label_positions, N, Vp, allo, target, t_star, credit, epsilon, var_lexmin, N_star);
}

void lexmin_searching(vector<double>& d_t, bool& lex_min, unsigned short int& t_star, unsigned short int& N, double& epsilon, unsigned short int& n_star, vector<double>& bound, vector<unsigned short int>& N_star, unsigned short int& Vp, vector<double>& target, vector<double>& credit, vector<GRBVar>& var_lexmin, unsigned short int inst, vector<GRBModel>& vector_model, unsigned short int& track, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, double& M, Allocation& allo, vector<unsigned short int>& label_positions, int& n_t) {
	while (lex_min && abs(d_t[t_star - 1]) > 0.5 && n_star < N) {
		std::cout << "begin search d_t" << endl;
		lex_min_d_star(d_t, lex_min, t_star, N, n_star, bound, N_star, Vp, target, credit, var_lexmin, vector_model, track, track_not_optimal, track_time_limit, inst, M, allo, label_positions, epsilon, n_t);
		std::cout << "inst: " << inst << endl;
		std::cout << "abs(d_t[t_star])" << abs(d_t[t_star]) << endl;
		std::cout << "t_star: " << t_star << endl;
		std::cout << "N-1: " << N - 1 << endl;
		std::cout << "epsilon in the loop: " << epsilon << endl;
		std::cout << "absolute epsilon in the loop: " << abs(epsilon) << endl;
		if (abs(d_t[t_star]) > 0.5) {
			if (abs(epsilon) > pow(10, -4)) {
				if (t_star == N - 1) {
					std::cout << "congratulations t_star == N - 1" << endl;
					//break
					n_star = N;
					std::cout << "congratulations after break" << endl;
				}
				else
				{
					if (d_t[t_star + 1] < 0.5) {
						std::cout << "congratulations d_t[t_star + 1] < 0.5" << endl;
						//break;
						n_star = N;
					}
					else {
						std::cout << "congratulations d_t[t_star + 1] > 0.5" << endl;
						lex_min_n_star(d_t, lex_min, t_star, N, allo, M, Vp, epsilon, n_star, bound, N_star, var_lexmin, vector_model, track, track_not_optimal, track_time_limit, label_positions, inst, n_t);
					}
				}
			}
			if (abs(epsilon) < pow(10, -4)) {
				std::cout << "congratulations abs(epsilon) < pow(10, -7))" << endl;
				lexmin_searching(d_t, lex_min, t_star, N, epsilon, n_star, bound, N_star, Vp, target, credit, var_lexmin, inst, vector_model, track, track_not_optimal, track_time_limit, M, allo, label_positions, n_t);
			}
		}
		else {
			std::cout << "congratulations break" << endl;
			//break
			n_star = N;
		}
	}
}

double solve_obj(Allocation& allo, set<int>& active_source, vector<int>& node_set, vector<unsigned short int>& label_positions, map<int, int>& cycle_dis, bool& is_cycle_dis) {

	GRBEnv env = GRBEnv();
	env.set("OutputFlag", "0");


	// Model
	try {
		allo.dynamic(active_source);
		node_set.clear();
		// Local variables
		GRBModel model = GRBModel(env);
		GRBLinExpr objFun1 = 0;

		vector<GRBVar> isCycleUsed(allo.cycles.size());
		vector<GRBLinExpr> isPatientUsed(allo.maxId + 1, 0);
		vector<bool> isPatientIdUsed(allo.maxId + 1, false);

		// Initialization
		for (int i = 0; i < allo.cycles.size(); i++) {
			isCycleUsed[i] = model.addVar(0, 1, 0, GRB_BINARY);
		}




		// Perform values
		set<int> error_node;
		for (int i = 0; i < allo.cycles.size(); i++) {
			for (int j = 0; j < allo.cycles[i].idX.size(); j++) {
				if (active_source.count(allo.cycles[i].idX[j])) {
					isPatientUsed[allo.cycles[i].idX[j]] += isCycleUsed[i];
					isPatientIdUsed[allo.cycles[i].idX[j]] = true;
					objFun1 += isCycleUsed[i];
				}
				else {
					//cout << "error in generating valid cycles" << endl;
					error_node.insert(allo.cycles[i].idX[j]);
				}
			}
		}

		//cout << "print our error nodes" << endl;
		//cout << "size of error nodes" << error_node.size() << endl;
		for (auto i = error_node.begin(); i != error_node.end(); i++) { cout << *i << endl; }
		//cout << "print out active sources" << endl;
		//cout << "size of active sources" << active_source.size() << endl;
		for (auto j = active_source.begin(); j != active_source.end(); j++) {}//cout << *j << endl;														
		int num_ofs = 0;
		for (int i = 0; i < allo.maxId + 1; i++) {
			if (isPatientIdUsed[i]) {
				model.addConstr(isPatientUsed[i] <= 1);
				num_ofs += 1;
			}
		}
		//cout << "number of constraints: " << num_ofs << endl;

		model.setObjective(objFun1, GRB_MAXIMIZE);



		// Setting of Gurobi
		model.getEnv().set(GRB_DoubleParam_TimeLimit, 3600);
		//model.getEnv().set(GRB_IntParam_Method, 3);
		//model.getEnv().set(GRB_IntParam_Threads, 16);
		//model.getEnv().set(GRB_DoubleParam_MIPGap, 0);
		model.optimize();

		int cnt = 0;
		//cout << "allo.cycles.size(): " << allo.cycles.size() << endl;
		for (int i = 0; i < allo.cycles.size(); i++) {
			if (isCycleUsed[i].get(GRB_DoubleAttr_X) > pow(10, -4)) {
				cnt += allo.cycles[i].idX.size();
				if (is_cycle_dis) {
					if (allo.cycles[i].idX.size() == 0) {
						cout << "----------------0----------------" << endl;
						cout << "----------i " << i << "-------------" << endl;
					}
					cycle_dis[allo.cycles[i].idX.size()] += 1;
				}
				for (int j = 0; j < allo.cycles[i].idX.size(); j++) {
					node_set.push_back(allo.cycles[i].idX[j]);
				}
			}
		}
		//cout << "cnt: " << cnt << endl;
		sort(node_set.begin(), node_set.end());
		/*cout << "----------print the node set------------" << endl;
		for (int i : node_set) {
			cout << i << endl;
		}*/
		//cout << "complete filling the node set" << endl;
		//cout << "the size of the node set" << node_set.size() << " the size of the active source:" << active_source.size() << endl;
		double obj = model.getObjective().getValue();
		model.reset();
		model.update();
		return obj;

	}

	// Exceptions
	catch (GRBException e) {
		cout << "Error code = " << e.getErrorCode() << endl;
		cout << e.getMessage() << endl;
	}
	catch (...) {
		cout << "Exception during optimization" << endl;
	}



}