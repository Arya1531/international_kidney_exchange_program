#pragma once

#include <iostream>
#include <string>
#include <fstream>
#include <vector>

#include <lemon/list_graph.h>
#include <lemon/concepts/graph.h>
#include <lemon/matching.h>
#include <lemon/adaptors.h>
#include <lemon/core.h>
#include <lemon/base.cc>
#include <lemon/concepts/maps.h>
#include <time.h>
#include <iomanip>
#include <glpk.h>
#include <math.h>
#include <stdio.h>
#include <cfloat>
#include "Allocation.h"
//#include "windows.h"
//#include "psapi.h"
#include <iterator>
#include "gurobi_c++.h"


using namespace lemon;
using namespace std;

double cpuTime();
bool is_next_char_digit(string& line, unsigned int l);
unsigned int char2uint(char& p);
void undi_lemon(unsigned int& m, vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, vector<unsigned short int>& label_positions, ListGraph& g, ListDigraph& g_original, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, ListGraph::EdgeMap<double>& edge_card_weight, ListDigraph::ArcMap<unsigned short int>& arc_card_weight, unsigned short int& no_of_nodes);
void coop_game(vector<double>& v, unsigned int& S, vector<unsigned short int>& s, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, bool& dispy, unsigned short int& Vp, unsigned short int& N, ListGraph::NodeMap<bool>& active_nodes, vector<bool>& leaving, unsigned short int& Q, bool& arbitray_maximum, double& game_generation, vector<vector<double>>& time_breakdown, unsigned short int inst, Allocation& allo, set<int>& active_source, vector<int>& source_set, vector<int>& node_set, vector<unsigned short int>& label_positions, vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, vector<map<int, int>>& cycle_dis, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit);
void xml_parser(string& line, vector<unsigned short int>& node_labels, vector<unsigned short int>& label_positions, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, unsigned short int& k, ListGraph& g, ListDigraph& g_original, vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, unsigned int& m, unsigned short int& no_of_nodes);
void shapley(vector<double>& shapl, vector<double>& v, unsigned short int& n, unsigned int& S);
void de2bi_card(unsigned int& k, vector<bool>& a, unsigned short int& n, unsigned short int& card);
void de2bi(unsigned int& k, vector<bool>& a, unsigned short int& n);
void insertion_sort(vector<unsigned short int>& w, vector<double>& y, unsigned short int& N);

void nucl(bool& disp, unsigned short int& n, unsigned int& s, vector<double>& x, vector<double>& v, double& prec);
void zeros_mem(vector<bool>& a, unsigned short int& n, unsigned int& s, vector<unsigned short int>& zeros);
void excess_init(vector<double>& exc, vector<bool>& unsettled, vector<double>& x, vector<double>& v, unsigned int& s, unsigned short int& n, vector<unsigned short int>& zeros);
void nucl_comp(bool& disp, unsigned short int& n, unsigned int& s, vector<double>& excess, double& prec, vector<bool>& unsettled, unsigned short int& iter, unsigned int& piv, unsigned int& sr, double& t, vector<double>& x, vector<bool>& a, double& t1, vector<double>& singleton_bounds, bool& nlsu, double& min_satisfaction, vector<unsigned short int>& zeros);
void vec_min_uns(double& m, vector<double>& x, vector<bool>& unsettled, unsigned int& s);
void tight_coal2(vector<bool>& T2, vector<double>& x, vector<double>& singleton_bounds, double& prec, unsigned short int& n, vector<unsigned int>& T2_coord, vector<bool>& unsettled_p, unsigned short int& t2_size);
void tight_coal(vector<bool>& T, vector<double>& excess, double& epsi, double& prec, unsigned int& s, vector<unsigned int>& T_coord, vector<bool>& unsettled, unsigned int& t_size);
void pivot(double& epsi, unsigned int& s, vector<double>& excess, double& prec, unsigned short int& n, vector<bool>& a, vector<vector<double>>& Arref, vector<bool>& J, vector<bool>& unsettled, unsigned short int& rank, vector<double>& d, vector<double>& x, bool& disp, vector<vector<bool>>& Asettled, unsigned int& piv, unsigned int& sr_count, unsigned short int& iter, vector<bool>& unsettled_p, vector<double>& singleton_bounds, double& epsi_old, bool& nlsu, vector<unsigned short int>& zeros, vector<bool>& T, vector<unsigned int>& T_coord, vector<bool>& T2, vector<unsigned int>& T2_coord, unsigned int& t_size, unsigned short int& t2_size, vector<vector<bool>>& Atight, vector<vector<bool>>& Atight2, vector<bool>& U, vector<bool>& U2, double& min_satisfaction);
void subr_upd(vector<vector<double>>& Arref, vector<bool>& J, unsigned int& i, unsigned short int& n, double& prec, vector<bool>& U, vector<bool>& U2, unsigned int& sumt, unsigned int& sumt2, vector<bool>& t, vector<bool>& t2, vector<vector<bool>>& Atight, vector<vector<bool>>& Atight2, unsigned int& tight_size, unsigned short int& tight2_size, unsigned short int& rank, vector<bool>& unsettled, vector<vector<bool>>& Asettled, bool& disp, unsigned int& s, vector<unsigned int>& T_coord, vector<unsigned int>& T2_coord, double& epsi_old, double& epsi, vector<bool>& unsettled_p, bool& settled, glp_prob*& lp, vector<bool>& ar0pos);
void subroutine(vector<bool>& U, vector<bool>& U2, vector<vector<bool>>& Atight, vector<vector<bool>>& Atight2, vector<vector<double>>& Arref, vector<bool>& J, double& prec, unsigned short int& n, unsigned int& tight_size, unsigned short int& tight2_size, unsigned short int& rank, bool& disp, vector<vector<bool>>& Asettled, unsigned int& sr_count, bool& u, unsigned int& s, vector<unsigned int>& T_coord, vector<unsigned int>& T2_coord, vector<bool>& unsettled, double& epsi_old, double& epsi, vector<bool>& unsettled_p, bool& settled, bool& nlsu);
void step(vector<bool>& T, vector<bool>& T2, vector<bool>& unsettled, vector<bool>& unsettled_p, unsigned int& s, double& epsi, vector<double>& excess, vector<double>& d, unsigned short int& n, vector<double>& x, vector<double>& singleton_bounds, bool& disp, double& prec, vector<unsigned short int>& zeros, vector<unsigned int>& T_coord, unsigned int& t_size, vector<unsigned int>& T2_coord, unsigned short int& t2_size, vector<vector<bool>>& Atight, vector<vector<bool>>& Atight2, vector<bool>& U, vector<bool>& U2);
void imprdir(vector<double>& d, unsigned short int& n, unsigned int& t_size, unsigned short int& t2_size, vector<vector<bool>>& Atight, vector<vector<bool>>& Atight2, vector<bool>& U, vector<bool>& U2, unsigned short int& rank, vector<vector<bool>>& Asettled, bool& disp);
bool binrank2(vector<vector<double>>& Arref, vector<bool>& J, vector<bool>& b, unsigned short int& n, unsigned short int& rank);
bool binrank(vector<vector<double>>& Arref, vector<bool>& J, vector<bool>& b, unsigned short int& n, unsigned short int& rank);
void sc_vec_prod(vector<double>& y, double a, vector<double>& x);
void vec_subtract(vector<double>& z, vector<double>& x, vector<double>& y);
void sum_vecb(unsigned int& s, vector<bool>& x);

void initial_pairs(unsigned short int& Vp, unsigned short int& N, ListGraph::NodeMap<bool>& active_nodes, ListDigraph::NodeMap<bool>& active_nodes_original, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, unsigned short int& initialSize, set<int>& active_source, vector<int>& source_set);
void arrival_times(vector<unsigned short int>& node_arrives, unsigned short int& Vp, unsigned short int& N, ListGraph::NodeMap<bool>& active_nodes, vector<ListGraph::Node>& c, unsigned short int& periods, bool& disp);

void period_0(unsigned short int& Q, vector<unsigned short int>& no_of_active_nodes, unsigned short int& N, vector<unsigned short int>& s, unsigned short int& Vp, vector<unsigned short int>& node_arrives, ListGraph::NodeMap<bool>& active_nodes, ListDigraph::NodeMap<bool>& active_nodes_original, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, vector<double>& credit, set<int>& active_source, vector<int>& source_set);
void min_d_1(vector<unsigned short int>& node_arrives, vector<bool>& leaving, ListGraph::NodeMap<bool>& active_nodes, ListDigraph::NodeMap<bool>& active_nodes_original, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, bool& disp, vector<unsigned short int>& no_of_active_nodes, unsigned short int& N, unsigned short int& Vp, unsigned short int& periods, bool& dispy, vector<unsigned short int>& s, unsigned short int& Q, vector<double>& v, bool& initial_nucl, vector<double>& credit, vector<double>& d, double& M_total, double& d_total, bool& c_involved, bool& arbitray_maximum, unsigned short int& initialSize, unsigned int& S, double& prec, vector<double>& init_alloc, double& d_c_total, unsigned short int inst, bool lex_min, double& max_d, double& game_generation, double& solution_concept_time, double& scenario_time, vector<vector<double>>& average_d_period, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, vector<vector<double>>& time_breakdown, set<int>& active_source, vector<int>& source_set, Allocation& allo, vector<int>& node_set, vector<unsigned short int>& label_positions, vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, int& n_t, double& relative_deviation, vector<map<int, int>>& cycle_dis, vector<double>& relative_optimal);
double core_dist(vector<double>& x, vector<double>& v, unsigned short int& N, unsigned int& S);
void ILP_d1_gurobi(unsigned short int& Q, unsigned short int& N, unsigned short int& Vp, double& M, double& M_total, vector<unsigned short int>& s, vector<bool>& leaving, vector<double>& d, double& d_total, bool& c_involved, vector<double>& credit, vector<double>& init_alloc, bool lex_min, unsigned short int inst, vector<vector<double>>& average_d_period, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, Allocation& allo, set<int>& active_source, vector<int>& node_set, vector<unsigned short int>& label_positions, int& n_t, vector<map<int, int>>& cycle_dis);
void arbitraryMaximum(vector<unsigned short int>& node_arrives, vector<bool>& leaving, ListGraph::NodeMap<bool>& active_nodes, ListDigraph::NodeMap<bool>& active_nodes_original, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, bool& disp, vector<unsigned short int>& no_of_active_nodes, unsigned short int& N, unsigned short int& Vp, unsigned short int& periods, bool& dispy, vector<unsigned short int>& s, unsigned short int& Q, vector<double>& v, bool& initial_nucl, vector<double>& credit, vector<double>& d, double& M_total, double& d_total, bool& c_involved, bool& arbitray_maximum, unsigned short int& initialSize, unsigned int& S, double& prec, vector<double>& init_alloc, unsigned short int inst, double& max_d, double& game_generation, double& solution_concept_time, vector<vector<double>>& average_d_period, vector<vector<double>>& time_breakdown, set<int>& active_source, vector<int>& source_set, Allocation& allo, vector<int>& node_set, vector<unsigned short int>& label_positions, vector<unsigned int>& arc_in, vector<unsigned int>& arc_out, double& relative_d1_arbitrary, vector<map<int, int>>& cycle_dis, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, vector<double>& relative_optimal);
void changing_nodes(ListGraph::NodeMap<bool>& active_nodes, ListDigraph::NodeMap<bool>& active_nodes_original, vector<bool>& leaving, vector<unsigned short int>& no_of_active_nodes, unsigned short int& N, unsigned short int& Vp, vector<unsigned short int>& node_arrives, unsigned short int& Q, vector<ListGraph::Node>& c, vector<ListGraph::Node>& c_b, vector<ListDigraph::Node>& c_original, vector<unsigned short int>& s, vector<double>& d, set<int>& active_source, vector<int>& source_set);
void lex_min_d_star(vector<double>& d_t, bool& lex_min, unsigned short int& t_star, unsigned short int& N, unsigned short int& n_star, vector<double>& bound, vector<unsigned short int>& N_star, unsigned short int& Vp, vector<double>& target, vector<double>& credit, vector<GRBVar>& var_lexmin, vector<GRBModel>& vector_model, unsigned short int& track, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, unsigned short int& inst, double& M, Allocation& allo, vector<unsigned short int>& label_positions, double& epsilon, int& n_t);
void lex_min_n_star(vector<double>& d_t, bool& lex_min, unsigned short int& t_star, unsigned short int& N, Allocation& allo, double& M, unsigned short int& Vp, double& epsilon, unsigned short int& n_star, vector<double>& bound, vector<unsigned short int>& N_star, vector<GRBVar>& var_lexmin, vector<GRBModel>& vector_model, unsigned short int& track, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, vector<unsigned short int>& label_positions, unsigned short int inst, int& n_t);
void sort_d_t(vector<double>& d_t, vector<GRBVar>& isCycleUsed, vector<unsigned short int>& label_positions, unsigned short int& N, unsigned short int& Vp, Allocation& allo, vector<double>& target, unsigned short int& t, vector<double>& credit, double& epsilon, vector<GRBVar>& var_lexmin, vector<unsigned short int>& N_star);
void lexmin_searching(vector<double>& d_t, bool& lex_min, unsigned short int& t_star, unsigned short int& N, double& epsilon, unsigned short int& n_star, vector<double>& bound, vector<unsigned short int>& N_star, unsigned short int& Vp, vector<double>& target, vector<double>& credit, vector<GRBVar>& var_lexmin, unsigned short int inst, vector<GRBModel>& vector_model, unsigned short int& track, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, double& M, Allocation& allo, vector<unsigned short int>& label_positions, int& n_t);
void epsilon_func(vector<double>& target, vector<double>& credit, double& epsilon, unsigned short int N);
double frac(double ori);
double solve_obj(Allocation& allo, set<int>& active_source, vector<int>& node_set, vector<unsigned short int>& label_positions, vector<map<int, int>>& cycle_dis, bool& is_cycle_dis, vector<vector<int>>& track_not_optimal, vector<vector<int>>& track_time_limit, unsigned short int inst, unsigned short int N, unsigned short int Q);